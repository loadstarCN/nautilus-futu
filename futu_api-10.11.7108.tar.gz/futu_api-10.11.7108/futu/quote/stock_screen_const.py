# -*- coding: utf-8 -*-
"""
StockScreen / WarrantScreen V2 枚举常量

所有枚举值来源于后端 proto 定义：
  - stock_screener_common.proto (条件选股)
  - wrnt_screener_common.proto  (窝轮筛选)

使用 IntEnum，可直接当 int 使用::

    from futu import StockScreenRequest, SimpleField, SimpleProperty, ScrSortDir, ScrMarket

    req = StockScreenRequest()
    req.add_simple_field(field=SimpleField.MARKET, values=[ScrMarket.HK])
    req.add_simple_property(name=SimpleProperty.PRICE, lower=10.0)  # 最新价 > 10
    req.set_sort(direction=ScrSortDir.DESC, property_type='simple',
                 property_params={'name': int(SimpleProperty.PRICE)})

完整枚举示例参见 ``StockScreenRequest`` 类的 docstring。
"""
from enum import IntEnum


# ============================================================
#  通用枚举 (StockScreen)
# ============================================================

class ScrMarket(IntEnum):
    """条件选股市场 (add_simple_field 中 SimpleField.MARKET 对应的 values)"""
    UNKNOWN = 0   # 未知
    HK = 1        # 港股
    US = 2        # 美股
    CN = 3        # A股
    SG = 4        # 新加坡
    CA = 5        # 加拿大
    AU = 6        # 澳大利亚
    JP = 7        # 日本
    MY = 8        # 马来西亚


class ScrSortDir(IntEnum):
    """排序方向 (set_sort / add_sort 的 direction 参数)"""
    ASC = 1       # 升序
    DESC = 2      # 降序
    ABS_ASC = 3   # 绝对值升序
    ABS_DESC = 4  # 绝对值降序


class Period(IntEnum):
    """K线周期"""
    UNKNOWN = 0
    MINUTE_1 = 1   # 1分钟
    MINUTE_3 = 2   # 3分钟
    MINUTE_5 = 3   # 5分钟
    MINUTE_15 = 4  # 15分钟
    HOUR_1 = 5     # 1小时
    MINUTE_30 = 6  # 30分钟
    DAY = 11       # 日线
    WEEK = 21      # 周线
    MONTH = 31     # 月线


class Position(IntEnum):
    """指标相对位置"""
    UNKNOWN = 0
    OVER = 1        # first 位于 second 上方
    BELOW = 2       # first 位于 second 下方
    CROSS_UP = 3    # first 从下往上穿 second
    CROSS_DOWN = 4  # first 从上往下穿 second


class Term(IntEnum):
    """财报期"""
    UNKNOWN = 0
    Q1 = 1          # Q1报
    Q2 = 2          # Q2报
    Q3 = 3          # Q3报
    Q4 = 4          # Q4报
    Q6 = 6          # 中报 (累积报)
    Q9 = 9          # 三季报 (累积报)
    LATEST = 10     # 最新单季报
    ANNUAL = 100    # 年报FY
    # 财报预测相关
    SURPRISE_LATEST = 200           # 最近一期
    SURPRISE_LATEST_QUARTER = 201   # 最近一期季报
    SURPRISE_LATEST_HALF = 202      # 最近一期半年报
    SURPRISE_LATEST_ANNUAL = 203    # 最近一期年报
    SURPRISE_LATEST_ALL = 204       # 全部


class RangePeriod(IntEnum):
    """范围周期 (用于估值分析)"""
    THREE_MONTHS = 1  # 近3月
    SIX_MONTHS = 2    # 近6月
    ONE_YEAR = 3      # 近1年
    THREE_YEARS = 4   # 近3年


class RecentDuration(IntEnum):
    """近N天"""
    LAST_1_DAY = 1     # 最近1天
    LAST_1_WEEK = 7    # 最近1周
    LAST_2_WEEK = 14   # 最近2周
    LAST_1_MONTH = 30  # 最近1月
    LAST_2_MONTH = 31  # 最近2月
    LAST_3_MONTH = 32  # 最近3月
    LAST_1_YEAR = 40   # 最近1年
    LAST_3_YEAR = 41   # 最近3年
    LAST_5_YEAR = 42   # 最近5年


class FutureDuration(IntEnum):
    """未来N天"""
    UNKNOWN = 0
    NEXT_1_DAY = 1    # 未来1天
    NEXT_1_WEEK = 2   # 未来1周
    NEXT_2_WEEK = 3   # 未来2周
    NEXT_1_MONTH = 4  # 未来1月
    NEXT_2_MONTH = 5  # 未来2月


class CashFlowPeriod(IntEnum):
    """资金流向周期"""
    DAY = 1      # 天
    WEEK = 2     # 周
    MONTH_P = 3  # 月
    QUARTER = 4  # 季


class OptionHVPeriod(IntEnum):
    """期权HV周期"""
    HV_30D = 0   # 30天
    HV_60D = 1   # 60天
    HV_90D = 2   # 90天
    HV_120D = 3  # 120天
    HV_365D = 4  # 365天


# ============================================================
#  SimpleField — 简单字段筛选
# ============================================================

class SimpleField(IntEnum):
    """简单字段 (add_simple_field 的 field 参数)"""
    MARKET = 1             # 市场 (values 传 Market 枚举)
    EXCHANGE = 2           # 交易所/上市地
    INDEX_ID = 3           # 指数ID
    USE_WATCHLIST = 4      # 使用自选股 (0=不用, 1=使用)
    HAS_ADR = 5            # 是否有关联ADR标的
    HAS_OPTION = 6         # 是否含期权标的
    HAS_WARRANT = 7        # 是否含窝轮标的
    HAS_FUTURE = 8         # 是否含期货标的
    HAS_AH_STOCK = 9       # 是否有关联AH股
    IS_ISLAMIC = 10        # 是否回教股
    NORTH_BOUND_ID = 11    # 北向板块ID (沪股通/深股通)
    MM_EXCLUSIVE_ID = 12   # Moomoo独家板块ID


# ============================================================
#  PropertyBasic — 基础属性
# ============================================================

class BasicProperty(IntEnum):
    """基础属性 (代码/名称/行业)"""
    UNKNOWN = 0
    CODE = 1101       # 股票代码
    NAME = 1102       # 股票名称
    INDUSTRY = 1103   # 所属行业


# ============================================================
#  PropertyNameSimple — 简单行情属性
# ============================================================

class SimpleProperty(IntEnum):
    """简单行情属性 (add_simple_property / add_retrieve_simple 的 name 参数)

    值 = 后端 PropertyNameSimple 枚举。
    注释中 "倍率:1000" 表示后端返回的 int64 值除以 1000 得到真实值。
    """
    UNKNOWN = 0
    # --- 融资融券 ---
    LONG_MARGIN_ALLOWED = 2101              # 是否允许融资 (0/1)
    LONG_MARGIN_MORTGAGE_RATE = 2102        # 融资抵押率 (倍率:1e5)
    SHORT_MARGIN_ALLOWED = 2103             # 是否允许融券 (0/1)
    SHORT_MARGIN_INTEREST_RATE = 2104       # 融券利息率 (倍率:1e6)
    LONG_MARGIN_BAIL_RATE = 2105            # 融资保证金率 (倍率:1e5)
    SHORT_MARGIN_BAIL_RATE = 2106           # 融券保证金率 (倍率:1e5)
    # --- 报价 ---
    PRICE = 2201                            # 最新价格 (倍率:1000)
    OPEN_PRICE = 2202                       # 今开价 (倍率:1000)
    LAST_CLOSE = 2203                       # 昨收价 (倍率:1000)
    HIGH = 2204                             # 今最高价 (倍率:1000)
    LOW = 2205                              # 今最低价 (倍率:1000)
    PRICE_CHANGE_RATE = 2206                # 涨跌速率 (倍率:1e5)
    BID_PRICE = 2207                        # 买入价 (倍率:1000)
    ASK_PRICE = 2208                        # 卖出价 (倍率:1000)
    PRICE_TO_52W_HIGH = 2209                # (现价-52周最高)/52周最高 (倍率:1e5)
    PRICE_TO_52W_LOW = 2210                 # (现价-52周最低)/52周最低 (倍率:1e5)
    HIGH_TO_52W_HIGH = 2211                 # (今高-52周最高)/52周最高 (倍率:1e5)
    LOW_TO_52W_LOW = 2212                   # (今低-52周最低)/52周最低 (倍率:1e5)
    CHANGE_5MIN = 2213                      # 五分钟涨跌幅 (倍率:1e5)
    CHANGE_YTD = 2214                       # 年初至今涨跌幅 (倍率:1e5)
    BID_VOL = 2215                          # 买入量 (倍率:1)
    ASK_VOL = 2216                          # 卖出量 (倍率:1)
    VOLUME_RATIO = 2217                     # 量比 (倍率:1e5)
    BID_ASK_RATIO = 2218                    # 委比 (倍率:1e7)
    LOT_PRICE = 2219                        # 每手价格 (倍率:1000)
    # --- 高精度价格 ---
    PRICE_HP = 2220                         # 高精度最新价 (倍率:1e9)
    OPEN_PRICE_HP = 2221                    # 高精度今开价 (倍率:1e9)
    LAST_CLOSE_HP = 2222                    # 高精度昨收价 (倍率:1e9)
    HIGH_HP = 2223                          # 高精度今最高 (倍率:1e9)
    LOW_HP = 2224                           # 高精度今最低 (倍率:1e9)
    BID_PRICE_HP = 2225                     # 高精度买入价 (倍率:1e9)
    ASK_PRICE_HP = 2226                     # 高精度卖出价 (倍率:1e9)
    LOT_PRICE_HP = 2227                     # 高精度每手价格 (倍率:1e9)
    # --- 信息 ---
    MARKET_CAP = 2301                       # 市值 (倍率:1000)
    PE_ANNUAL = 2302                        # 年化(静态)市盈率 (倍率:1e5)
    PE_TTM = 2303                           # TTM市盈率 (倍率:1e5)
    PB = 2304                               # 市净率 (倍率:1e5)
    DIVIDEND_RATIO = 2305                   # 股息率 (倍率:1e5)
    LISTED_DATE = 2306                      # 上市时间 (时间戳)
    LISTED_DAYS = 2307                      # 上市天数 (倍率:1)
    TOYOKEIZAI_FORECAST_PE = 2308           # 东洋预测PE (倍率:1e5)
    # --- 盘前盘后 ---
    BEFORE_PRICE = 2401                     # 盘前价格 (倍率:1000)
    BEFORE_PRICE_CHANGE = 2402              # 盘前涨跌额 (倍率:1000)
    BEFORE_CHANGE_PCT = 2403                # 盘前涨跌幅 (倍率:1e5)
    BEFORE_VOLUME = 2404                    # 盘前成交量 (倍率:1)
    BEFORE_TURNOVER = 2405                  # 盘前成交额 (倍率:1000)
    AFTER_PRICE = 2406                      # 盘后价格 (倍率:1000)
    AFTER_PRICE_CHANGE = 2407               # 盘后涨跌额 (倍率:1000)
    AFTER_CHANGE_PCT = 2408                 # 盘后涨跌幅 (倍率:1e5)
    AFTER_VOLUME = 2409                     # 盘后成交量 (倍率:1)
    AFTER_TURNOVER = 2410                   # 盘后成交额 (倍率:1000)
    # --- 高精度盘前盘后 ---
    BEFORE_PRICE_HP = 2411                  # 高精度盘前价格 (倍率:1e9)
    BEFORE_PRICE_CHANGE_HP = 2412           # 高精度盘前涨跌额 (倍率:1e9)
    AFTER_PRICE_HP = 2413                   # 高精度盘后价格 (倍率:1e9)
    AFTER_PRICE_CHANGE_HP = 2414            # 高精度盘后涨跌额 (倍率:1e9)
    # --- 夜盘 ---
    OVERNIGHT_PRICE = 2415                  # 夜盘价格 (倍率:1e9)
    OVERNIGHT_PRICE_CHANGE = 2416           # 夜盘涨跌额 (倍率:1e9)
    OVERNIGHT_CHANGE_PCT = 2417             # 夜盘涨跌幅 (倍率:1e5)
    OVERNIGHT_VOLUME = 2418                 # 夜盘成交量 (倍率:1)
    OVERNIGHT_TURNOVER = 2419               # 夜盘成交额 (倍率:1e3)


# ============================================================
#  PropertyNameCumulative — 累计行情属性
# ============================================================

class CumulativeProperty(IntEnum):
    """累计行情属性 (add_cumulative_property 的 name 参数)"""
    UNKNOWN = 0
    PRICE_CHANGE = 3101             # 价格涨跌额 (倍率:1000)
    PRICE_CHANGE_PCT = 3102         # 价格涨跌幅 (倍率:1e5)
    AMPLITUDE = 3103                # 价格振幅 (倍率:1e5)
    AVG_VOLUME = 3104               # 平均成交量 (倍率:1)
    AVG_TURNOVER = 3105             # 平均成交额 (倍率:1000)
    TURNOVER_RATIO = 3106           # 换手率 (倍率:1e5)
    HIGH_TO_N_DAY_HIGH = 3107       # (今高-n日最高)/n日最高 (倍率:1e5)
    LOW_TO_N_DAY_LOW = 3108         # (今低-n日最低)/n日最低 (倍率:1e5)
    PRICE_CHANGE_HP = 3109          # 高精度涨跌额 (倍率:1e9)


# ============================================================
#  PropertyNameFinancial — 财务属性
# ============================================================

class FinancialProperty(IntEnum):
    """财务属性 (add_financial_property 的 name 参数)"""
    UNKNOWN = 0
    # --- 基本财务因子 ---
    NET_PROFIT = 4101                       # 净利润 (倍率:1000)
    NET_PROFIT_GROWTH = 4102                # 净利润增长率 (倍率:1e5)
    GROSS_PROFIT = 4103                     # 毛利润 (倍率:1000)
    GROSS_PROFIT_GROWTH = 4104              # 毛利润增长率 (倍率:1e5)
    REVENUE = 4105                          # 营业额 (倍率:1000)
    REVENUE_GROWTH = 4106                   # 营业额增长率 (倍率:1e5)
    NET_PROFIT_RATIO = 4107                 # 净利率 (倍率:1e5)
    GROSS_PROFIT_RATIO = 4108               # 毛利率 (倍率:1e5)
    DEBT_TO_ASSETS = 4109                   # 资产负债率 (倍率:1e5)
    ROE = 4110                              # 净资产收益率 (倍率:1e5)
    RELEASED_DATE = 4111                    # 财报日期 (时间戳秒)
    # --- 盈利能力因子 ---
    EBITDA = 4201                           # 税息折旧及摊销前利润 (倍率:1000)
    ROIC = 4202                             # 投入资本回报率 (倍率:1e5)
    EBIT_MARGIN = 4203                      # EBIT利润率 (倍率:1e5)
    EBITDA_MARGIN = 4204                    # EBITDA利润率 (倍率:1e5)
    FINANCIAL_COST_RATE = 4205              # 财务成本率 (倍率:1e5)
    EBIT_TTM = 4206                         # 息税前利润TTM (倍率:1000)
    OPERATING_PROFIT_TTM = 4207             # 营业利润TTM (倍率:1000)
    SHAREHOLDERS_PROFIT_TTM = 4208          # 归母净利润TTM (倍率:1000)
    ROA_TTM = 4209                          # 资产回报率TTM (倍率:1e5)
    OPERATING_MARGIN_TTM = 4210             # 营业利润率TTM (倍率:1e5)
    NET_PROFIT_CASH_COVER_TTM = 4211        # 盈利现金收入比例TTM (倍率:1e5)
    RD_EXPENSE_RATIO = 4212                 # 研发费用率 (倍率:1e5)
    SELLING_EXPENSE_RATIO = 4213            # 销售费用率 (倍率:1e5)
    MANAGE_EXPENSE_RATIO = 4214             # 管理费用率 (倍率:1e5)
    OPERATING_PROFIT_RATE = 4215            # 经营利润率 (倍率:1e5)
    PROFIT_BEFORE_TAX_RATE = 4216           # 税前利润率 (倍率:1e5)
    DIVIDENDS_TTM = 4217                    # 股息TTM (倍率:1000)
    DIVIDENDS_LFY = 4218                    # 股息LFY (倍率:1000)
    DIVIDENDS_TTM_RATIO = 4219              # 股息率TTM (倍率:1e5)
    DIVIDENDS_LFY_RATIO = 4220              # 股息率LFY (倍率:1e5)
    # --- 偿债能力因子 ---
    CURRENT_RATIO = 4301                    # 流动比率 (倍率:1e5)
    QUICK_RATIO = 4302                      # 速动比率 (倍率:1e5)
    LT_DEBT_SHAREHOLDERS_RATIO = 4303       # 长期负债股东权益比率 (倍率:1e5)
    FINANCIAL_LEVERAGE = 4304               # 财务杠杆 (倍率:1e5)
    INTEREST_BEARING_DEBT_RATIO = 4305      # 有息负债率 (倍率:1e5)
    # --- 清债能力因子 ---
    CASH_EQUIVALENTS = 4401                 # 现金和现金等价 (倍率:1000)
    CURRENT_ASSET_RATIO = 4402              # 流动资产率 (倍率:1e5)
    CURRENT_DEBT_RATIO = 4403               # 流动负债率 (倍率:1e5)
    EQUITY_MULTIPLIER = 4404                # 权益乘数 (倍率:1e5)
    PROPERTY_RATIO = 4405                   # 产权比率 (倍率:1e5)
    # --- 运营能力因子 ---
    ACCOUNTS_RECEIVABLE = 4501              # 应收帐款净额 (倍率:1000)
    TOTAL_ASSET_TURNOVER = 4502             # 总资产周转率 (倍率:1e5)
    FIXED_ASSET_TURNOVER = 4503             # 固定资产周转率 (倍率:1e5)
    INVENTORY_TURNOVER = 4504               # 存货周转率 (倍率:1e5)
    OPERATING_CASH_FLOW_TTM = 4505          # 经营活动现金流TTM (倍率:1000)
    MONEY_TURNOVER_CYCLE = 4506             # 资金周转周期(天) (倍率:1000)
    ACCOUNTS_RECEIVABLE_RATE = 4507         # 应收帐款周转率(次) (倍率:1000)
    FREE_CASH_FLOW_INCOME_RATIO = 4508      # 自由现金流/收入 (倍率:1e5)
    FREE_CASH_FLOW_NP_RATIO = 4509          # 自由现金流/母公司净利润 (倍率:1e5)
    CURRENT_ASSETS_TURNOVER = 4510          # 流动资产周转率(次) (倍率:1000)
    INCOME_PER_CAPITA = 4511                # 人均营收 (倍率:1000)
    PROFIT_PER_CAPITA = 4512                # 人均营业利润 (倍率:1000)
    NET_PROFIT_PER_CAPITA = 4513            # 人均净利润 (倍率:1000)
    # --- 成长能力 ---
    EBIT_GROWTH_RATE = 4601                 # EBIT同比增长率 (倍率:1e5)
    OPERATING_PROFIT_GROWTH = 4602          # 营业利润同比增长率 (倍率:1e5)
    TOTAL_ASSETS_GROWTH = 4603              # 总资产同比增长率 (倍率:1e5)
    SHAREHOLDER_PROFIT_GROWTH = 4604        # 归母净利润同比增长率 (倍率:1e5)
    PROFIT_BEFORE_TAX_GROWTH = 4605         # 总利润同比增长率 (倍率:1e5)
    EPS_GROWTH_RATE = 4606                  # EPS同比增长率 (倍率:1e5)
    ROE_GROWTH_RATE = 4607                  # ROE同比增长率 (倍率:1e5)
    ROIC_GROWTH_RATE = 4608                 # ROIC同比增长率 (倍率:1e5)
    NOCF_GROWTH_RATE = 4609                 # 经营现金流同比增长率 (倍率:1e5)
    NOCF_PER_SHARE_GROWTH = 4610            # 每股经营现金流同比增长率 (倍率:1e5)
    REVENUE_CAGR = 4611                     # 总收入复合年均增长率 (倍率:1e5)
    GROSS_PROFIT_CAGR = 4612                # 毛利润复合年均增长率 (倍率:1e5)
    EBITDA_CAGR = 4613                      # EBITDA复合年均增长率 (倍率:1e5)
    EBIT_CAGR = 4614                        # EBIT复合年均增长率 (倍率:1e5)
    NET_PROFIT_CAGR = 4615                  # 净利润复合年均增长率 (倍率:1e5)
    STOCKHOLDER_PROFIT_CAGR = 4616          # 归属普通股利润CAGR (倍率:1e5)
    NET_MARGIN_CAGR = 4617                  # 归母净利润CAGR (倍率:1e5)
    OPERATING_PROFIT_CAGR = 4618            # 营业利润CAGR (倍率:1e5)
    FREE_CASH_CAGR = 4619                   # 自由现金流CAGR (倍率:1e5)
    TOTAL_ASSETS_CAGR = 4620                # 总资产CAGR (倍率:1e5)
    BASIC_EPS_CAGR = 4621                   # EPS CAGR (倍率:1e5)
    ROA_CAGR = 4622                         # ROA CAGR (倍率:1e5)
    ROE_CAGR = 4623                         # ROE CAGR (倍率:1e5)
    ROIC_CAGR = 4624                        # ROIC CAGR (倍率:1e5)
    DIVIDEND_CAGR = 4625                    # 股息CAGR (倍率:1e5)
    FREE_CASH_FLOW_GROWTH = 4626            # 自由现金流同比增长率 (倍率:1e5)
    # --- 现金流 ---
    OPERATING_REVENUE_CASH_COVER = 4701     # 经营现金收入比 (倍率:1e5)
    OPERATING_PROFIT_TOTAL_RATIO = 4702     # 营业利润占比 (倍率:1e5)
    FREE_CASH_FLOW = 4703                   # 自由现金流 (倍率:1e3)
    # --- 市场表现 ---
    BASIC_EPS = 4801                        # 基本每股收益 (倍率:1000)
    DILUTED_EPS = 4802                      # 稀释每股收益 (倍率:1000)
    NOCF_PER_SHARE = 4803                   # 每股经营现金净流量 (倍率:1000)
    # --- 基础量价因子 ---
    TOTAL_SHARE = 4901                      # 总股数 (倍率:1)
    FLOAT_SHARE = 4902                      # 流通股数 (倍率:1)
    FLOAT_MARKET_CAP = 4903                 # 流通市值 (倍率:1000)
    PS_TTM = 4904                           # 市销率TTM (倍率:1e5)
    PCF_TTM = 4905                          # 市现率TTM (倍率:1e5)
    # --- 财务超预期 ---
    SURPRISE_EPS_DATE = 4906                # EPS发布日 (时间戳秒)
    SURPRISE_REVENUE_DATE = 4907            # REVENUE发布日 (时间戳秒)
    SURPRISE_EBIT_DATE = 4908               # EBIT发布日 (时间戳秒)
    SURPRISE_ACTUAL_EPS = 4909              # 真实值EPS (倍率:1e4)
    SURPRISE_ACTUAL_REVENUE = 4910          # 真实值REVENUE (倍率:1e4)
    SURPRISE_ACTUAL_EBIT = 4911             # 真实值EBIT (倍率:1e4)
    SURPRISE_ESTIMATE_EPS = 4912            # 预测值EPS (倍率:1e4)
    SURPRISE_ESTIMATE_REVENUE = 4913        # 预测值REVENUE (倍率:1e4)
    SURPRISE_ESTIMATE_EBIT = 4914           # 预测值EBIT (倍率:1e4)
    SURPRISE_EPS_BEAT = 4915                # 超预期比例EPS (倍率:1e5)
    SURPRISE_REVENUE_BEAT = 4916            # 超预期比例REVENUE (倍率:1e5)
    SURPRISE_EBIT_BEAT = 4917               # 超预期比例EBIT (倍率:1e5)
    SURPRISE_EPS_YOY = 4918                 # 去年同期EPS (倍率:1e4)
    SURPRISE_REVENUE_YOY = 4919             # 去年同期REVENUE (倍率:1e4)
    SURPRISE_EBIT_YOY = 4920                # 去年同期EBIT (倍率:1e4)
    SURPRISE_EPS_YOY_GROWTH = 4921          # 同比增长率EPS (倍率:1e5)
    SURPRISE_REVENUE_YOY_GROWTH = 4922      # 同比增长率REVENUE (倍率:1e5)
    SURPRISE_EBIT_YOY_GROWTH = 4923         # 同比增长率EBIT (倍率:1e5)
    SURPRISE_EPS_TERM = 4924                # EPS财报周期
    SURPRISE_REVENUE_TERM = 4925            # REVENUE财报周期
    SURPRISE_EBIT_TERM = 4926               # EBIT财报周期
    SURPRISE_EPS_EARNING_DAY_CHG = 4927     # EPS财报日涨跌幅 (倍率:1e5)
    SURPRISE_REVENUE_EARNING_DAY_CHG = 4928  # REVENUE财报日涨跌幅 (倍率:1e5)
    SURPRISE_EBIT_EARNING_DAY_CHG = 4929    # EBIT财报日涨跌幅 (倍率:1e5)
    SURPRISE_EPS_POST_DAY_CHG = 4930        # EPS财报次日涨跌幅 (倍率:1e5)
    SURPRISE_REVENUE_POST_DAY_CHG = 4931    # REVENUE财报次日涨跌幅 (倍率:1e5)
    SURPRISE_EBIT_POST_DAY_CHG = 4932       # EBIT财报次日涨跌幅 (倍率:1e5)
    SURPRISE_EPS_POST_PERIOD = 4933         # EPS财报具体时间
    SURPRISE_REVENUE_POST_PERIOD = 4934     # REVENUE财报具体时间
    SURPRISE_EBIT_POST_PERIOD = 4935        # EBIT财报具体时间
    SURPRISE_EPS_DAY_CHG_V2 = 4936          # EPS财报日涨跌幅V2 (倍率:1e5)
    SURPRISE_REVENUE_DAY_CHG_V2 = 4937      # REVENUE财报日涨跌幅V2 (倍率:1e5)
    SURPRISE_EBIT_DAY_CHG_V2 = 4938         # EBIT财报日涨跌幅V2 (倍率:1e5)
    SURPRISE_EPS_DATE_V2 = 4939             # EPS发布日V2 (时间戳)
    SURPRISE_REVENUE_DATE_V2 = 4940         # REVENUE发布日V2 (时间戳)
    SURPRISE_EBIT_DATE_V2 = 4941            # EBIT发布日V2 (时间戳)
    SURPRISE_EPS_POST_PERIOD_V2 = 4942      # EPS发布时间V2
    SURPRISE_REVENUE_POST_PERIOD_V2 = 4943  # REVENUE发布时间V2
    SURPRISE_EBIT_POST_PERIOD_V2 = 4944     # EBIT发布时间V2


# ============================================================
#  Indicator — 技术指标
# ============================================================

class Indicator(IntEnum):
    """技术指标 (add_indicator_positional 的 first_indicator_name 参数)"""
    UNKNOWN = 0
    PRICE = 1               # 最新价格 (倍率:1000)
    # --- MA ---
    MA5 = 11                # 5日简单均线 (倍率:1000)
    MA10 = 12               # 10日简单均线 (倍率:1000)
    MA20 = 13               # 20日简单均线 (倍率:1000)
    MA30 = 14               # 30日简单均线 (倍率:1000)
    MA60 = 15               # 60日简单均线 (倍率:1000)
    MA120 = 16              # 120日简单均线 (倍率:1000)
    MA250 = 17              # 250日简单均线 (倍率:1000)
    MA = 18                 # 动态简单均线 (倍率:1000, 需设 indicator_params)
    # --- EMA ---
    EMA5 = 21               # 5日指数均线 (倍率:1000)
    EMA10 = 22              # 10日指数均线 (倍率:1000)
    EMA20 = 23              # 20日指数均线 (倍率:1000)
    EMA30 = 24              # 30日指数均线 (倍率:1000)
    EMA60 = 25              # 60日指数均线 (倍率:1000)
    EMA120 = 26             # 120日指数均线 (倍率:1000)
    EMA250 = 27             # 250日指数均线 (倍率:1000)
    EMA = 28                # 动态指数均线 (倍率:1000, 需设 indicator_params)
    # --- KDJ ---
    KDJ_K = 31              # KDJ(9,3,3)的K值 (倍率:1e5)
    KDJ_D = 32              # KDJ(9,3,3)的D值 (倍率:1e5)
    KDJ_J = 33              # KDJ(9,3,3)的J值 (倍率:1e5)
    KDJ_K_DYN = 34          # 动态KDJ的K值 (倍率:1e5)
    KDJ_D_DYN = 35          # 动态KDJ的D值 (倍率:1e5)
    KDJ_J_DYN = 36          # 动态KDJ的J值 (倍率:1e5)
    # --- MACD ---
    MACD_DIF = 41           # MACD(12,26,9)的DIF (倍率:1000)
    MACD_DEA = 42           # MACD(12,26,9)的DEA (倍率:1000)
    MACD_MACD = 43          # MACD(12,26,9)的MACD (倍率:1000)
    MACD_DIF_DYN = 44       # 动态MACD的DIF (倍率:1000)
    MACD_DEA_DYN = 45       # 动态MACD的DEA (倍率:1000)
    MACD_MACD_DYN = 46      # 动态MACD的MACD (倍率:1000)
    # --- RSI ---
    RSI_12 = 51             # RSI(12) (倍率:1e5)
    RSI = 52                # 动态RSI (倍率:1e5, 需设 indicator_params)
    # --- BOLL ---
    BOLL_UPPER = 61         # BOLL(20,2)上轨 (倍率:1000)
    BOLL_MIDDLE = 62        # BOLL(20,2)中轨 (倍率:1000)
    BOLL_LOWER = 63         # BOLL(20,2)下轨 (倍率:1000)
    BOLL_UPPER_DYN = 64     # 动态BOLL上轨 (倍率:1000)
    BOLL_MIDDLE_DYN = 65    # 动态BOLL中轨 (倍率:1000)
    BOLL_LOWER_DYN = 66     # 动态BOLL下轨 (倍率:1000)
    # --- RVOL ---
    RVOL = 71               # 动态RVOL (倍率:1e4)


# ============================================================
#  Pattern — 指标形态
# ============================================================

class Pattern(IntEnum):
    """指标形态 (add_indicator_pattern 的 name 参数)"""
    UNKNOWN = 0
    # --- MA/EMA 排列 ---
    MA_LONG = 1             # MA多头排列
    MA_SHORT = 2            # MA空头排列
    EMA_LONG = 3            # EMA多头排列
    EMA_SHORT = 4           # EMA空头排列
    # --- KDJ ---
    KDJ_GOLD_CROSS = 11     # KDJ低位金叉
    KDJ_DEATH_CROSS = 12    # KDJ高位死叉
    KDJ_TOP_DIVERGE = 13    # KDJ顶背离
    KDJ_BOTTOM_DIVERGE = 14 # KDJ底背离
    # --- MACD ---
    MACD_GOLD_CROSS = 21    # MACD低位金叉
    MACD_DEATH_CROSS = 22   # MACD高位死叉
    MACD_TOP_DIVERGE = 23   # MACD顶背离
    MACD_BOTTOM_DIVERGE = 24  # MACD底背离
    # --- RSI ---
    RSI_GOLD_CROSS = 31     # RSI低位金叉
    RSI_DEATH_CROSS = 32    # RSI高位死叉
    RSI_TOP_DIVERGE = 33    # RSI顶背离
    RSI_BOTTOM_DIVERGE = 34 # RSI底背离
    # --- BOLL ---
    BOLL_BREAK_UPPER = 41   # 突破上轨
    BOLL_BREAK_LOWER = 42   # 突破下轨
    BOLL_CROSS_MID_UP = 43  # 向上破中轨
    BOLL_CROSS_MID_DOWN = 44  # 向下破中轨
    # --- 综合信号 ---
    BULLISH = 100           # 看涨信号
    BEARISH = 101           # 看跌信号


# ============================================================
#  Featured — 特色指标
# ============================================================

class FeaturedProperty(IntEnum):
    """特色指标 (add_featured_property 的 name 参数)"""
    # --- 筹码 ---
    CHIPS_PROFIT_RATIO = 5101           # 筹码获利比例 (倍率:1e5)
    CHIPS_INTERVAL_COINCIDENCE = 5102   # 筹码区间重合度 (倍率:1e5)
    # --- 卖空数据 ---
    SHORT_POSITION = 5110               # 卖空持仓量 (倍率:1)
    FINANCIAL_POSITION = 5111           # 融资持仓量 (倍率:1)
    SHORT_LAST_WEEK_DIFF = 5112         # 卖空净增仓(前周比) (倍率:1)
    FINANCIAL_LAST_WEEK_DIFF = 5113     # 融资净增仓(前周比) (倍率:1)
    FINANCING_SHORT_RATIO = 5114        # 融资/卖空倍数 (倍率:1e3)
    LENDING_FEE_PER_SHARE = 5115        # 借贷费用(逆日步) (倍率:1e3)
    COVER_DAYS = 5116                   # 回补天数 (倍率:1e3)
    # --- 指标解读 ---
    INDICATOR_ANALYSIS = 5201           # 指标解读状态 (倍率:1000)
    PEARSON_CORRELATION = 5202          # 皮尔逊相关系数 (倍率:1e5, 参数:板块ID)
    BETA = 5203                         # 贝塔系数 (倍率:1e5, 参数:板块ID)
    # --- 股票热度 ---
    TRADE_INDEX = 5211                  # 交易热度 (倍率:1e5)
    SEARCH_INDEX = 5212                 # 搜索热度 (倍率:1e5)
    NEWS_INDEX = 5213                   # 资讯热度 (倍率:1e5)
    AVERAGE_INDEX = 5214                # 综合热度 (倍率:1e5)
    TRADE_INDEX_RANK = 5215             # 交易热度排名 (倍率:1)
    SEARCH_INDEX_RANK = 5216            # 搜索热度排名 (倍率:1)
    NEWS_INDEX_RANK = 5217              # 资讯热度排名 (倍率:1)
    AVERAGE_INDEX_RANK = 5218           # 综合热度排名 (倍率:1)
    TRADE_RANK_CHANGE = 5219            # 交易热度排名增减 (倍率:1)
    SEARCH_RANK_CHANGE = 5220           # 搜索热度排名增减 (倍率:1)
    NEWS_RANK_CHANGE = 5221             # 资讯热度排名增减 (倍率:1)
    AVERAGE_RANK_CHANGE = 5222          # 综合热度排名增减 (倍率:1)
    # --- 舆情 ---
    PUBLIC_OPINION = 5301               # 舆情指数状态 (倍率:1000)
    # --- IFIS ---
    IFIS_ANNOUNCE_DATE = 5310           # 业绩公告日 (时间戳)
    IFIS_REVISED_SALES = 5311           # 营业收入业绩修正率 (倍率:1e5)
    IFIS_REVISED_OP = 5312              # 营业利润业绩修正率 (倍率:1e5)
    IFIS_REVISED_RP = 5313              # 经常利润业绩修正率 (倍率:1e5)
    IFIS_REVISED_NP = 5314              # 归普净利润业绩修正率 (倍率:1e5)
    # --- 机构持股 ---
    INST_RATIO = 5320                   # 个股机构持股比例 (倍率:1e5)
    INST_STOCK_RATIO = 5321             # 机构持股个股比例 (倍率:1e5, 参数:机构ID)
    IS_INST_HOLD = 5322                 # 是否机构持股 (参数:机构ID)
    INST_VALUE = 5323                   # 机构持股市值 (倍率:1e3)
    INST_SHARES_CHG = 5324              # 机构持股数变化 (倍率:1e5)
    INST_HOLDING_RATIO = 5325           # 机构持股比率 (倍率:1e5)
    INST_HOLDING_CHG_RATIO = 5326       # 机构持股变化比率 (倍率:1e5)
    INST_HOLDING_CHG_TYPE = 5327        # 机构持股变化类型 (倍率:1)
    INST_HOLDING_DATE = 5328            # 机构持股日期 (倍率:1)
    # --- 员工数 ---
    EMPLOYEE_NUM = 5330                 # 员工人数 (倍率:1)
    EMPLOYEE_NUM_GROWTH = 5331          # 员工人数增长率 (倍率:1e5, 参数:RecentDuration)
    # --- 分析师评级 ---
    ANALYST_RATING = 5401               # 分析师评级状态 (倍率:1000)
    ANALYST_RATING_CHANGE = 5402        # 机构评级变动 (参数:RecentDuration, RatingChangeType)
    ANALYST_TARGET_PRICE = 5403         # 分析师目标价 (倍率:1e9)
    ANALYST_TARGET_PRICE_RATE = 5404    # (目标价-现价)/现价 (倍率:1e5)
    # --- 晨星评级 ---
    MORNINGSTAR_FAIR_VALUE = 5405       # 晨星公允价值 (倍率:1e9)
    MORNINGSTAR_FAIR_VALUE_RATE = 5406  # (公允价-现价)/现价 (倍率:1e5)
    MORNINGSTAR_STAR = 5407             # 晨星星级评级 (倍率:1)
    MORNINGSTAR_MOAT = 5408             # 晨星护城河 (倍率:1)
    MORNINGSTAR_UNCERTAINTY = 5409      # 晨星不确定性 (倍率:1)
    MORNINGSTAR_HEALTH = 5410           # 晨星财务健康 (倍率:1)
    # --- 公司估值 ---
    HIST_PERCENTILE_PB = 5501           # PB高于历史百分位 (倍率:1e5)
    HIST_PERCENTILE_PE = 5502           # PE高于历史百分位 (倍率:1e5)
    HIST_PERCENTILE_PS = 5503           # PS高于历史百分位 (倍率:1e5)
    INDUSTRY_RANK_PB = 5504             # PB行业排行 (倍率:1)
    INDUSTRY_RANK_PE = 5505             # PE行业排行 (倍率:1)
    INDUSTRY_RANK_PS = 5506             # PS行业排行 (倍率:1)
    MARKET_RANK_PB = 5507               # PB市场排行 (倍率:1)
    MARKET_RANK_PE = 5508               # PE市场排行 (倍率:1)
    MARKET_RANK_PS = 5509               # PS市场排行 (倍率:1)
    # --- 融资融券 ---
    IS_LONG_MARGIN = 5600               # 是否允许融资 (参数:券商ID)
    IS_SHORT_MARGIN = 5601              # 是否允许融券 (参数:券商ID)
    INIT_LONG_MARGIN_RATIO = 5602       # 融资初始保证金比率 (倍率:1e6, 参数:券商ID)
    INIT_SHORT_MARGIN_RATIO = 5603      # 卖空初始保证金比率 (倍率:1e6, 参数:券商ID)
    SHORT_FEE_RATE = 5604               # 卖空费率 (倍率:1e6, 参数:券商ID)
    IS_COLLATERAL = 5605                # 是否可抵押证券 (参数:券商ID)
    COLLATERAL_RATIO = 5606             # 可抵押证券抵押比例 (倍率:1e6, 参数:券商ID)
    # --- 股东优待 ---
    IS_SHAREHOLDER_PERKS = 5700         # 是否支持股东优待
    PERKS_REQUIRED_VAL = 5701           # 最低购买金额 (倍率:1e6)
    PERKS_ST_MONTHS = 5702              # 股权登记月 (倍率:1)
    PERKS_YIELD = 5703                  # 股东优待收益率 (倍率:1e6)
    PERKS_TOTAL_YIELD = 5704            # 股东优待总收益率 (倍率:1e6)
    PERKS_CATEGORIES = 5705             # 股东优待分类 (倍率:1)
    PERKS_HAS_ST_MONTH = 5706           # 是否包含股权登记月 (参数:月份)
    PERKS_HAS_CATEGORY = 5707           # 是否包含优待分类 (参数:分类)
    # --- 股息率 ---
    PAYOUT_RATIO_LFY = 5800             # 股息支付率LFY (倍率:1e5)
    DISTRIBUTION_FREQUENCY = 5801       # 派息频率 (1=年, 2=半年, 3=季, 4=月)
    MAX_DIVIDEND_GROW_YEAR = 5802       # 股息最大增长年数 (倍率:1)
    PUB_DATE_TIMESTAMP = 5803           # 公告日时间戳 (倍率:1)
    PUB_DATE_DAYS = 5804                # 公告日天数 (倍率:1)
    NEXT_RECORD_DATE = 5805             # 下次股权登记日时间戳 (倍率:1)
    NEXT_RECORD_DATE_DAYS = 5806        # 下次股权登记日天数 (倍率:1)
    NEXT_EX_DATE = 5807                 # 下次除权除息日时间戳 (倍率:1)
    NEXT_EX_DATE_DAYS = 5808            # 下次除权除息日天数 (倍率:1)
    NEXT_PAYABLE_DATE = 5809            # 下次派息日时间戳 (倍率:1)
    NEXT_PAYABLE_DATE_DAYS = 5810       # 下次派息日天数 (倍率:1)
    INCREASE_RATE = 5811                # 增派率 (倍率:1e5, 参数:1/3/5年)
    AVERAGE_DIVIDEND_YIELD = 5812       # 平均股息率 (倍率:1e5, 参数:3/5年)
    TOYOKEIZAI_FORECAST_DIV = 5813      # 东洋预测股息率 (倍率:1e5)
    # --- AU Franking ---
    AU_FRANKING_DIVIDEND = 5814         # 最近计税周期股息 (倍率:1e5)
    AU_FRANKING_DIVIDEND_YIELD = 5815   # 最近计税周期股息率 (倍率:1e5)
    AU_FRANKING = 5816                  # 抵免税率 (倍率:1e5)
    AU_FRANKING_CREDIT = 5817           # 抵免税额 (倍率:1e5)
    AU_FRANKING_GROSS_YIELD = 5818      # 毛利股息率 (倍率:1e5)
    AU_FRANKING_TAX_RATE = 5819         # 公司税率 (倍率:1e5)
    # --- 资金流向 ---
    CASH_FLOW_TOTAL_NET_IN = 5900       # 整体净流入 (倍率:1e3, 参数:CashFlowPeriod)
    CASH_FLOW_MAIN_NET_IN = 5901        # 主力大单净流入 (倍率:1e3, 参数:CashFlowPeriod)
    CASH_FLOW_NET_IN_COUNT = 5902       # 整体净流入次数 (参数:CashFlowPeriod)
    CASH_FLOW_NET_OUT_COUNT = 5903      # 整体净流出次数 (参数:CashFlowPeriod)
    CASH_FLOW_MAIN_IN_COUNT = 5904      # 主力大单净流入次数 (参数:CashFlowPeriod)
    CASH_FLOW_MAIN_OUT_COUNT = 5905     # 主力大单净流出次数 (参数:CashFlowPeriod)
    HK_CONNECT_NET_IN = 5906            # 港股通净流入 (倍率:1e3, 参数:CashFlowPeriod)
    HK_CONNECT_NET_IN_COUNT = 5907      # 港股通净流入次数 (仅日维度)
    HK_CONNECT_NET_OUT_COUNT = 5908     # 港股通净流出次数 (仅日维度)


# ============================================================
#  Broker — 经纪商持股
# ============================================================

class BrokerProperty(IntEnum):
    """经纪商持股 (add_broker_holdings 的 name 参数)"""
    CONCENTRATED_DISTRIBUTION = 6101    # 持仓分布集中度 (倍率:1e5)
    HOLDINGS_CHANGE = 6102              # 持仓经纪商变动 (倍率:1e5)
    BROKER_NUM = 6103                   # 持仓经纪商数量 (倍率:1)
    BROKER_RANK = 6104                  # 经纪商排行 (倍率:1)
    HOLDINGS_RATIO = 6105               # 经纪商持仓量占比 (倍率:1e5)
    CENTRAL_HOLDINGS_RATIO = 6106       # 中央结算持股占比 (倍率:1e5)
    CENTRAL_HOLDINGS_CHANGE = 6107      # 中央结算持股变动 (倍率:1e5)


# ============================================================
#  KlineShape — K线形态指标
# ============================================================

class KlineShapeProperty(IntEnum):
    """K线形态指标 (add_kline_shape 的 name 参数)"""
    SHAPE_TYPE = 6200           # K线形态 (倍率:1)
    RISE_PROB = 6201            # 上涨/下跌概率 (倍率:1e5)
    AFTER_SELECTED_CHG = 6202   # 入选后涨跌幅 (倍率:1e5)
    SELECTED_TIME = 6203        # 入选时间 (倍率:1)
    SUPPORT_LEVEL = 6204        # 支撑位 (倍率:1e9)
    PRESSURE_LEVEL = 6205       # 压力位 (倍率:1e9)


class KlineShapeType(IntEnum):
    """K线形态类型 (add_kline_shape 的 value_set 参数值)

    名字对齐后端 proto stock_screener_common.KlineShapeType, 与 OpenD 直发的 enum_name 一致。
    """
    NONE = 0
    # --- 上涨形态 ---
    DOUBLE_BOTTOMS = 1               # W型底
    TRIPLE_BOTTOMS = 2               # 三重底
    HEAD_SHOULDERS_BOTTOM = 3        # 头肩底
    CUP_BOTTOM = 4                   # 圆弧底
    TRUMPET_BOTTOM = 5               # 喇叭底
    FLAG = 6                         # 看涨旗形
    SYMMETRY_TRIANGLE = 7            # 看涨对称三角形
    SUSTAINABLE_RHOMBUS = 8          # 看涨持续菱形
    WEDGE = 9                        # 看涨持续楔形
    SUSTAINABLE_TRIANGLE = 10        # 看涨持续三角形
    # --- 下跌形态 ---
    DOUBLE_PEAKS = 1001              # M型顶
    TRIPLE_PEAKS = 1002              # 三重顶
    HEAD_SHOULDERS_PEAK = 1003       # 头肩顶
    CUP_PEAK = 1004                  # 圆弧顶
    TRUMPET_PEAK = 1005              # 喇叭顶
    FLAG_DOWN = 1006                 # 看跌旗形
    SYMMETRY_TRIANGLE_DOWN = 1007    # 看跌对称三角形
    SUSTAINABLE_RHOMBUS_DOWN = 1008  # 看跌持续菱形
    WEDGE_DOWN = 1009                # 看跌持续楔形
    SUSTAINABLE_TRIANGLE_DOWN = 1010 # 看跌持续三角形
    # --- 形态大类 ---
    BULLISH_TYPE = 2000              # 看涨形态
    BEARISH_TYPE = 2001              # 看跌形态


# ============================================================
#  Option — 期权指标
# ============================================================

class OptionProperty(IntEnum):
    """期权指标 (add_option 的 name 参数)"""
    STOCK_IV = 1000                 # 正股IV (倍率:1e6)
    STOCK_IV_RANK = 1001            # 正股IV排名 (倍率:1e6)
    STOCK_IV_PERCENTILE = 1002      # 正股IV百分位 (倍率:1e6)
    STOCK_EARNINGS_IV_CRUSH = 1003  # 财报发布日IV (倍率:1e6, 带财报周期参数)
    STOCK_IV_CHG = 1004             # 正股IV涨跌 (倍率:1e6)
    STOCK_IV_CHG_RATIO = 1005       # 正股IV变化率 (倍率:1e6)
    STOCK_HV = 1006                 # 正股HV (倍率:1e6, 带周期参数)
    STOCK_IV_MINUS_HV = 1007        # IV-HV (倍率:1e6, 默认30天)
    STOCK_IV_DIV_HV = 1008          # IV/HV (倍率:1e6, 默认30天)
    STOCK_OPTION_VOL = 1009         # 期权成交量 (倍率:1)
    STOCK_OPTION_OPEN_IN = 1010     # 期权总持仓 (倍率:1)


# ============================================================
#  WarrantScreen 枚举
# ============================================================

class WarrantMarket(IntEnum):
    """窝轮筛选市场 (WarrantScreenRequest 的 market 参数)"""
    HK = 1    # 港股
    SG = 4    # 新加坡
    MY = 15   # 马来西亚


class WarrantType(IntEnum):
    """窝轮类型"""
    CALL = 1    # 认购
    PUT = 2     # 认沽
    BULL = 3    # 牛证
    BEAR = 4    # 熊证
    IW = 5      # 界内证


class WarrantStatus(IntEnum):
    """窝轮状态 (用于 3254 WarrantField.STATUS 的 choice_filter, OpenD 负责与后端枚举映射)"""
    NORMAL = 0            # 正常
    STOP_TRADE = 1        # 终止交易
    PENDING_LISTING = 2   # 待上市


class WarrantField(IntEnum):
    """窝轮筛选字段 (add_interval_filter / add_choice_filter 的 field_id 参数)"""
    UNKNOWN = 0
    CODE = 1                    # 证券代码 (文本)
    NAME = 2                    # 股票名称 (文本)
    ISSUER_ID = 4               # 发行商ID
    STOCK_OWNER = 5             # 正股ID
    WARRANT_TYPE = 6            # 窝轮类型 (参考 WarrantType)
    CONVERSION_RATIO = 7        # 换股比率 (放大1e3)
    CURRENT_PRICE = 8           # 当前价 (放大1e3)
    STREET_RATIO = 9            # 街货占比 (放大1e3)
    VOLUME = 10                 # 成交量
    MATURITY_DATE = 11          # 到期日 (时间戳秒)
    STRIKE_PRICE = 12           # 行使价 (放大1e3)
    PREMIUM = 13                # 溢价 (放大1e5, 可为负)
    RECOVERY_PRICE = 14         # 收回价 (放大1e3)
    IMPLIED_VOLATILITY = 15     # 引伸波幅 (放大1e2)
    LEVERAGE_RATIO = 16         # 杠杆比率 (放大1e3)
    PRICE_RECOVERY_RATIO = 17   # 正股距收回价% (放大1e5)
    DELTA = 18                  # 对冲值 (放大1e3)
    STATUS = 19                 # 轮证状态
    IPO_TIME = 20               # 上市时间 (时间戳秒)
    BUY_VOL = 21                # 买量
    SELL_VOL = 22               # 卖量
    EFFECTIVE_LEVERAGE = 23     # 有效杠杆 (放大1e3)
    LAST_CLOSE_PRICE = 24       # 昨收价 (放大1e3)
    TURNOVER = 25               # 成交额
    SELL_PRICE = 26             # 卖价 (放大1e3)
    BUY_PRICE = 27              # 买价 (放大1e3)
    HIGH_PRICE = 28             # 最高价 (放大1e3)
    LOW_PRICE = 29              # 最低价 (放大1e3)
    RATIO_ITM_OTM = 30          # 价内/价外 (放大1e5, 可为负)
    BREAK_EVEN_POINT = 31       # 打和点 (放大1e5)
    AMPLITUDE = 32              # 振幅 (放大1e5)
    SCORE_FAXING = 33           # 法兴评分 (放大1e5)
    LAST_TRADE_DATE = 34        # 最后交易日 (时间戳秒)
    STREET_VOLUME = 35          # 街货量
    LOT_SIZE = 36               # 每手股数
    ISSUE_SIZE = 37             # 发行量
    IPO_PRICE = 38              # 发行价 (放大1e3)
    LOWER_STRIKE_PRICE = 39     # 下限价 (放大1e3)
    UPPER_STRIKE_PRICE = 40     # 上限价 (放大1e3)
    IW_PRICE_STATUS = 41        # 界内/界外
    SENSITIVITY = 42            # 敏感度 (放大1e3)
    CONVERSION_PRICE = 43       # 换股价
    CHANGE_RATE = 44            # 涨跌幅 (放大1e3)
    CHANGE_VALUE = 45           # 涨跌额
    SCORE = 51                  # Warrant评分 (放大1e5)
    FILTER_NO_TRADE = 52        # 过滤无成交窝轮 (0=不过滤, 1=过滤)
    CURRENCY_CODE = 53          # 币种
    STOCK_OWNER_PRICE = 54      # 正股价格 (放大1e3)


# ============================================================
#  OptionScreen 枚举 (ProtoID 3253)
# ============================================================

class OptMarketCategory(IntEnum):
    """期权市场品类 (OptionScreenRequest 的 market_categories 参数)"""
    US_STOCK = 0   # 美股股票期权
    US_INDEX = 1   # 美股指数期权
    US_FUTURE = 2  # 美股期货期权
    HK_STOCK = 3   # 港股股票期权
    HK_INDEX = 4   # 港股指数期权
    JP_STOCK = 5   # 日股股票期权
    JP_INDEX = 6   # 日股指数期权


class OptUnderlyingIndicator(IntEnum):
    """标的筛选因子 (add_underlying_filter 的 indicator_type 参数)"""
    UNKNOWN = 0
    # 标的基本信息 (确切值筛选)
    STOCK_LIST = 101       # 指定标的范围 (股票ID列表)
    PLATE = 103            # 【不支持】指定板块, 后端未实装, 传入会报错
    INDEX_LIST = 106       # 指定指数类型
    # 标的期权统计 (范围筛选)
    VOLUME = 201           # 总成交量
    OPEN_INTEREST = 202    # 总持仓量
    IV = 203               # 标的IV (精度1e5)
    HV = 204               # 标的HV (精度1e5)
    IV_RANK = 205          # IV Rank (精度1e5)
    IV_PERCENTILE = 206    # IV Percentile (精度1e5)
    IV_CHANGE = 207        # IV变化量 (精度1e5)
    IV_CHANGE_RATIO = 208  # IV变化率 (精度1e5)
    IV_HV_RATIO = 209      # IV/HV (精度1e5)
    IV_HV_SPREAD = 210     # IV-HV (精度1e5)
    # 行情指标 (范围筛选)
    MARKET_CAP = 401       # 标的市值 (精度1e3)
    STOCK_PRICE = 402      # 标的最新价 (精度1e9)
    CHANGE_RATIO = 403     # 涨跌幅 (精度1e5)


class OptIndicator(IntEnum):
    """期权筛选因子 (add_option_filter 的 indicator_type 参数)"""
    UNKNOWN = 0
    # 期权静态信息
    STRIKE_PRICE = 1001            # 行权价 (精度1e9)
    LEFT_DAY = 1002                # 距到期日天数
    OPTION_TYPE = 1003             # 期权类型 (1=CALL, 2=PUT)
    EXERCISE_TYPE = 1004           # 行权方式 (1=美式, 2=欧式)
    EXPIRATION_TYPE = 1005         # 到期类型 (1=周, 2=月, 3=季)
    STRIKE_DATE_TIMESTAMP = 1007   # 到期日时间戳(秒)
    # 期权实时行情
    IN_THE_MONEY = 2001            # 价内/价外 (0=价外, 1=价内)
    PRICE = 2002                   # 期权价格 (精度1e9)
    MID_PRICE = 2003               # 中间价 (精度1e9)
    BID_PRICE = 2004               # 买价 (精度1e9)
    ASK_PRICE = 2005               # 卖价 (精度1e9)
    BID_ASK_SPREAD = 2006          # 买卖价差 (精度1e9)
    BID_VOLUME = 2007              # 买量
    ASK_VOLUME = 2008              # 卖量
    BID_ASK_VOLUME_RATIO = 2009    # 买卖量比 (精度1e5)
    CHANGE_RATIO = 2010            # 涨跌幅 (精度1e5)
    VOLUME = 2011                  # 成交量
    TURNOVER = 2012                # 成交额 (精度1e3)
    OPEN_INTEREST = 2013           # 持仓量
    OPEN_INTEREST_MARKET_CAP = 2014  # 持仓市值 (精度1e3)
    VOL_OI_RATIO = 2018            # 成交量/持仓量 (精度1e5)
    PREMIUM = 2021                 # 权利金 【filter 不支持, 仅 sort/retrieve 可用】
    # 期权分析指标
    IMPLIED_VOLATILITY = 3001      # 隐含波动率 (精度1e5)
    HISTORY_VOLATILITY = 3002      # 历史波动率 (精度1e5)
    IV_HV_RATIO = 3003             # IV/HV (精度1e5)
    DELTA = 3004                   # Delta (精度1e5)
    GAMMA = 3005                   # Gamma (精度1e5)
    VEGA = 3006                    # Vega (精度1e5)
    THETA = 3007                   # Theta (精度1e5)
    RHO = 3008                     # Rho (精度1e5)
    LEVERAGE_RATIO = 3009          # 杠杆比率 (精度1e5)
    EFFECTIVE_GEARING = 3010       # 有效杠杆 (精度1e5)
    BUY_TO_BEP = 3011              # 买入到盈亏平衡点比率 (精度1e5)
    SELL_TO_BEP = 3012             # 卖出到盈亏平衡点比率 (精度1e5)
    BUY_PROFIT_PROBABILITY = 3013  # 买入盈利概率 (精度1e5)
    SELL_PROFIT_PROBABILITY = 3014 # 卖出盈利概率 (精度1e5)
    INTRINSIC_VALUE_PER = 3015     # 内在价值百分比 (精度1e5)
    TIME_VALUE_PER = 3016          # 时间价值百分比 (精度1e5)
    ITM_DEGREE = 3017              # 价内程度 (精度1e5)
    OTM_DEGREE = 3018              # 价外程度 (精度1e5)
    ITM_PROBABILITY = 3019         # 价内概率 (精度1e5)
    OTM_PROBABILITY = 3020         # 价外概率 (精度1e5)
    SELL_ANNUALIZED_RETURN = 3021  # 卖出年化收益率 (精度1e5)
    INTERVAL_RETURN = 3022         # 卖出区间收益率 (精度1e5)
    # 已废弃: 不支持 filter/sort/retrieve, 传入 OpenD 会返回错误。新代码请用 BUY_TO_BEP(3011)
    BUY_BREAK_EVEN_POINT = 3023    # 已废弃, 传入会报错


class OptSortDir(IntEnum):
    """期权排序方向 (add_sort 的 desc 参数对应 0=升序, 1=降序)"""
    ASC = 0    # 升序
    DESC = 1   # 降序
