# -*- coding: utf-8 -*-
"""
    Market quote and trade context setting
"""

import datetime
import math
from collections import OrderedDict
import pandas as pd
from ..common.open_context_base import OpenContextBase, ContextStatus
from ..common.network_manager import CloseReason
from .quote_query import *
from .quote_stockfilter_info import *
from .quote_option_event_info import *
from .quote_get_warrant import *

class SubRecord:
    def __init__(self):
        self.subMap = {}  # (subkey, is_orderbook_detail, extended_time, session) => code set

    def sub(self, code_list, subtype_list, is_orderbook_detail, extended_time, session):
        for subtype in subtype_list:
            keys_to_remove = []
            for key in list(self.subMap.keys()):
                if key[0] == subtype and (
                        key[1] != is_orderbook_detail or key[2] != extended_time or key[3] != session):
                    keys_to_remove.append(key)

            for key in keys_to_remove:
                code_set = self.subMap[key]
                for code in code_list:
                    code_set.discard(code)
                if len(code_set) == 0:
                    del self.subMap[key]

            for code in code_list:
                if (subtype, is_orderbook_detail, extended_time, session) not in self.subMap:
                    self.subMap[(subtype, is_orderbook_detail, extended_time, session)] = set()
                self.subMap[(subtype, is_orderbook_detail, extended_time, session)].add(code)

    def unsub(self, code_list, subtype_list):
        for subtype in subtype_list:
            for key in list(self.subMap.keys()):
                # 检查当前键的subType是否匹配
                if key[0] == subtype:
                    code_set = self.subMap[key]
                    for code in code_list:
                        code_set.discard(code)
                    if len(code_set) == 0:
                        del self.subMap[key]

    def unsub_all(self):
        self.subMap = {}

    def get_sub_list(self):
        """
        :return: [(code_list, subtype_list, is_orderbook_detail, extended_time,session)]
        """
        result = []
        temp_map = {}
        for key, code_set in self.subMap.items():
            code_list = list(code_set)
            subtype, is_orderbook_detail, extended_time, session = key
            unique_key = (tuple(code_list), is_orderbook_detail, extended_time, session)
            if unique_key not in temp_map:
                temp_map[unique_key] = {
                    'subtype_list': [subtype]
                }
            else:
                temp_map[unique_key]['subtype_list'].append(subtype)

        for (code_list, is_orderbook_detail, extended_time, session), value in temp_map.items():
            unique_subtype_list = list(set(value['subtype_list']))
            result.append((list(code_list), unique_subtype_list, is_orderbook_detail, extended_time, session))

        return result


class OpenQuoteContext(OpenContextBase):
    """行情上下文对象类"""

    def __init__(self, host='127.0.0.1', port=11111, is_encrypt=None, is_async_connect=False, security_firm=SecurityFirm.NONE, ai_type=0):
        """
        初始化Context对象
        :param host: host地址
        :param port: 端口
        :param is_encrypt: 是否加密
        :param is_async_connect: 是否异步连接
        :param security_firm: 券商标识，SecurityFirm枚举值
        :param ai_type: AI类型，默认为0
        """
        if not SecurityFirm.if_has_key(security_firm):
            raise ValueError("Invalid SecurityFirm value. Use allowed enum value (e.g., FUTUSECURITIES, FUTUINC, FUTUSG).")
        self._ctx_subscribe = {}
        self._sub_record = SubRecord()
        self.__security_firm = security_firm
        super(OpenQuoteContext, self).__init__(
            host, port, is_encrypt=is_encrypt, is_async_connect=is_async_connect, ai_type=ai_type)

    def get_security_firm(self):
        """获取券商标识"""
        return self.__security_firm

    def close(self, reason=CloseReason.Close):
        """
        关闭上下文对象。

        .. code:: python

            from futu import *
            quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
            quote_ctx.close()
        """
        super(OpenQuoteContext, self).close(reason=reason)

    def on_api_socket_reconnected(self):
        """for API socket reconnected"""
        # auto subscriber
        with self._lock:
            sub_list = self._sub_record.get_sub_list()

        ret_code = RET_OK
        ret_msg = ''
        for code_list, subtype_list, is_detailed_orderbook, extended_time, session in sub_list:
            ret_code, ret_msg = self._reconnect_subscribe(
                code_list, subtype_list, is_detailed_orderbook, extended_time, session)
            logger.debug("reconnect subscribe code_count={} ret_code={} ret_msg={} subtype_list={} code_list={} is_detailed_orderbook={} extended_time={} session={}".format(
                len(code_list), ret_code, ret_msg, subtype_list, code_list, is_detailed_orderbook, extended_time, session))
            if ret_code != RET_OK:
                break

        # 重定阅失败，重连
        if ret_code != RET_OK:
            logger.error(
                "reconnect subscribe error, close connect and retry!!")

        return ret_code, ret_msg

    def request_trading_days(self, market=None, start=None, end=None, code=None):
        # 注：当 market 和 code 同时存在时，会忽略 market，仅对 code 进行查询。
        """获取交易日
        :param market: 市场类型，Qot_Common.TradeDateMarket
        :param start: 起始日期。例如'2020-04-01'。
        :param end: 结束日期。例如'2020-04-10'。
        :param code: 股票代码。例如'HK.00700'，'US.APPL'。
         start和end的组合如下：
         ==========    ==========    ========================================
         start类型      end类型       说明
         ==========    ==========    ========================================
         str            str           start和end分别为指定的日期
         None           str           start为end往前365天
         str            None          end为start往后365天
         None           None          end为当前日期，start为end往前365天
         ==========    ==========    ========================================
        :return: 成功时返回(RET_OK, data)，data是[{'time': '2020-04-01', 'trade_date_type': 'WHOLE'}]数组；失败时返回(RET_ERROR, data)，其中data是错误描述字符串
        """
        if market is None:
            market = TradeDateMarket.NONE  # 当market入参是空，设置为TradeDateMarket.NONE
        if is_str(market) is False:
            error_str = ERROR_STR_PREFIX + "the type of market param is wrong"
            return RET_ERROR, error_str

        ret, msg, start, end = normalize_start_end_date(start, end, 365)
        if ret != RET_OK:
            return ret, msg

        if code is not None and is_str(code) is False:
            error_str = ERROR_STR_PREFIX + "the type of code is wrong"
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            RequestTradeDayQuery.pack_req, RequestTradeDayQuery.unpack_rsp)

        # the keys of kargs should be corresponding to the actual function arguments
        kargs = {
            'market': market,
            'start_date': start,
            'end_date': end,
            'conn_id': self.get_sync_conn_id(),
            'code': code,
            'security_firm': self.__security_firm
        }
        ret_code, msg, trade_day_list = query_processor(**kargs)

        if ret_code != RET_OK:
            return RET_ERROR, msg

        return RET_OK, trade_day_list

    def get_stock_basicinfo(self, market, stock_type=SecurityType.STOCK, code_list=None):
        """
        获取指定市场中特定类型的股票基本信息
        注：当 market 和 code_list 同时存在时，会忽略 market，仅对 code_list 进行查询。
        :param market: 市场类型，futu.common.constant.Market
        :param stock_type: 股票类型， futu.common.constant.SecurityType
        :param code_list: 如果不为None，应该是股票code的iterable类型，将只返回指定的股票信息
        :return: (ret_code, content)
                ret_code 等于RET_OK时， content为Pandas.DataFrame数据, 否则为错误原因字符串, 数据列格式如下
            =================   ===========   ==========================================================================
            参数                  类型                        说明
            =================   ===========   ==========================================================================
            code                str            股票代码
            name                str            名字
            lot_size            int            每手数量
            stock_type          str            股票类型，参见SecurityType
            stock_child_type    str            窝轮子类型，参见WrtType
            stock_owner         str            所属正股的代码
            option_type         str            期权类型，Qot_Common.OptionType
            strike_time         str            行权日
            strike_price        float          行权价
            suspension          bool           是否停牌(True表示停牌)
            listing_date        str            上市时间
            stock_id            int            股票id
            delisting           bool           是否退市
            index_option_type   str            指数期权类型（期权特有字段）
            main_contract       bool           是否主连合约（期货特有字段）
            last_trade_time     string         最后交易时间（期货特有字段，非主连期货合约才有值）
            exchange_type       str            所属交易所，Qot_Common.ExchType
            =================   ===========   ==========================================================================

        :example:

            .. code-block:: python

            from futu import *
            quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
            print(quote_ctx.get_stock_basicinfo(Market.HK, SecurityType.WARRANT))
            print(quote_ctx.get_stock_basicinfo(Market.US, SecurityType.DRVT, 'US.AAPL210115C185000'))
            quote_ctx.close()
        """
        if code_list is None:
            param_table = {'market': market, 'stock_type': stock_type}
            for x in param_table:
                param = param_table[x]
                if param is None or is_str(param) is False:
                    error_str = ERROR_STR_PREFIX + "the type of %s param is wrong" % x
                    return RET_ERROR, error_str
        else:
            if is_str(code_list):
                code_list = code_list.split(',')
            elif isinstance(code_list, list):
                pass
            else:
                return RET_ERROR, "code list must be like ['HK.00001', 'HK.00700'] or 'HK.00001,HK.00700'"

        code_list = unique_and_normalize_list(code_list)   # 去重

        query_processor = self._get_sync_query_processor(
            StockBasicInfoQuery.pack_req, StockBasicInfoQuery.unpack_rsp)
        kargs = {
            "market": market,
            'stock_type': stock_type,
            'code_list': code_list,
            'conn_id': self.get_sync_conn_id(),
            'security_firm': self.__security_firm
        }

        ret_code, msg, basic_info_list = query_processor(**kargs)
        if ret_code != RET_OK:
            return ret_code, msg

        col_list = [
            'code', 'name', 'lot_size', 'stock_type', 'stock_child_type', 'stock_owner',
            'option_type', 'strike_time', 'strike_price', 'suspension',
            'listing_date', 'stock_id', 'delisting', 'index_option_type',
            'main_contract', 'last_trade_time', 'exchange_type'
        ]

        basic_info_table = pd.DataFrame(basic_info_list, columns=col_list)

        return RET_OK, basic_info_table

    def request_history_kline(self,
                              code,
                              start=None,
                              end=None,
                              ktype=KLType.K_DAY,
                              autype=AuType.QFQ,
                              fields=[KL_FIELD.ALL],
                              max_count=1000,
                              page_req_key=None,
                              extended_time=False,
                              session = Session.NONE):
        """
        拉取历史k线，不需要先下载历史数据。

        :param code: 股票代码
        :param start: 开始时间，例如'2017-06-20'
        :param end:  结束时间，例如'2017-07-20'。
                  start和end的组合如下：
                     ==========    ==========    ========================================
                     start类型      end类型       说明
                     ==========    ==========    ========================================
                     str            str           start和end分别为指定的日期
                     None           str           start为end往前365天
                     str            None          end为start往后365天
                     None           None          end为当前日期，start为end往前365天
                     ==========    ==========    ========================================
        :param ktype: k线类型， 参见 KLType 定义
        :param autype: 复权类型, 参见 AuType 定义
        :param fields: 需返回的字段列表，参见 KL_FIELD 定义 KL_FIELD.ALL  KL_FIELD.OPEN ....
        :param max_count: 本次请求最大返回的数据点个数，传None表示返回start和end之间所有的数据。
        :param page_req_key: 分页请求的key。如果start和end之间的数据点多于max_count，那么后续请求时，要传入上次调用返回的page_req_key。初始请求时应该传None。
        :return: (ret, data, page_req_key)

                ret == RET_OK 返回pd dataframe数据，data.DataFrame数据, 数据列格式如下。page_req_key在分页请求时（即max_count>0）
                可能返回，并且需要在后续的请求中传入。如果没有更多数据，page_req_key返回None。

                ret != RET_OK 返回错误字符串

            =================   ===========   ==============================================================================
            参数                  类型                        说明
            =================   ===========   ==============================================================================
            code                str            股票代码
            time_key            str            k线时间
            open                float          开盘价
            close               float          收盘价
            high                float          最高价
            low                 float          最低价
            pe_ratio            float          市盈率（该字段为比例字段，默认不展示%）
            turnover_rate       float          换手率
            volume              int            成交量
            turnover            float          成交额
            change_rate         float          涨跌幅
            last_close          float          昨收价
            =================   ===========   ==============================================================================

        :note

        :example:

        .. code:: python

            from futu import *
            quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
            ret, data, page_req_key = quote_ctx.request_history_kline('HK.00700', start='2017-06-20', end='2018-06-22', max_count=50)
            print(ret, data)
            ret, data, page_req_key = quote_ctx.request_history_kline('HK.00700', start='2017-06-20', end='2018-06-22', max_count=50, page_req_key=page_req_key)
            print(ret, data)
            quote_ctx.close()
        """
        next_page_req_key = None
        ret, msg, req_start, end = normalize_start_end_date(start, end, 365)
        if ret != RET_OK:
            return ret, msg, next_page_req_key

        req_fields = unique_and_normalize_list(fields)
        if not fields:
            req_fields = copy(KL_FIELD.ALL_REAL)
        req_fields = KL_FIELD.normalize_field_list(req_fields)
        if not req_fields:
            error_str = ERROR_STR_PREFIX + "the type of fields param is wrong"
            return RET_ERROR, error_str, next_page_req_key

        if autype is None:
            autype = 'None'

        param_table = {'code': code, 'ktype': ktype, 'autype': autype}
        for x in param_table:
            param = param_table[x]
            if param is None or is_str(param) is False:
                error_str = ERROR_STR_PREFIX + "the type of %s param is wrong" % x
                return RET_ERROR, error_str, next_page_req_key

        max_kl_num = min(1000, max_count) if max_count is not None else 1000
        data_finish = False
        list_ret = []
        # 循环请求数据，避免一次性取太多超时
        while not data_finish:
            kargs = {
                "code": code,
                "start_date": req_start,
                "end_date": end,
                "ktype": ktype,
                "autype": autype,
                "fields": copy(req_fields),
                "max_num": max_kl_num,
                "conn_id": self.get_sync_conn_id(),
                "next_req_key": page_req_key,
                "extended_time": extended_time,
                "session":session,
                "security_firm": self.__security_firm
            }
            query_processor = self._get_sync_query_processor(RequestHistoryKlineQuery.pack_req,
                                                             RequestHistoryKlineQuery.unpack_rsp)
            ret_code, msg, content = query_processor(**kargs)
            if ret_code != RET_OK:
                return ret_code, msg, next_page_req_key

            list_kline, has_next, page_req_key = content
            list_ret.extend(list_kline)
            next_page_req_key = page_req_key
            if max_count is not None:
                if max_count > len(list_ret) and has_next:
                    data_finish = False
                    max_kl_num = min(max_count - len(list_ret), 1000)
                else:
                    data_finish = True
            else:
                data_finish = not has_next

        # 表头列
        col_list = ['code', 'name']
        for field in req_fields:
            str_field = KL_FIELD.DICT_KL_FIELD_STR[field]
            if str_field not in col_list:
                col_list.append(str_field)

        kline_frame_table = pd.DataFrame(list_ret, columns=col_list)

        return RET_OK, kline_frame_table, next_page_req_key


    def get_market_snapshot(self, code_list):
        """
        获取市场快照

        :param code_list: 股票列表
        :return: (ret, data)

                ret == RET_OK 返回pd dataframe数据，data.DataFrame数据, 数据列格式如下

                ret != RET_OK 返回错误字符串

                =======================   =============   ==============================================================================
                参数                       类型                        说明
                =======================   =============   ==============================================================================
                code                       str            股票代码
                update_time                str            更新时间(yyyy-MM-dd HH:mm:ss)，（美股默认是美东时间，港股A股默认是北京时间）
                last_price                 float          最新价格
                open_price                 float          今日开盘价
                high_price                 float          最高价格
                low_price                  float          最低价格
                prev_close_price           float          昨收盘价格
                volume                     int            成交数量
                turnover                   float          成交金额
                turnover_rate              float          换手率
                suspension                 bool           是否停牌(True表示停牌)
                listing_date               str            上市日期 (yyyy-MM-dd)
                equity_valid               bool           是否正股（为true时以下正股相关字段才有合法数值）
                issued_shares              int            发行股本
                total_market_val           float          总市值
                net_asset                  int            资产净值
                net_profit                 int            净利润
                earning_per_share          float          每股盈利
                outstanding_shares         int            流通股本
                net_asset_per_share        float          每股净资产
                circular_market_val        float          流通市值
                ey_ratio                   float          收益率（该字段为比例字段，默认不展示%）
                pe_ratio                   float          市盈率（该字段为比例字段，默认不展示%）
                pb_ratio                   float          市净率（该字段为比例字段，默认不展示%）
                pe_ttm_ratio               float          市盈率TTM（该字段为比例字段，默认不展示%）
                dividend_ttm               float          股息TTM
                dividend_ratio_ttm         float          股息率TTM（该字段为百分比字段，默认不展示%）
                dividend_lfy               float          股息LFY，上一年度派息
                dividend_lfy_ratio         float          股息率LFY（该字段为百分比字段，默认不展示
                stock_owner                str            窝轮所属正股的代码或期权的标的股代码
                wrt_valid                  bool           是否是窝轮（为true时以下窝轮相关的字段才有合法数据）
                wrt_conversion_ratio       float          换股比率（该字段为比例字段，默认不展示%）
                wrt_type                   str            窝轮类型，参见WrtType
                wrt_strike_price           float          行使价格
                wrt_maturity_date          str            格式化窝轮到期时间
                wrt_end_trade              str            格式化窝轮最后交易时间
                wrt_code                   str            窝轮对应的正股（此字段已废除,修改为stock_owner）
                wrt_recovery_price         float          窝轮回收价
                wrt_street_vol             float          窝轮街货量
                wrt_issue_vol              float          窝轮发行量
                wrt_street_ratio           float          窝轮街货占比（该字段为比例字段，默认不展示%）
                wrt_delta                  float          窝轮对冲值
                wrt_implied_volatility     float          窝轮引伸波幅
                wrt_premium                float          窝轮溢价
                wrt_leverage               float          杠杆比率（倍）
                wrt_ipop                   float          价内/价外（该字段为百分比字段，默认不展示%）
                wrt_break_even_point       float          打和点
                wrt_conversion_price       float          换股价
                wrt_price_recovery_ratio   float          距收回价（该字段为百分比字段，默认不展示%）
                wrt_score                  float          综合评分
                wrt_upper_strike_price     float          上限价，仅界内证支持该字段
                wrt_lower_strike_price     float          下限价，仅界内证支持该字段
                wrt_inline_price_status    str            界内界外，仅界内证支持该字段，参见PriceType
                lot_size                   int            每手股数
                price_spread               float          当前摆盘价差亦即摆盘数据的买档或卖档的相邻档位的报价差
                ask_price                  float          卖价
                bid_price                  float          买价
                ask_vol                    float          卖量
                bid_vol                    float          买量
                enable_margin              bool           是否可融资，如果为true，后两个字段才有意义
                mortgage_ratio             float          股票抵押率（该字段为百分比字段，默认不展示%）
                long_margin_initial_ratio  float          融资初始保证金率（该字段为百分比字段，默认不展示%）
                enable_short_sell          bool           是否可卖空，如果为true，后三个字段才有意义
                short_sell_rate            float          卖空参考利率（该字段为百分比字段，默认不展示%）
                short_available_volume     int            剩余可卖空数量
                short_margin_initial_ratio float          卖空（融券）初始保证金率（该字段为百分比字段，默认不展示%
                amplitude                  float          振幅（该字段为百分比字段，默认不展示%）
                avg_price                  float          平均价
                bid_ask_ratio              float          委比（该字段为百分比字段，默认不展示%）
                volume_ratio               float          量比
                highest52weeks_price       float          52周最高价
                lowest52weeks_price        float          52周最低价
                highest_history_price      float          历史最高价
                lowest_history_price       float          历史最低价
                option_valid               bool           是否是期权（为true时以下期权相关的字段才有合法数值）
                option_type                str            期权类型，参见OptionType
                strike_time                str            行权日（美股默认是美东时间，港股A股默认是北京时间）
                option_strike_price        float          行权价
                option_contract_size       int            每份合约数
                option_open_interest       int            未平仓合约数
                option_implied_volatility  float          隐含波动率
                option_premium             float          溢价
                option_delta               float          希腊值 Delta
                option_gamma               float          希腊值 Gamma
                option_vega                float          希腊值 Vega
                option_theta               float          希腊值 Theta
                option_rho                 float          希腊值 Rho
                option_net_open_interest   int            净未平仓合约数
                option_expiry_date_distance    int        距离到期日天数
                option_contract_nominal_value  float      合约名义金额
                option_owner_lot_multiplier    float      相等正股手数，指数期权无该字段
                option_area_type           str            期权地区类型，见 OptionAreaType_
                option_contract_multiplier float          合约乘数，指数期权特有字段
                index_option_type          str            指数期权类型，见 IndexOptionType
                index_raise_count          int            指数类型上涨支数
                index_fall_count           int            指数类型下跌支数
                index_requal_count         int            指数类型平盘支数
                plate_raise_count          int            板块类型上涨支数
                plate_fall_count           int            板块类型下跌支数
                plate_equal_count          int            板块类型平盘支数
                after_volume               int            盘后成交量
                after_turnover             double         盘后成交额
                sec_status                 str            股票状态， 参见SecurityStatus
                future_valid               bool           是否期货
                future_last_settle_price   float          昨结
                future_position            float          持仓量
                future_position_change     float          日增仓
                future_main_contract       bool           是否主连合约
                future_last_trade_time     string         只有非主连期货合约才有该字段
                trust_valid                bool           是否基金
                trust_dividend_yield       float          股息率
                trust_aum                  float          资产规模
                trust_outstanding_units    int            总发行量
                trust_netAssetValue        float          单位净值
                trust_premium              float          溢价
                trust_assetClass           string         资产类别
                =======================   =============   ==============================================================================
        """
        code_list = unique_and_normalize_list(code_list)
        if not code_list:
            error_str = ERROR_STR_PREFIX + "the type of code param is wrong"
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            MarketSnapshotQuery.pack_req, MarketSnapshotQuery.unpack_rsp)
        kargs = {
            "stock_list": code_list,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }

        ret_code, msg, snapshot_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        equity_col_list = ['issued_shares',
                           'total_market_val',
                           'net_asset',
                           'net_profit',
                           'earning_per_share',
                           'outstanding_shares',
                           'circular_market_val',
                           'net_asset_per_share',
                           'ey_ratio',
                           'pe_ratio',
                           'pb_ratio',
                           'pe_ttm_ratio',
                           'dividend_ttm',
                           'dividend_ratio_ttm',
                           'dividend_lfy',
                           'dividend_lfy_ratio'
                           ]
        wrt_col_list = ['wrt_conversion_ratio',
                        'wrt_type',
                        'wrt_strike_price',
                        'wrt_maturity_date',
                        'wrt_end_trade',
                        'wrt_recovery_price',
                        'wrt_street_vol',
                        'wrt_issue_vol',
                        'wrt_street_ratio',
                        'wrt_delta',
                        'wrt_implied_volatility',
                        'wrt_premium',
                        'wrt_leverage',
                        'wrt_ipop',
                        'wrt_break_even_point',
                        'wrt_conversion_price',
                        'wrt_price_recovery_ratio',
                        'wrt_score',
                        'wrt_upper_strike_price',
                        'wrt_lower_strike_price',
                        'wrt_inline_price_status',
                        'wrt_issuer_code'
                        ]
        option_col_list = ['option_type',
                           'strike_time',
                           'option_strike_price',
                           'option_contract_size',
                           'option_open_interest',
                           'option_implied_volatility',
                           'option_premium',
                           'option_delta',
                           'option_gamma',
                           'option_vega',
                           'option_theta',
                           'option_rho',
                           'option_net_open_interest',
                           'option_expiry_date_distance',
                           'option_contract_nominal_value',
                           'option_owner_lot_multiplier',
                           'option_area_type',
                           'option_contract_multiplier',
                           'index_option_type'
                           ]

        index_col_list = ['index_raise_count',
                          'index_fall_count',
                          'index_equal_count'
                          ]

        plate_col_list = ['plate_raise_count',
                          'plate_fall_count',
                          'plate_equal_count'
                          ]

        future_col_list = ['future_last_settle_price',
                           'future_position',
                           'future_position_change',
                           'future_main_contract',
                           'future_last_trade_time',
                         ]

        trust_col_list = ['trust_dividend_yield',
                          'trust_aum',
                          'trust_outstanding_units',
                          'trust_netAssetValue',
                          'trust_premium',
                          'trust_assetClass',
                        ]

        col_list = [
            'code',
            'name',
            'update_time',
            'last_price',
            'open_price',
            'high_price',
            'low_price',
            'prev_close_price',
            'volume',
            'turnover',
            'turnover_rate',
            'suspension',
            'listing_date',
            'lot_size',
            'price_spread',
            'stock_owner',
            'ask_price',
            'bid_price',
            'ask_vol',
            'bid_vol',
            'enable_margin',
            'mortgage_ratio',
            'long_margin_initial_ratio',
            'enable_short_sell',
            'short_sell_rate',
            'short_available_volume',
            'short_margin_initial_ratio',
            'amplitude',
            'avg_price',
            'bid_ask_ratio',
            'volume_ratio',
            'highest52weeks_price',
            'lowest52weeks_price',
            'highest_history_price',
            'lowest_history_price',
            'close_price_5min',
            'after_volume',
            'after_turnover',
            'sec_status',
        ]

        col_dict = OrderedDict()
        col_dict.update((key, 1) for key in col_list)
        col_dict['equity_valid'] = 1
        col_dict.update((key, 1) for key in equity_col_list)
        col_dict['wrt_valid'] = 1
        col_dict.update((key, 1) for key in wrt_col_list)
        col_dict['option_valid'] = 1
        col_dict.update((key, 1) for key in option_col_list)
        col_dict['index_valid'] = 1
        col_dict.update((key, 1) for key in index_col_list)
        col_dict['plate_valid'] = 1
        col_dict.update((key, 1) for key in plate_col_list)
        col_dict['future_valid'] = 1
        col_dict.update((key, 1) for key in future_col_list)
        col_dict['trust_valid'] = 1
        col_dict.update((key, 1) for key in trust_col_list)

        col_dict.update((row[0], 1) for row in pb_field_map_PreAfterMarketData_pre)
        col_dict.update((row[0], 1) for row in pb_field_map_PreAfterMarketData_after)
        col_dict.update((row[0], 1) for row in pb_field_map_PreAfterMarketData_overnight)

        snapshot_frame_table = pd.DataFrame(snapshot_list, columns=col_dict.keys())

        return RET_OK, snapshot_frame_table

    def get_rt_data(self, code):
        """
        获取指定股票的分时数据

        :param code: 股票代码，例如，HK.00700，US.APPL
        :return: (ret, data)

                ret == RET_OK 返回pd dataframe数据，data.DataFrame数据, 数据列格式如下

                ret != RET_OK 返回错误字符串

                =====================   ===========   ==========================================================================
                参数                      类型                        说明
                =====================   ===========   ==========================================================================
                code                    str            股票代码
                time                    str            时间(yyyy-MM-dd HH:mm:ss)（美股默认是美东时间，港股A股默认是北京时间）
                is_blank                bool           数据状态；正常数据为False，伪造数据为True
                opened_mins             int            零点到当前多少分钟
                cur_price               float          当前价格
                last_close              float          昨天收盘的价格
                avg_price               float          平均价格
                volume                  float          成交量
                turnover                float          成交金额
                =====================   ===========   ==========================================================================
        """
        if code is None or is_str(code) is False:
            error_str = ERROR_STR_PREFIX + "the type of param in code is wrong"
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            RtDataQuery.pack_req, RtDataQuery.unpack_rsp)
        kargs = {
            "code": code,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }

        ret_code, msg, rt_data_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        for x in rt_data_list:
            x['code'] = code

        col_list = [
            'code', 'name', 'time', 'is_blank', 'opened_mins', 'cur_price',
            'last_close', 'avg_price', 'volume', 'turnover'
        ]

        rt_data_table = pd.DataFrame(rt_data_list, columns=col_list)

        return RET_OK, rt_data_table

    def get_plate_list(self, market, plate_class):
        """
        获取板块集合下的子板块列表

        :param market: 市场标识，注意这里不区分沪，深,输入沪或者深都会返回沪深市场的子板块（这个是和客户端保持一致的）参见Market
        :param plate_class: 板块分类，参见Plate
        :return: ret == RET_OK 返回pd dataframe数据，data.DataFrame数据, 数据列格式如下

                ret != RET_OK 返回错误字符串

                =====================   ===========   ==============================================================
                参数                      类型                        说明
                =====================   ===========   ==============================================================
                code                    str            股票代码
                plate_name              str            板块名字
                plate_id                str            板块id
                =====================   ===========   ==============================================================
        """
        param_table = {'market': market, 'plate_class': plate_class}
        for x in param_table:
            param = param_table[x]
            if param is None or is_str(market) is False:
                error_str = ERROR_STR_PREFIX + "the type of market param is wrong"
                return RET_ERROR, error_str

        if not Market.if_has_key(market):
            error_str = ERROR_STR_PREFIX + "the value of market param is wrong "
            return RET_ERROR, error_str

        if not Plate.if_has_key(plate_class):
            error_str = ERROR_STR_PREFIX + "the class of plate is wrong"
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            SubplateQuery.pack_req, SubplateQuery.unpack_rsp)
        kargs = {
            'market': market,
            'plate_class': plate_class,
            'conn_id': self.get_sync_conn_id(),
            'security_firm': self.__security_firm
        }

        ret_code, msg, subplate_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = ['code', 'plate_name', 'plate_id']

        subplate_frame_table = pd.DataFrame(subplate_list, columns=col_list)

        return RET_OK, subplate_frame_table

    def get_plate_stock(self, plate_code, sort_field=SortField.CODE, ascend=True):
        """
        获取特定板块下的股票列表

        :param plate_code: 板块代码, string, 例如，”SH.BK0001”，”SH.BK0002”，先利用获取子版块列表函数获取子版块代码
        :param sort_field: 排序字段，string
        :param ascend: 排序方向，string，True升序，False降序
        :return: (ret, data)

                ret == RET_OK 返回pd dataframe数据，data.DataFrame数据, 数据列格式如下

                ret != RET_OK 返回错误字符串

                =====================   ===========   ==============================================================
                参数                      类型                        说明
                =====================   ===========   ==============================================================
                code                    str            股票代码
                lot_size                int            每手股数
                stock_name              str            股票名称
                stock_owner             str            所属正股的代码
                stock_child_type        str            股票子类型，参见WrtType
                stock_type              str            股票类型，参见SecurityType
                list_time               str            上市时间（美股默认是美东时间，港股A股默认是北京时间）
                stock_id                int            股票id
                main_contract           bool           是否主连合约（期货特有字段）
                last_trade_time         string         最后交易时间（期货特有字段，非主连期货合约才有值）
                =====================   ===========   ==============================================================
        """
        if plate_code is None or is_str(plate_code) is False:
            error_str = ERROR_STR_PREFIX + "the type of code is wrong"
            return RET_ERROR, error_str

        r, v = SortField.to_number(sort_field)
        if (not r):
            error_str = ERROR_STR_PREFIX + "the type of sort field is wrong"
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            PlateStockQuery.pack_req, PlateStockQuery.unpack_rsp)
        kargs = {
            "plate_code": plate_code,
            "sort_field": sort_field,
            "ascend": ascend,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }

        ret_code, msg, plate_stock_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = [
            'code', 'lot_size', 'stock_name', 'stock_owner',
            'stock_child_type', 'stock_type', 'list_time', 'stock_id',
            'main_contract', 'last_trade_time'
        ]
        plate_stock_table = pd.DataFrame(plate_stock_list, columns=col_list)

        return RET_OK, plate_stock_table

    def get_broker_queue(self, code):
        """
        获取股票的经纪队列

        :param code: 股票代码
        :return: (ret, bid_frame_table, ask_frame_table)或(ret, err_message)

                ret == RET_OK 返回pd dataframe数据，数据列格式如下

                ret != RET_OK 后面两项为错误字符串

                bid_frame_table 经纪买盘数据

                =====================   ===========   ==============================================================
                参数                      类型                        说明
                =====================   ===========   ==============================================================
                code                    str             股票代码
                bid_broker_id           int             经纪买盘id
                bid_broker_name         str             经纪买盘名称
                bid_broker_pos          int             经纪档位
                order_id                int64           交易所订单id，与交易接口返回的订单id并不一样
                order_volume            int64           订单股数
                =====================   ===========   ==============================================================

                ask_frame_table 经纪卖盘数据

                =====================   ===========   ==============================================================
                参数                      类型                        说明
                =====================   ===========   ==============================================================
                code                    str             股票代码
                ask_broker_id           int             经纪卖盘id
                ask_broker_name         str             经纪卖盘名称
                ask_broker_pos          int             经纪档位
                order_id                int64           交易所订单id，与交易接口返回的订单id并不一样
                order_volume            int64           订单股数
                =====================   ===========   ==============================================================
        """
        if code is None or is_str(code) is False:
            error_str = ERROR_STR_PREFIX + "the type of param in code is wrong"
            return RET_ERROR, error_str, error_str

        query_processor = self._get_sync_query_processor(
            BrokerQueueQuery.pack_req, BrokerQueueQuery.unpack_rsp)
        kargs = {
            "code": code,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }

        ret_code, ret_msg, content = query_processor(**kargs)
        if ret_code != RET_OK:
            return ret_code, ret_msg, ret_msg

        (_, bid_list, ask_list) = content
        col_bid_list = [
            'code', 'name', 'bid_broker_id', 'bid_broker_name', 'bid_broker_pos', 'order_id', 'order_volume'
        ]
        col_ask_list = [
            'code', 'name', 'ask_broker_id', 'ask_broker_name', 'ask_broker_pos', 'order_id', 'order_volume'
        ]

        bid_frame_table = pd.DataFrame(bid_list, columns=col_bid_list)
        ask_frame_table = pd.DataFrame(ask_list, columns=col_ask_list)
        return RET_OK, bid_frame_table, ask_frame_table

    def _check_subscribe_param(self, code_list, subtype_list):

        code_list = unique_and_normalize_list(code_list)
        subtype_list = unique_and_normalize_list(subtype_list)

        if len(code_list) == 0:
            msg = ERROR_STR_PREFIX + 'code_list is null'
            return RET_ERROR, msg, code_list, subtype_list

        if len(subtype_list) == 0:
            msg = ERROR_STR_PREFIX + 'subtype_list is null'
            return RET_ERROR, msg, code_list, subtype_list

        for subtype in subtype_list:
            if not SubType.if_has_key(subtype):
                msg = ERROR_STR_PREFIX + 'subtype is %s , which is wrong. (%s)' % (
                    subtype, SubType.get_all_keys())
                return RET_ERROR, msg, code_list, subtype_list

        for code in code_list:
            ret, msg = split_stock_str(code)
            if ret != RET_OK:
                return RET_ERROR, msg, code_list, subtype_list

        return RET_OK, "", code_list, subtype_list

    def subscribe(self, code_list, subtype_list, is_first_push=True, subscribe_push=True, is_detailed_orderbook=False, extended_time=False, session=Session.NONE):
        """
        订阅注册需要的实时信息，指定股票和订阅的数据类型即可

        注意：len(code_list) * 订阅的K线类型的数量 <= 100

        :param code_list: 需要订阅的股票代码列表
        :param subtype_list: 需要订阅的数据类型列表，参见SubType
        :param is_first_push: 订阅成功后是否马上推送一次数据
        :param subscribe_push: 订阅后推送
        :param is_detailed_orderbook 是否订阅详细的摆盘订单明细，仅用于 SF 行情权限下订阅 ORDER_BOOK 类型
        :param extended_time - 是否允许美股盘前盘后数据（仅用于订阅美股实时K线、实时分时、实时逐笔），False不允许，True允许
        :param session - 是否允许美股盘前盘后数据（仅用于订阅美股实时K线、实时分时、实时逐笔）,参见Session
        :return: (ret, err_message)

                ret == RET_OK err_message为None

                ret != RET_OK err_message为错误描述字符串
        :example:

        .. code:: python

        from futu import *
        quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
        print(quote_ctx.subscribe(['HK.00700'], [SubType.QUOTE)])
        quote_ctx.close()
        """
        return self._subscribe_impl(code_list, subtype_list, is_first_push, subscribe_push, is_detailed_orderbook, extended_time, session)

    def _subscribe_impl(self, code_list, subtype_list, is_first_push, subscribe_push=True, is_detailed_orderbook=False, extended_time=False, session=Session.NONE):

        ret, msg, code_list, subtype_list = self._check_subscribe_param(
            code_list, subtype_list)
        if ret != RET_OK:
            return ret, msg

        kline_sub_count = 0
        for sub_type in subtype_list:
            if sub_type in KLINE_SUBTYPE_LIST:
                kline_sub_count += 1

        # if kline_sub_count * len(code_list) > MAX_KLINE_SUB_COUNT:
        #     return RET_ERROR, 'Too many subscription'

        query_processor = self._get_sync_query_processor(SubscriptionQuery.pack_subscribe_req,
                                                         SubscriptionQuery.unpack_subscribe_rsp)

        kargs = {
            'code_list': code_list,
            'subtype_list': subtype_list,
            'conn_id': self.get_sync_conn_id(),
            'is_first_push': is_first_push,
            'subscribe_push': subscribe_push,
            'is_detailed_orderbook': is_detailed_orderbook,
            'extended_time': extended_time,
            'session': session,
            'security_firm': self.__security_firm
        }
        ret_code, msg, _ = query_processor(**kargs)

        if ret_code != RET_OK:
            return RET_ERROR, msg

        with self._lock:
            self._sub_record.sub(code_list, subtype_list, is_detailed_orderbook, extended_time, session)
        #
        # ret_code, msg, push_req_str = SubscriptionQuery.pack_push_req(
        #     code_list, subtype_list, self.get_async_conn_id(), is_first_push)
        #
        # if ret_code != RET_OK:
        #     return RET_ERROR, msg
        #
        # ret_code, msg = self._send_async_req(push_req_str)
        # if ret_code != RET_OK:
        #     return RET_ERROR, msg

        return RET_OK, None

    def _reconnect_subscribe(self, code_list, subtype_list, is_detailed_orderbook, extended_time, session):

        # 将k线定阅和其它定阅区分开来
        kline_sub_list = []
        other_sub_list = []
        for sub in subtype_list:
            if sub in KLINE_SUBTYPE_LIST:
                kline_sub_list.append(sub)
            else:
                other_sub_list.append(sub)

        # 连接断开时，可能会有大批股票需要重定阅，分次定阅，提高成功率
        kline_sub_one_size = 1
        if len(kline_sub_list) > 0:
            kline_sub_one_size = math.floor(100 / len(kline_sub_list))

        sub_info_list = [
            {"sub_list": kline_sub_list, "one_size":  kline_sub_one_size},
            {"sub_list": other_sub_list, "one_size": 100},
        ]

        ret_code = RET_OK
        ret_data = None

        for info in sub_info_list:
            sub_list = info["sub_list"]
            one_size = info["one_size"]
            all_count = len(code_list)
            start_idx = 0

            while start_idx < all_count and len(sub_list):
                sub_count = one_size if start_idx + \
                    one_size <= all_count else (all_count - start_idx)
                sub_codes = code_list[start_idx: start_idx + sub_count]
                start_idx += sub_count

                ret_code, ret_data = self._subscribe_impl(
                    sub_codes, sub_list, True, True, is_detailed_orderbook, extended_time, session)
                if ret_code != RET_OK:
                    break
            if ret_code != RET_OK:
                break

        return ret_code, ret_data

    def unsubscribe(self, code_list, subtype_list, unsubscribe_all=False):
        """
        取消订阅
        :param code_list: 取消订阅的股票代码列表
        :param subtype_list: 取消订阅的类型，参见SubType
        :return: (ret, err_message)

                ret == RET_OK err_message为None

                ret != RET_OK err_message为错误描述字符串
        """
        if not unsubscribe_all:
            ret, msg, code_list, subtype_list = self._check_subscribe_param(
                code_list, subtype_list)
            if ret != RET_OK:
                return ret, msg
        query_processor = self._get_sync_query_processor(SubscriptionQuery.pack_unsubscribe_req,
                                                         SubscriptionQuery.unpack_unsubscribe_rsp)

        kargs = {
            'code_list': code_list,
            'subtype_list': subtype_list,
            'unsubscribe_all': unsubscribe_all,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }

        with self._lock:
            if unsubscribe_all:
                self._sub_record.unsub_all()
            else:
                self._sub_record.unsub(code_list, subtype_list)

        ret_code, msg, _ = query_processor(**kargs)

        if ret_code != RET_OK:
            return RET_ERROR, msg

        if unsubscribe_all:  # 反订阅全部别的参数不重要
            return RET_OK, None


        kargs = {
            'code_list': code_list,
            'subtype_list': subtype_list,
            "conn_id": self.get_async_conn_id(),
            "security_firm": self.__security_firm
        }

        ret_code, msg = self._query_async(SubscriptionQuery.pack_unpush_req, SubscriptionQuery.unpack_unpush_query_rsp, **kargs)
        if ret_code != RET_OK:
            return RET_ERROR, msg

        return RET_OK, None

    def unsubscribe_all(self):
        return self.unsubscribe(None, None, True)

    def query_subscription(self, is_all_conn=True):
        """
        查询已订阅的实时信息

        :param is_all_conn: 是否返回所有连接的订阅状态,不传或者传False只返回当前连接数据
        :return: (ret, data)

                ret != RET_OK 返回错误字符串

                ret == RET_OK 返回 定阅信息的字典数据 ，格式如下:

                {
                    'total_used': 4,    # 所有连接已使用的定阅额度

                    'own_used': 0,       # 当前连接已使用的定阅额度

                    'remain': 496,       #  剩余的定阅额度

                    'own_security_firm': 'FUTUSECURITIES',  # 当前连接的券商标识

                    'option_used_quota': 10,     # 期权已使用订阅额度

                    'option_remain_quota': 90,   # 期权剩余订阅额度

                    'own_option_used_quota': 10,    # 当前连接期权已使用订阅额度

                    'sub_list':          #  每种定阅类型对应的股票列表

                    {
                        'BROKER': ['HK.00700', 'HK.02318'],

                        'RT_DATA': ['HK.00700', 'HK.02318']
                    }
                }
        """
        is_all_conn = bool(is_all_conn)
        query_processor = self._get_sync_query_processor(
            SubscriptionQuery.pack_subscription_query_req,
            SubscriptionQuery.unpack_subscription_query_rsp)
        kargs = {
            "is_all_conn": is_all_conn,
            "conn_id": self.get_sync_conn_id()
        }

        ret_code, msg, sub_table = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        ret_dict = {}
        ret_dict['total_used'] = sub_table['total_used']
        ret_dict['remain'] = sub_table['remain']
        ret_dict['option_used_quota'] = sub_table['option_used_quota']
        ret_dict['option_remain_quota'] = sub_table['option_remain_quota']
        ret_dict['own_used'] = 0
        ret_dict['own_security_firm'] = SecurityFirm.NONE
        ret_dict['own_option_used_quota'] = 0
        ret_dict['sub_list'] = {}
        for conn_sub in sub_table['conn_sub_list']:

            is_own_conn = conn_sub['is_own_conn']
            if is_own_conn:
                ret_dict['own_used'] = conn_sub['used']
                ret_dict['own_security_firm'] = conn_sub['security_firm']
                ret_dict['own_option_used_quota'] = conn_sub['option_used_quota']
            if not is_all_conn and not is_own_conn:
                continue

            for sub_info in conn_sub['sub_list']:
                subtype = sub_info['subtype']

                if subtype not in ret_dict['sub_list']:
                    ret_dict['sub_list'][subtype] = []
                code_list = ret_dict['sub_list'][subtype]

                for code in sub_info['code_list']:
                    if code not in code_list:
                        code_list.append(code)

        return RET_OK, ret_dict

    def get_stock_quote(self, code_list):
        """
        获取订阅股票报价的实时数据，有订阅要求限制。

        对于异步推送，参见StockQuoteHandlerBase

        :param code_list: 股票代码列表，必须确保code_list中的股票均订阅成功后才能够执行
        :return: (ret, data)

                ret == RET_OK 返回pd dataframe数据，数据列格式如下

                ret != RET_OK 返回错误字符串

                =====================   ===========   ==============================================================
                参数                      类型                        说明
                =====================   ===========   ==============================================================
                code                    str            股票代码
                data_date               str            日期
                data_time               str            时间（美股默认是美东时间，港股A股默认是北京时间）
                last_price              float          最新价格
                open_price              float          今日开盘价
                high_price              float          最高价格
                low_price               float          最低价格
                prev_close_price        float          昨收盘价格
                volume                  int            成交数量
                turnover                float          成交金额
                turnover_rate           float          换手率
                amplitude               int            振幅
                suspension              bool           是否停牌(True表示停牌)
                listing_date            str            上市日期 (yyyy-MM-dd)
                price_spread            float          当前价差，亦即摆盘数据的买档或卖档的相邻档位的报价差
                dark_status             str            暗盘交易状态，见DarkStatus
                sec_status              str            股票状态，见SecurityStatus
                strike_price            float          行权价
                contract_size           int            每份合约数
                open_interest           int            未平仓合约数
                implied_volatility      float          隐含波动率
                premium                 float          溢价
                delta                   float          希腊值 Delta
                gamma                   float          希腊值 Gamma
                vega                    float          希腊值 Vega
                theta                   float          希腊值 Theta
                rho                     float          希腊值 Rho
                net_open_interest       int            净未平仓合约数
                expiry_date_distance    int            距离到期日天数
                contract_nominal_value  float          合约名义金额
                owner_lot_multiplier    float          相等正股手数，指数期权无该字段
                option_area_type        str            期权地区类型，见 OptionAreaType_
                contract_multiplier     float          合约乘数，指数期权特有字段
                last_settle_price       float          昨结，期货特有字段
                position                float          持仓量，期货特有字段
                position_change         float          日增仓，期货特有字段
                index_option_type       str            指数期权的类型，仅在指数期权有效
                =====================   ===========   ==============================================================
        """
        code_list = unique_and_normalize_list(code_list)
        if not code_list:
            error_str = ERROR_STR_PREFIX + "the type of code_list param is wrong"
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            StockQuoteQuery.pack_req,
            StockQuoteQuery.unpack_rsp,
        )
        kargs = {
            "stock_list": code_list,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }

        ret_code, msg, quote_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = [
            'code', 'name', 'data_date', 'data_time', 'last_price', 'open_price',
            'high_price', 'low_price', 'prev_close_price', 'volume',
            'turnover', 'turnover_rate', 'amplitude', 'suspension',
            'listing_date', 'price_spread', 'dark_status', 'sec_status', 'strike_price',
            'contract_size', 'open_interest', 'implied_volatility',
            'premium', 'delta', 'gamma', 'vega', 'theta', 'rho',
            'net_open_interest', 'expiry_date_distance', 'contract_nominal_value',
            'owner_lot_multiplier', 'option_area_type', 'contract_multiplier',
            'last_settle_price', 'position', 'position_change', 'index_option_type'
        ]

        col_list.extend(row[0] for row in pb_field_map_PreAfterMarketData_pre)
        col_list.extend(row[0] for row in pb_field_map_PreAfterMarketData_after)
        col_list.extend(row[0] for row in pb_field_map_PreAfterMarketData_overnight)

        quote_frame_table = pd.DataFrame(quote_list, columns=col_list)

        return RET_OK, quote_frame_table

    def get_rt_ticker(self, code, num=500):
        """
        获取指定股票的实时逐笔。取最近num个逐笔

        :param code: 股票代码
        :param num: 最近ticker个数(有最大个数限制，最近1000个）
        :return: (ret, data)

                ret == RET_OK 返回pd dataframe数据，数据列格式如下

                ret != RET_OK 返回错误字符串

                =====================   ===========   ==============================================================
                参数                      类型                        说明
                =====================   ===========   ==============================================================
                code                     str            股票代码
                sequence                 int            逐笔序号
                time                     str            成交时间（美股默认是美东时间，港股A股默认是北京时间）
                price                    float          成交价格
                volume                   int            成交数量（股数）
                turnover                 float          成交金额
                ticker_direction         str            逐笔方向
                type                    str             逐笔类型，参见TickerType
                =====================   ===========   ==============================================================
        """

        if code is None or is_str(code) is False:
            error_str = ERROR_STR_PREFIX + "the type of code param is wrong"
            return RET_ERROR, error_str

        if num is None or isinstance(num, int) is False:
            error_str = ERROR_STR_PREFIX + "the type of num param is wrong"
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            TickerQuery.pack_req,
            TickerQuery.unpack_rsp,
        )
        kargs = {
            "code": code,
            "num": num,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ticker_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = [
            'code', 'name', 'time', 'price', 'volume', 'turnover', "ticker_direction",
            'sequence', 'type'
        ]
        ticker_frame_table = pd.DataFrame(ticker_list, columns=col_list)

        return RET_OK, ticker_frame_table

    def get_cur_kline(self, code, num, ktype=KLType.K_DAY, autype=AuType.QFQ):
        """
        实时获取指定股票最近num个K线数据，最多1000根

        :param code: 股票代码
        :param num:  k线数据个数
        :param ktype: k线类型，参见KLType
        :param autype: 复权类型，参见AuType
        :return: (ret, data)

                ret == RET_OK 返回pd dataframe数据，数据列格式如下

                ret != RET_OK 返回错误字符串

                =====================   ===========   ==============================================================
                参数                      类型                        说明
                =====================   ===========   ==============================================================
                code                     str            股票代码
                time_key                 str            时间（美股默认是美东时间，港股A股默认是北京时间）
                open                     float          开盘价
                close                    float          收盘价
                high                     float          最高价
                low                      float          最低价
                volume                   int            成交量
                turnover                 float          成交额
                pe_ratio                 float          市盈率（该字段为比例字段，默认不展示%）
                turnover_rate            float          换手率
                =====================   ===========   ==============================================================
        """
        param_table = {'code': code, 'ktype': ktype}
        for x in param_table:
            param = param_table[x]
            if param is None or is_str(param) is False:
                error_str = ERROR_STR_PREFIX + "the type of %s param is wrong" % x
                return RET_ERROR, error_str

        if num is None or isinstance(num, int) is False:
            error_str = ERROR_STR_PREFIX + "the type of num param is wrong"
            return RET_ERROR, error_str

        if autype is not None and is_str(autype) is False:
            error_str = ERROR_STR_PREFIX + "the type of autype param is wrong"
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            CurKlineQuery.pack_req,
            CurKlineQuery.unpack_rsp,
        )

        kargs = {
            "code": code,
            "num": num,
            "ktype": ktype,
            "autype": autype,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, kline_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = [
            'code', 'name', 'time_key', 'open', 'close', 'high', 'low', 'volume',
            'turnover', 'pe_ratio', 'turnover_rate', 'last_close'
        ]
        kline_frame_table = pd.DataFrame(kline_list, columns=col_list)

        return RET_OK, kline_frame_table

    def get_order_book(self, code, num=10, order_book_type=None):
        """
        获取实时摆盘数据

        :param code: 股票代码
        :param num: 请求摆盘档数，LV2行情用户最多可以获取10档，SF行情用户最多可以获取40档
        :param order_book_type: 摆盘类型，参见OrderBookType。不传默认返回整股盘
        :return: (ret, data)

                ret == RET_OK 返回字典，数据格式如下

                ret != RET_OK 返回错误字符串

                {‘code’: 股票代码
                ‘Ask’:[ (ask_price1, ask_volume1, order_num, {order_id1:order_volume1,…}), (ask_price2, ask_volume2, order_num, {order_id1:order_volume1,…}),…]
                ‘Bid’: [ (bid_price1, bid_volume1, order_num, {order_id1:order_volume1,…}), (bid_price2, bid_volume2, order_num, {order_id1:order_volume1,…}),…]
                }

                ‘Ask’：卖盘， ‘Bid’买盘。每个元组的含义是(委托价格，委托数量，委托订单数)
        """
        if code is None or is_str(code) is False:
            error_str = ERROR_STR_PREFIX + "the type of code param is wrong"
            return RET_ERROR, error_str

        if order_book_type is not None:
            r, _ = OrderBookType.to_number(order_book_type)
            if not r:
                error_str = ERROR_STR_PREFIX + "the type of order_book_type param is wrong"
                return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            OrderBookQuery.pack_req,
            OrderBookQuery.unpack_rsp,
        )

        kargs = {
            "code": code,
            "num": num,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm,
            "order_book_type": order_book_type
        }
        ret_code, msg, orderbook = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        return RET_OK, orderbook

    def get_referencestock_list(self, code, reference_type):
        """
        获取证券的关联数据
        :param code: 证券id，str，例如HK.00700
        :param reference_type: 要获得的相关数据，参见SecurityReferenceType。例如WARRANT，表示获取正股相关的窝轮
        :return: (ret, data)

                ret == RET_OK 返回pd dataframe数据，数据列格式如下

                ret != RET_OK 返回错误字符串
                =======================   ===========   ==============================================================================
                参数                        类型                        说明
                =======================   ===========   ==============================================================================
                code                        str           证券代码
                lot_size                    int           每手数量
                stock_type                  str           证券类型，参见SecurityType
                stock_name                  str           证券名字
                list_time                   str           上市时间（美股默认是美东时间，港股A股默认是北京时间）
                wrt_valid                   bool          是否是窝轮，如果为True，下面wrt开头的字段有效
                wrt_type                    str           窝轮类型，参见WrtType
                wrt_code                    str           所属正股
                future_valid                bool          是否是期货，如果为True，下面future开头的字段有效
                future_main_contract        bool          是否主连合约（期货特有字段）
                future_last_trade_time      string        最后交易时间（期货特有字段，非主连期货合约才有值）
                =======================   ===========   ==============================================================================

        """
        if code is None or is_str(code) is False:
            error_str = ERROR_STR_PREFIX + "the type of code param is wrong"
            return RET_ERROR, error_str


        if reference_type is not None and not SecurityReferenceType.if_has_key(reference_type):
            error_str = ERROR_STR_PREFIX + "the type of reference_type param is wrong"
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            StockReferenceList.pack_req,
            StockReferenceList.unpack_rsp,
        )

        kargs = {
            "code": code,
            'ref_type': reference_type,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, data_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = [
            'code', 'lot_size', 'stock_type', 'stock_name', 'list_time', 'wrt_valid', 'wrt_type', 'wrt_code',
            'future_valid','future_main_contract','future_last_trade_time'
        ]

        pd_frame = pd.DataFrame(data_list, columns=col_list)
        return RET_OK, pd_frame

    def get_owner_plate(self, code_list):
        """
        获取单支或多支股票的所属板块信息列表

        :param code_list: 股票代码列表，仅支持正股、指数。list或str。例如：['HK.00700', 'HK.00001']或者'HK.00700,HK.00001'。
        :return: (ret, data)

                ret == RET_OK 返回pd dataframe数据，data.DataFrame数据, 数据列格式如下

                ret != RET_OK 返回错误字符串

                =====================   ===========   ==============================================================
                参数                      类型                        说明
                =====================   ===========   ==============================================================
                code                    str            证券代码
                plate_code              str            板块代码
                plate_name              str            板块名字
                plate_type              str            板块类型（行业板块或概念板块），futu.common.constant.Plate
                =====================   ===========   ==============================================================
        """
        if is_str(code_list):
            code_list = code_list.split(',')
        elif isinstance(code_list, list):
            pass
        else:
            return RET_ERROR, "code list must be like ['HK.00001', 'HK.00700'] or 'HK.00001,HK.00700'"

        code_list = unique_and_normalize_list(code_list)
        if not code_list:
            error_str = ERROR_STR_PREFIX + "the type of code param is wrong"
            return RET_ERROR, error_str

        for code in code_list:
            if code is None or is_str(code) is False:
                error_str = ERROR_STR_PREFIX + "the type of param in code_list is wrong"
                return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            OwnerPlateQuery.pack_req, OwnerPlateQuery.unpack_rsp)
        kargs = {
            "code_list": code_list,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }

        ret_code, msg, owner_plate_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = [
            'code', 'name', 'plate_code', 'plate_name', 'plate_type'
        ]

        owner_plate_table = pd.DataFrame(owner_plate_list, columns=col_list)

        return RET_OK, owner_plate_table

    def get_holding_change_list(self, code, holder_type, start=None, end=None):
        """
        获取大股东持股变动列表,只提供美股数据

        :param code: 股票代码. 例如：'US.AAPL'
        :param holder_type: 持有者类别，StockHolder_
        :param start: 开始时间. 例如：'2016-10-01'
        :param end: 结束时间，例如：'2017-10-01'。
            start与end的组合如下：
            ==========    ==========    ========================================
             start类型      end类型       说明
            ==========    ==========    ========================================
             str            str           start和end分别为指定的日期
             None           str           start为end往前365天
             str            None          end为start往后365天
             None           None          end为当前日期，start为end往前365天
            ==========    ==========    ========================================

        :return: (ret, data)

                ret == RET_OK 返回pd dataframe数据，data.DataFrame数据, 数据列格式如下

                ret != RET_OK 返回错误字符串

                =====================   ===========   ==============================================================
                参数                      类型                        说明
                =====================   ===========   ==============================================================
                holder_name             str            高管名称
                holding_qty             float          持股数
                holding_ratio           float          持股比例（该字段为比例字段，默认不展示%）
                change_qty              float          变动数
                change_ratio            float          变动比例（该字段为比例字段，默认不展示%）
                time                    str            发布时间（美股的时间默认是美东）
                =====================   ===========   ==============================================================
        """
        
        if code is None or is_str(code) is False:
            msg = ERROR_STR_PREFIX + "the type of code param is wrong"
            return RET_ERROR, msg

        r, holder_type_number = StockHolder.to_number(holder_type)
        if holder_type is None or not r:
            msg = ERROR_STR_PREFIX + "the type {0} is wrong".format(holder_type)
            return RET_ERROR, msg

        ret_code, msg, start, end = normalize_start_end_date(
            start, end, delta_days=365)
        if ret_code != RET_OK:
            return ret_code, msg

        query_processor = self._get_sync_query_processor(
            HoldingChangeList.pack_req, HoldingChangeList.unpack_rsp)
        kargs = {
            "code": code,
            "holder_type": holder_type_number,
            "conn_id": self.get_sync_conn_id(),
            "start_date": start,
            "end_date": end,
            "security_firm": self.__security_firm
        }

        ret_code, msg, owner_plate_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = [
            'holder_name', 'holding_qty', 'holding_ratio', 'change_qty', 'change_ratio', 'time'
        ]

        holding_change_list = pd.DataFrame(owner_plate_list, columns=col_list)

        return RET_OK, holding_change_list

    def _check_option_strategy_legs(self, option_legs):
        if not isinstance(option_legs, list) or len(option_legs) == 0:
            return RET_ERROR, ERROR_STR_PREFIX + "option_legs must be a non-empty list"

        for leg in option_legs:
            if not isinstance(leg, OptionStrategyLeg):
                return RET_ERROR, ERROR_STR_PREFIX + "each item in option_legs must be OptionStrategyLeg"
            if leg.code is None or is_str(leg.code) is False:
                return RET_ERROR, ERROR_STR_PREFIX + "the type of code in option_legs is wrong"
            ret, content = split_stock_str(leg.code)
            if ret == RET_ERROR:
                return RET_ERROR, content
            r, _ = StrategyLegAction.to_number(leg.action)
            if r is False:
                return RET_ERROR, ERROR_STR_PREFIX + "the type of action in option_legs is wrong"
            if not isinstance(leg.quantity, (int, float)) or isinstance(leg.quantity, bool) or leg.quantity <= 0:
                return RET_ERROR, ERROR_STR_PREFIX + "the quantity in option_legs must be float number"

        return RET_OK, ""

    def get_option_chain(self, code, index_option_type=IndexOptionType.NORMAL, start=None, end=None, option_type=OptionType.ALL, option_cond_type=OptionCondType.ALL, data_filter = None):
        """
        通过标的股查询期权

        :param code: 股票代码,例如：'HK.02318'
        :param index_option_type: 指数期权类型，IndexOptionType
        :param start: 开始日期，该日期指到期日，例如'2017-08-01'
        :param end: 结束日期（包括这一天），该日期指到期日，例如'2017-08-30'。 注意，时间范围最多30天
                start和end的组合如下：
                ==========    ==========    ========================================
                 start类型      end类型       说明
                ==========    ==========    ========================================
                 str            str           start和end分别为指定的日期
                 None           str           start为end往前30天
                 str            None          end为start往后30天
                 None           None          start为当前日期，end往后30天
                ==========    ==========    ========================================
        :param option_type: 期权类型,默认全部，全部/看涨/看跌，futu.common.constant.OptionType
        :param option_cond_type: 默认全部，全部/价内/价外，futu.common.constant.OptionCondType
        :param data_filter: 数据筛选条件，默认不筛选，参考OptionDataFilter,
                OptionDataFilter字段如下：
                ============================    ==========    ========================================
                 字段                            类型           说明
                ============================    ==========    ========================================
                 implied_volatility_min         float          隐含波动率过滤起点 %
                 implied_volatility_max         float          隐含波动率过滤终点 %
                 delta_min                      float          希腊值 Delta过滤起点
                 delta_max                      float          希腊值 Delta过滤终点
                 gamma_min                      float          希腊值 Gamma过滤起点
                 gamma_max                      float          希腊值 Gamma过滤终点
                 vega_min                       float          希腊值 Vega过滤起点
                 vega_max                       float          希腊值 Vega过滤终点
                 theta_min                      float          希腊值 Theta过滤起点
                 theta_max                      float          希腊值 Theta过滤终点
                 rho_min                        float          希腊值 Rho过滤起点
                 rho_max                        float          希腊值 Rho过滤终点
                 net_open_interest_min          float          净未平仓合约数过滤起点
                 net_open_interest_max          float          净未平仓合约数过滤终点
                 open_interest_min              float          未平仓合约数过滤起点
                 open_interest_max              float          未平仓合约数过滤终点
                 vol_min                        float          成交量过滤起点
                 vol_max                        float          成交量过滤终点
                ============================    ==========    ========================================
        :return: (ret, data)

                ret == RET_OK 返回pd dataframe数据，数据列格式如下

                ret != RET_OK 返回错误字符串

                ==================   ===========   ==============================================================
                参数                      类型                        说明
                ==================   ===========   ==============================================================
                code                 str           股票代码
                name                 str           名字
                lot_size             int           每手数量
                stock_type           str           股票类型，参见SecurityType
                option_type          str           期权类型，Qot_Common.OptionType
                stock_owner          str           标的股
                strike_time          str           行权日（美股默认是美东时间，港股A股默认是北京时间）
                strike_price         float         行权价
                suspension           bool          是否停牌(True表示停牌)
                stock_id             int           股票id
                index_option_type    str           指数期权类型
                expiration_cycle     str           交割周期类型
                option_standard_type str           期权标准类型
                option_settlement_mode str         结算方式
                ==================   ===========   ==============================================================

        """

        if code is None or is_str(code) is False:
            error_str = ERROR_STR_PREFIX + "the type of code param is wrong"
            return RET_ERROR, error_str

        r, n = IndexOptionType.to_number(index_option_type)
        if r is False:
            msg = ERROR_STR_PREFIX + "the type of index_option_type param is wrong"
            return RET_ERROR, msg

        if data_filter is not None and not isinstance(data_filter, OptionDataFilter):
            msg = ERROR_STR_PREFIX + "the type of data_filter param is wrong"
            return RET_ERROR, msg

        if not OptionType.if_has_key(option_type):
            msg = ERROR_STR_PREFIX + "the type of option_type param is wrong"
            return RET_ERROR, msg

        if not OptionCondType.if_has_key(option_cond_type):
            msg = ERROR_STR_PREFIX + "the type of option_cond_type param is wrong"
            return RET_ERROR, msg

        ret_code, msg, start, end = normalize_start_end_date(
            start, end, delta_days=29, default_time_end='00:00:00', prefer_end_now=False)
        if ret_code != RET_OK:
            return ret_code, msg

        query_processor = self._get_sync_query_processor(
            OptionChain.pack_req, OptionChain.unpack_rsp)
        kargs = {
            "code": code,
            "index_option_type": index_option_type,
            "conn_id": self.get_sync_conn_id(),
            "start_date": start,
            "end_date": end,
            "option_cond_type": option_cond_type,
            "option_type": option_type,
            "data_filter": data_filter,
            "security_firm": self.__security_firm
        }

        ret_code, msg, option_chain_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = [
            'code', 'name', 'lot_size', 'stock_type', 'option_type', 
            'stock_owner', 'strike_time', 'strike_price', 'suspension',
            'stock_id', 'index_option_type', 'expiration_cycle', 
            'option_standard_type', 'option_settlement_mode'
        ]

        option_chain = pd.DataFrame(option_chain_list, columns=col_list)

        option_chain.sort_values(
            by=["strike_time", "strike_price"], axis=0, ascending=True, inplace=True)
        option_chain.index = range(len(option_chain))

        return RET_OK, option_chain

    def get_warrant(self, stock_owner='', req=None):
        """
        :param stock_owner:所属正股
        :param req:futu.quote.quote_get_warrant.Request
        """


        if (req is None) or (not isinstance(req, Request)):
            req = Request()

        if stock_owner is Market.HK:
            stock_owner = ''

        if stock_owner is not None:
            req.stock_owner = stock_owner

        r, v = SortField.to_number(req.sort_field)
        if not r:
            return RET_ERROR, 'sort_field is wrong. must be SortField'

        query_processor = self._get_sync_query_processor(
            QuoteWarrant.pack_req, QuoteWarrant.unpack_rsp)
        kargs = {
            "req": req,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, content = query_processor(**kargs)
        if ret_code != RET_OK:
            return ret_code, msg
        else:
            warrant_data_list, last_page, all_count = content
            col_list = ['stock', 'name', 'stock_owner', 'type', 'issuer', 'maturity_time',
                        'list_time', 'last_trade_time', 'recovery_price', 'conversion_ratio',
                        'lot_size', 'strike_price', 'last_close_price', 'cur_price', 'price_change_val', 'change_rate',
                        'status', 'bid_price', 'ask_price', 'bid_vol', 'ask_vol', 'volume', 'turnover', 'score',
                        'premium', 'break_even_point', 'leverage', 'ipop', 'price_recovery_ratio', 'conversion_price',
                        'street_rate', 'street_vol', 'amplitude', 'issue_size', 'high_price', 'low_price',
                        'implied_volatility', 'delta', 'effective_leverage', 'list_timestamp',  'last_trade_timestamp',
                        'maturity_timestamp', 'upper_strike_price', 'lower_strike_price', 'inline_price_status']
            warrant_data_frame = pd.DataFrame(
                warrant_data_list, columns=col_list)
            # 1120400921001028854
            return ret_code, (warrant_data_frame, last_page, all_count)

    def get_history_kl_quota(self, get_detail=False):
        """拉取历史K线已经用掉的额度"""
        # self.get_login_user_id()
        query_processor = self._get_sync_query_processor(
            HistoryKLQuota.pack_req, HistoryKLQuota.unpack_rsp)
        kargs = {
            "get_detail": get_detail,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code != RET_OK:
            return ret_code, msg
        else:
            used_quota = data["used_quota"]
            remain_quota = data["remain_quota"]
            detail_list = data["detail_list"]
            return ret_code, (used_quota, remain_quota, detail_list)

    def get_rehab(self, code):
        """获取除权信息"""

        """
        获取给定股票列表的复权因子

        :param code_list: 股票列表，例如['HK.00700']
        :return: (ret, data)

                ret == RET_OK 返回pd dataframe数据，data.DataFrame数据, 数据列格式如下

                ret != RET_OK 返回错误字符串

                =====================   ===========   =================================================================================
                参数                      类型                        说明
                =====================   ===========   =================================================================================
                ex_div_date             str            除权除息日
                split_base              float          拆股分子
                split_ert               float          拆股分母
                join_base               float          合股分子
                join_ert                float          合股分母
                split_ratio             float          拆合股比例，例如，对于5股合1股为1/5，对于1股拆5股为5/1
                per_cash_div            float          每股派现
                special_dividend        float          特别股息
                bonus_base              float          送股分子
                bonus_ert               float          送股分母
                per_share_div_ratio     float          每股送股比例
                transfer_base           float          转赠股分子
                transfer_ert            float          转赠股分母
                per_share_trans_ratio   float          每股转增股比例
                allot_base              float          配股分子
                allot_ert               float          配股分母
                allotment_ratio         float          每股配股比例
                allotment_price         float          配股价
                add_base                float          增发股分子
                add_ert                 float          增发股分母
                stk_spo_ratio           float          增发比例
                stk_spo_price           float          增发价格
                spin_off_base           float          分立分子
                spin_off_ert            float          分立分母
                spin_off_ratio          float          分立比例
                forward_adj_factorA     float          前复权因子A
                forward_adj_factorB     float          前复权因子B
                backward_adj_factorA    float          后复权因子A
                backward_adj_factorB    float          后复权因子B
                =====================   ===========   =================================================================================
        """
        query_processor = self._get_sync_query_processor(
            RequestRehab.pack_req, RequestRehab.unpack_rsp)
        kargs = {
            "stock": code,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code != RET_OK:
            return ret_code, msg
        else:
            col_list = [
                'ex_div_date', 'split_base','split_ert','join_base', 'join_ert','split_ratio', 
                'per_cash_div', 'special_dividend', 'bonus_base', 'bonus_ert', 'per_share_div_ratio', 
                'transfer_base', 'transfer_ert', 'per_share_trans_ratio', 
                'allot_base','allot_ert', 'allotment_ratio', 'allotment_price', 
                'add_base', 'add_ert', 'stk_spo_ratio', 'stk_spo_price',
                'spin_off_base', 'spin_off_ert', 'spin_off_ratio',
                'forward_adj_factorA', 'forward_adj_factorB',
                'backward_adj_factorA', 'backward_adj_factorB',    
                   
            ]
            exr_frame_table = pd.DataFrame(data, columns=col_list)
            return ret_code, exr_frame_table

    def get_user_info(self, info_field=[]):
        """获取用户信息（内部保留函数）"""
        query_processor = self._get_sync_query_processor(
            GetUserInfo.pack_req, GetUserInfo.unpack_rsp)
        kargs = {
            "info_field": info_field,
            "conn_id": self.get_sync_conn_id()
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code != RET_OK:
            return ret_code, msg
        else:
            return ret_code, data

    def get_capital_distribution(self, stock_code):
        """
        个股资金分布
        GetCapitalDistribution
        """
        if stock_code is None or is_str(stock_code) is False:
            error_str = ERROR_STR_PREFIX + 'the type of stock_code param is wrong'
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            GetCapitalDistributionQuery.pack_req,
            GetCapitalDistributionQuery.unpack,
        )

        kargs = {
            "code": stock_code,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, dict):
            col_list = [
                'capital_in_super',
                'capital_in_big',
                'capital_in_mid',
                'capital_in_small',
                'capital_out_super',
                'capital_out_big',
                'capital_out_mid',
                'capital_out_small',
                'update_time',
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list, index=[0])
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_option_quote(self, option_legs):
        """
         获取期权行情
        :param option_legs: 组合策略合约腿列表，元素类型为 OptionStrategyLeg
        :return: (ret, data)
        ret != RET_OK 返回错误字符串
        ret == RET_OK data为DataFrame类型，字段如下:
        ======================   ==================   ================================
        参数                       类型                 说明
        ======================   ==================   ================================
        price                     float                最新价
        change_val                float                涨跌额
        change_rate               float                涨跌幅
        volume                    int                  成交量
        turnover                  float                成交额
        high_price                float                最高价
        low_price                 float                最低价
        mid_price                 float                中间价
        open_price                float                今开
        last_close_price          float                昨收
        open_interest             int                  未平仓合约数
        premium                   float                溢价
        implied_volatility        float                隐含波动率
        delta                     float                Delta
        gamma                     float                Gamma
        vega                      float                Vega
        theta                     float                Theta
        rho                       float                Rho
        option_type               OptionType           期权类型
        expire_time               str                  到期日
        strike_price              float                行权价
        contract_size             float                合约规模
        contract_multiplier       float                合约乘数
        exercise_type             OptionAreaType       行权类型
        days_to_expiry            int                  距到期日天数
        net_open_interest         int                  净未平仓合约数
        contract_value            float                合约金额
        equal_underlying          float                相当正股手数
        index_option_type         IndexOptionType      指数期权类型
        intrinsic_value           float                内在价值
        time_value                float                时间价值
        breakeven_point           list                 盈亏平衡点列表
        dist_to_breakeven         list                 与breakeven_point同下标对应的距离列表
        prob_of_profit            float                盈利概率
        seller_roi                float                卖方回报率
        mark_price                float                标记价
        leverage_ratio            float                杠杆倍数
        effective_gearing         float                有效杠杆
        ======================   ==================   ================================
        """
        ret_code, msg = self._check_option_strategy_legs(option_legs)
        if ret_code != RET_OK:
            return ret_code, msg

        query_processor = self._get_sync_query_processor(
            GetOptionQuoteQuery.pack_req,
            GetOptionQuoteQuery.unpack,
        )

        kargs = {
            "option_legs": option_legs,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'price', 'change_val', 'change_rate', 'volume', 'turnover',
                'high_price', 'low_price', 'mid_price', 'open_price', 'last_close_price',
                'open_interest', 'premium', 'implied_volatility', 'delta', 'gamma',
                'vega', 'theta', 'rho', 'option_type', 'expire_time', 'strike_price',
                'contract_size', 'contract_multiplier', 'exercise_type', 'days_to_expiry',
                'net_open_interest', 'contract_value', 'equal_underlying', 'index_option_type',
                'intrinsic_value', 'time_value', 'breakeven_point', 'dist_to_breakeven',
                'prob_of_profit', 'seller_roi', 'mark_price', 'leverage_ratio',
                'effective_gearing'
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_option_strategy(self, code, option_strategy, expire_time=None, far_expire_time=None, spread=None,
                            index_option_type=IndexOptionType.NORMAL, option_type=OptionType.ALL,
                            strike_price=None):
        """
         获取期权策略组合
        :param code: 标的股票代码
        :param option_strategy: 期权策略类型，OptionStrategyType
        :param expire_time: 近端到期日，例如'2026-05-29'
        :param far_expire_time: 远端到期日，对角策略时需要
        :param spread: 价差筛选值
        :param index_option_type: 指数期权类型，IndexOptionType
        :param option_type: 期权类型，OptionType
        :param strike_price: 行权价筛选
        :return: (ret, data)
        ret != RET_OK 返回错误字符串
        ret == RET_OK data为DataFrame类型，字段如下:
        ======================   ==================   ================================
        参数                       类型                 说明
        ======================   ==================   ================================
        code                      str                  组合策略代码
        name                      str                  组合策略名称
        option_strategy           OptionStrategyType   期权策略类型
        stock_owner               str                  标的股
        legs                      list                 策略腿列表（OptionStrategyLeg）
        ======================   ==================   ================================
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + "the type of code param is wrong"
        if not OptionStrategyType.if_has_key(option_strategy):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of option_strategy param is wrong"
        if expire_time is not None and is_str(expire_time) is False:
            return RET_ERROR, ERROR_STR_PREFIX + "the type of expire_time param is wrong"
        if far_expire_time is not None and is_str(far_expire_time) is False:
            return RET_ERROR, ERROR_STR_PREFIX + "the type of far_expire_time param is wrong"
        if spread is not None and (not isinstance(spread, (int, float)) or isinstance(spread, bool)):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of spread param is wrong"
        if strike_price is not None and (not isinstance(strike_price, (int, float)) or isinstance(strike_price, bool)):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of strike_price param is wrong"
        if index_option_type is not None and not IndexOptionType.if_has_key(index_option_type):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of index_option_type param is wrong"
        if option_type is not None and not OptionType.if_has_key(option_type):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of option_type param is wrong"

        query_processor = self._get_sync_query_processor(
            GetOptionStrategyQuery.pack_req,
            GetOptionStrategyQuery.unpack,
        )

        kargs = {
            "code": code,
            "option_strategy": option_strategy,
            "expire_time": expire_time,
            "far_expire_time": far_expire_time,
            "spread": spread,
            "index_option_type": index_option_type,
            "option_type": option_type,
            "strike_price": strike_price,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'code',
                'name',
                'option_strategy',
                'stock_owner',
                'legs'
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_option_strategy_analysis(self, option_legs):
        """
         获取期权策略分析
        :param option_legs: 组合策略合约腿列表，元素类型为 OptionStrategyLeg
        :return: (ret, data)
        ret != RET_OK 返回错误字符串
        ret == RET_OK data为DataFrame类型，字段如下:
        ======================   ==================   ================================
        参数                       类型                 说明
        ======================   ==================   ================================
        code                      str                  组合策略代码
        name                      str                  组合策略名称
        option_strategy           OptionStrategyType   期权策略类型
        bid1                      float                买一价
        ask1                      float                卖一价
        max_profit                float                最大盈利
        max_loss                  float                最大亏损
        breakeven_points          list                 盈亏平衡点列表
        prob_of_profit            float                盈利概率
        delta                     float                组合 Delta
        theta                     float                组合 Theta
        ======================   ==================   ================================
        """
        ret_code, msg = self._check_option_strategy_legs(option_legs)
        if ret_code != RET_OK:
            return ret_code, msg

        query_processor = self._get_sync_query_processor(
            GetOptionStrategyAnalysisQuery.pack_req,
            GetOptionStrategyAnalysisQuery.unpack,
        )

        kargs = {
            "option_legs": option_legs,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'code',
                'name',
                'option_strategy',
                'bid1',
                'ask1',
                'max_profit',
                'max_loss',
                'breakeven_points',
                'prob_of_profit',
                'delta',
                'theta'
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_option_strategy_spread(self, code, option_strategy, expire_time=None, far_expire_time=None,
                                   index_option_type=IndexOptionType.NORMAL):
        """
         获取期权策略有效价差
        :param code: 标的股票代码
        :param option_strategy: 期权策略类型，OptionStrategyType
        :param expire_time: 近端到期日，例如'2026-05-29'
        :param far_expire_time: 远端到期日，对角策略时需要
        :param index_option_type: 指数期权类型，IndexOptionType
        :return: (ret, data)
        ret != RET_OK 返回错误字符串
        ret == RET_OK data为DataFrame类型，字段如下:
        ======================   ==================   ================================
        参数                       类型                 说明
        ======================   ==================   ================================
        spread                    float                有效价差
        ======================   ==================   ================================
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + "the type of code param is wrong"
        if expire_time is not None and is_str(expire_time) is False:
            return RET_ERROR, ERROR_STR_PREFIX + "the type of expire_time param is wrong"
        if far_expire_time is not None and is_str(far_expire_time) is False:
            return RET_ERROR, ERROR_STR_PREFIX + "the type of far_expire_time param is wrong"
        if not OptionStrategyType.if_has_key(option_strategy):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of option_strategy param is wrong"
        if not IndexOptionType.if_has_key(index_option_type):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of index_option_type param is wrong"

        query_processor = self._get_sync_query_processor(
            GetOptionStrategySpreadQuery.pack_req,
            GetOptionStrategySpreadQuery.unpack,
        )

        kargs = {
            "code": code,
            "option_strategy": option_strategy,
            "expire_time": expire_time,
            "far_expire_time": far_expire_time,
            "index_option_type": index_option_type,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'spread'
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_search_quote(self, keyword, max_count=10):
        """
        搜索行情
        :param keyword: 搜索词，如 'lite'
        :param max_count: 行情条数上限，默认 10
        :return: (ret, data)
        ret != RET_OK 返回错误字符串
        ret == RET_OK data为DataFrame类型，字段如下:
        ======================   ==================   ================================
        参数                       类型                 说明
        ======================   ==================   ================================
        market                    str                  市场类型
        code                      str                  交易代码，如 LITE / 01936
        name                      str                  标的名称
        sec_type                  str                  股票类型
        is_watched                bool                 是否已在自选
        ======================   ==================   ================================
        """
        if not keyword or not is_str(keyword):
            return RET_ERROR, ERROR_STR_PREFIX + "keyword must be a non-empty string"
        if not isinstance(max_count, int) or max_count <= 0:
            return RET_ERROR, ERROR_STR_PREFIX + "max_count must be a positive integer"

        query_processor = self._get_sync_query_processor(
            GetSearchQuoteQuery.pack_req,
            GetSearchQuoteQuery.unpack,
        )
        kargs = {
            "keyword": keyword,
            "max_count": max_count,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = ['market', 'code', 'name', 'sec_type', 'is_watched']
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_search_news(self, keyword, max_count=10, news_sub_type=NewsSubType.ALL):
        """
        搜索资讯
        :param keyword: 搜索词，如 'lite'
        :param max_count: 资讯条数上限，默认 10
        :param news_sub_type: 资讯子类型，取值为 NewsSubType.ALL / NEWS / NOTICE / RATING，默认 NewsSubType.ALL
        :return: (ret, data)
        ret != RET_OK 返回错误字符串
        ret == RET_OK data为DataFrame类型，字段如下:
        ======================   ==================   ================================
        参数                       类型                 说明
        ======================   ==================   ================================
        title                     str                  标题
        news_sub_type             str                  资讯子类型，取值为 "ALL" / "NEWS" / "NOTICE" / "RATING"
        source                    str                  来源
        publish_time              str                  发布时间戳字符串
        view_count                int                  浏览量
        related_securities        list                 关联标的列表，如 LITE.US
        url                       str                  详情页链接
        ======================   ==================   ================================
        """
        if not keyword or not is_str(keyword):
            return RET_ERROR, ERROR_STR_PREFIX + "keyword must be a non-empty string"
        if not isinstance(max_count, int) or max_count <= 0:
            return RET_ERROR, ERROR_STR_PREFIX + "max_count must be a positive integer"
        if not NewsSubType.if_has_key(news_sub_type):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of news_sub_type param is wrong"

        query_processor = self._get_sync_query_processor(
            GetSearchNewsQuery.pack_req,
            GetSearchNewsQuery.unpack,
        )
        kargs = {
            "keyword": keyword,
            "max_count": max_count,
            "news_sub_type": news_sub_type,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = ['title', 'news_sub_type', 'source', 'publish_time', 'view_count',
                        'related_securities', 'url']
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_capital_flow(self, stock_code, period_type = PeriodType.INTRADAY, start=None, end=None):
        """
        个股资金流入流出
        GetCapitalFlow
        """
        if not PeriodType.if_has_key(period_type):
            msg = ERROR_STR_PREFIX + "the type of period_type param is wrong"
            return RET_ERROR, msg

        if period_type != PeriodType.INTRADAY:
            ret_code, msg, start, end = normalize_start_end_date(start, end, 365)
            if ret_code != RET_OK:
                return ret_code, msg

        if stock_code is None or is_str(stock_code) is False:
            error_str = ERROR_STR_PREFIX + 'the type of stock_code param is wrong'
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            GetCapitalFlowQuery.pack_req,
            GetCapitalFlowQuery.unpack,
        )

        kargs = {
            "code": stock_code,
            "conn_id": self.get_sync_conn_id(),
            "start_date": start,
            "end_date": end,
            "period_type": period_type,
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'last_valid_time',
                'in_flow',
                'super_in_flow',
                'big_in_flow',
                'mid_in_flow',
                'sml_in_flow',
                'main_in_flow',
                'capital_flow_item_time',
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_financials_earnings_price_move(self, code, period_count=None):
        """
        获取个股财报日前后价格表现（F10），对应 Moomoo RequestReportCycleQuoteData。
        Get Financials Earnings Price Move
        :param period_count: 财报周期数量，默认 10，范围 1–50
        :return: 成功时 (RET_OK, DataFrame)，按日展开明细。
        """
        if code is None or is_str(code) is False:
            error_str = ERROR_STR_PREFIX + 'the type of code param is wrong'
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            GetFinancialsEarningsPriceMoveQuery.pack_req,
            GetFinancialsEarningsPriceMoveQuery.unpack,
        )
        kargs = {
            "code": code,
            "conn_id": self.get_sync_conn_id(),
            "period_count": period_count,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'fiscal_year',
                'financial_type',
                'period_text',
                'pub_trading_day',
                'pub_trading_day_str',
                'pub_type',
                'price_info_index',
                'day_offset',
                'trading_day',
                'trading_day_str',
                'close_price',
                'open_price',
                'highest_price',
                'lowest_price',
                'last_close_price',
                'option_iv',
                'option_hv',
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        return RET_ERROR, "empty data"

    def get_financials_earnings_price_history(self, code):
        """
        获取个股财报日前后股价历史（F10），对应 Moomoo CS_CmdID_PriceHistoryOnEarningsDays。
        Get Financials Earnings Price History
        """
        if code is None or is_str(code) is False:
            error_str = ERROR_STR_PREFIX + 'the type of code param is wrong'
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            GetFinancialsEarningsPriceHistoryQuery.pack_req,
            GetFinancialsEarningsPriceHistoryQuery.unpack,
        )
        kargs = {
            "code": code,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'fiscal_year',
                'financial_type',
                'period_text',
                'is_current',
                'pub_trading_day',
                'pub_trading_day_str',
                'pub_time',
                'pub_time_str',
                'pub_type',
                'predict_vola_ratio_newest',
                'predict_vola_ratio_highest',
                'predict_vola_val_newest',
                'predict_vola_val_highest',
                'option_iv_crush',
                'option_strike_date_iv_crush',
                'trading_day',
                'trading_day_str',
                'close_price',
                'open_price',
                'highest_price',
                'lowest_price',
                'last_close_price',
                'volume',
                'schedule_delta',
                'schedule_close_price',
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        return RET_ERROR, "empty data"

    def get_research_morningstar_report(self, code):
        """
        获取晨星研究详情。
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'

        query_processor = self._get_sync_query_processor(
            GetResearchMorningstarReportQuery.pack_req,
            GetResearchMorningstarReportQuery.unpack,
        )
        kargs = {
            "code": code,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ret

    def get_research_analyst_consensus(self, code):
        """
        获取分析师评级概述。
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'

        query_processor = self._get_sync_query_processor(
            GetResearchAnalystConsensusQuery.pack_req,
            GetResearchAnalystConsensusQuery.unpack,
        )
        kargs = {
            "code": code,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ret

    def get_research_rating_summary(self, code, rating_dimension_type=None, uid=None, num=None, next_key=None):
        """
        获取评级汇总或评级详情。
        rating_dimension_type: 1=机构维度（默认），2=分析师维度
        uid: 空=汇总列表；非空=指定机构/分析师的评级详情
        num: 单页条数（默认 10）
        next_key: 分页游标，首页传空；服务端回 "-1" 表示已取完
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'

        query_processor = self._get_sync_query_processor(
            GetResearchRatingSummaryQuery.pack_req,
            GetResearchRatingSummaryQuery.unpack,
        )
        kargs = {
            "code": code,
            "conn_id": self.get_sync_conn_id(),
            "rating_dimension_type": rating_dimension_type,
            "uid": uid,
            "num": num,
            "next_key": next_key,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ret

    def verification(self, verification_type=VerificationType.NONE, verification_op=VerificationOp.NONE, code=""):
        """图形验证码下载之后会将其存至固定路径，请到该路径下查看验证码
        Windows平台：%appdata%/com.futunn.FutuOpenD/F3CNN/PicVerifyCode.png
        非Windows平台：~/.com.futunn.FutuOpenD/F3CNN/PicVerifyCode.png
        注意：只有最后一次请求验证码会生效，重复请求只有最后一次的验证码有效"""

        """required int32 type = 1; //验证码类型, VerificationType
        required int32 op = 2; //操作, VerificationOp
        optional string code = 3; //验证码，请求验证码时忽略该字段，输入时必填"""

        query_processor = self._get_sync_query_processor(
            Verification.pack_req, Verification.unpack_rsp)
        kargs = {
            "verification_type": verification_type,
            "verification_op": verification_op,
            "code": code,
            "conn_id": self.get_sync_conn_id()
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code != RET_OK:
            return ret_code, msg
        else:
            return ret_code, data

    def get_delay_statistics(self, type_list, qot_push_stage, segment_list):
        """
        GetDelayStatistics
        qot_push_stage 行情推送统计的区间，行情推送统计时有效，QotPushStage
        type_list 统计数据类型，DelayStatisticsType [DelayStatisticsType.QOT_PUSH, DelayStatisticsType.REQ_REPLY]
        check segment_list 统计分段，默认100ms以下以2ms分段，100ms以上以500，1000，2000，-1分段，-1表示无穷大。
        """

        query_processor = self._get_sync_query_processor(
            GetDelayStatisticsQuery.pack_req,
            GetDelayStatisticsQuery.unpack,
        )

        kargs = {
            "type_list": type_list,
            "qot_push_stage": qot_push_stage,
            "segment_list": segment_list,
            "conn_id": self.get_sync_conn_id()
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, dict):
            ret_dic = dict()
            ret_dic["qot_push"] = ret["qot_push_all_statistics_list"]
            ret_dic["req_reply"] = ret["req_reply_statistics_list"]
            ret_dic["place_order"] = ret["place_order_statistics_list"]
            return RET_OK, ret_dic
        else:
            return RET_ERROR, "empty data"

    def get_technical_unusual(self, code, time_range=None, indicator_filters=None, language_id=None):
        """
        技术指标异动（SkillWrapAPI.TechnicalUnusual）。
        :param code: 股票名或代码等字符串，原样写入请求 stock_symbol，不做解析或规范化
        :param time_range: 时间范围（自然日天数），默认由服务端处理（约 7 日）
        :param indicator_filters: 指标名列表，默认全部
        :param language_id: 语种 0 简中 1 繁中 2 英文 4 泰语 5 日语
        :return: 成功 (RET_OK, dict)，含 err_code/time_range/content；失败 (RET_ERROR, retMsg)
        """
        if indicator_filters is not None and not isinstance(indicator_filters, list):
            return RET_ERROR, "indicator_filters must be a list or None"
        query_processor = self._get_sync_query_processor(
            SkillWrapTechnicalUnusualQuery.pack_req,
            SkillWrapTechnicalUnusualQuery.unpack,
        )
        ret_code, msg, data = query_processor(
            code=code,
            time_range=time_range,
            indicator_filters=indicator_filters or [],
            language_id=language_id,
            conn_id=self.get_sync_conn_id(),
        )
        if ret_code != RET_OK:
            return ret_code, msg
        return RET_OK, data

    def get_financial_unusual(self, code, time_range=None, analysis_dimensions=None, language_id=None):
        """
        财务异动（SkillWrapAPI.FinancialUnusual）。
        :param code: 股票名或代码等字符串，原样写入 stock_symbol
        :param analysis_dimensions: 分析维度名列表，默认全部
        """
        if analysis_dimensions is not None and not isinstance(analysis_dimensions, list):
            return RET_ERROR, "analysis_dimensions must be a list or None"
        query_processor = self._get_sync_query_processor(
            SkillWrapFinancialUnusualQuery.pack_req,
            SkillWrapFinancialUnusualQuery.unpack,
        )
        ret_code, msg, data = query_processor(
            code=code,
            time_range=time_range,
            analysis_dimensions=analysis_dimensions or [],
            language_id=language_id,
            conn_id=self.get_sync_conn_id(),
        )
        if ret_code != RET_OK:
            return ret_code, msg
        return RET_OK, data

    def get_derivative_unusual(self, code, time_range=None, analysis_dimensions=None, language_id=None):
        """
        衍生品异动（SkillWrapAPI.DerivativeUnusual）。
        :param code: 股票名或代码等字符串，原样写入 stock_symbol
        """
        if analysis_dimensions is not None and not isinstance(analysis_dimensions, list):
            return RET_ERROR, "analysis_dimensions must be a list or None"
        query_processor = self._get_sync_query_processor(
            SkillWrapDerivativeUnusualQuery.pack_req,
            SkillWrapDerivativeUnusualQuery.unpack,
        )
        ret_code, msg, data = query_processor(
            code=code,
            time_range=time_range,
            analysis_dimensions=analysis_dimensions or [],
            language_id=language_id,
            conn_id=self.get_sync_conn_id(),
        )
        if ret_code != RET_OK:
            return ret_code, msg
        return RET_OK, data

    def modify_user_security(self, group_name, op, code_list):
        """
        ModifyUserSecurity
        修改用户自选股列表信息
        """
        if is_str(code_list):
            code_list = code_list.split(',')
        elif isinstance(code_list, list):
            pass
        else:
            return RET_ERROR, "code list must be like ['HK.00001', 'HK.00700'] or 'HK.00001,HK.00700'"
        code_list = unique_and_normalize_list(code_list)
        for code in code_list:
            if code is None or is_str(code) is False:
                error_str = ERROR_STR_PREFIX + "the type of param in code_list is wrong"
                return RET_ERROR, error_str

        ret, op_value = ModifyUserSecurityOp.to_number(op)
        if ret is not True:
            return RET_ERROR, op_value

        query_processor = self._get_sync_query_processor(
            ModifyUserSecurityQuery.pack_req,
            ModifyUserSecurityQuery.unpack,
        )

        kargs = {
            "group_name": group_name,
            "op": op_value,
            "code_list": code_list,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        else:
            return RET_OK, "success"

    def get_user_security(self, group_name):
        """
        GetUserSecurity
        """
        if not isinstance(group_name, str):
            return RET_ERROR, "group_name need str"

        query_processor = self._get_sync_query_processor(
            GetUserSecurityQuery.pack_req,
            GetUserSecurityQuery.unpack,
        )

        kargs = {
            "group_name": group_name,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'code', 'name', 'lot_size', 'stock_type', 'stock_child_type', 'stock_owner',
                'option_type', 'strike_time', 'strike_price', 'suspension',
                'listing_date', 'stock_id', 'delisting',
                'main_contract', 'last_trade_time'
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_stock_filter(self, market, filter_list=None, plate_code=None, begin=0, num=200):
        """
        Qot_StockFilter
        :param plate_code: 板块代码, string, 例如，”SH.BK0001”，”SH.BK0002”，先利用获取子版块列表函数获取子版块代码
        """
        if not Market.if_has_key(market):
            error_str = ERROR_STR_PREFIX + "the value of market param is wrong "
            return RET_ERROR, error_str

        if plate_code is not None and is_str(plate_code) is False:
            error_str = ERROR_STR_PREFIX + "the type of plate_code is wrong"
            return RET_ERROR, error_str

        """容错容错"""
        if filter_list is None:
            filter_list = []

        if filter_list is not None and (isinstance(filter_list, SimpleFilter) or isinstance(filter_list,
                                                                                            AccumulateFilter) or isinstance(
                filter_list, FinancialFilter) or isinstance(filter_list, PatternFilter) or isinstance(filter_list,
                                                                                                      CustomIndicatorFilter)):
            filter_list = [filter_list]
        if filter_list is not None and not isinstance(filter_list, list):
            error_str = ERROR_STR_PREFIX + "the type of filter_list is wrong"
            return RET_ERROR, error_str

        for filter in filter_list:
            if not (isinstance(filter, SimpleFilter) or isinstance(filter, AccumulateFilter) or isinstance(filter,
                                                                                                           FinancialFilter) or isinstance(
                    filter, PatternFilter) or isinstance(filter, CustomIndicatorFilter)):
                error_str = ERROR_STR_PREFIX + "the item of filter_list is wrong"
                return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            StockFilterQuery.pack_req,
            StockFilterQuery.unpack,
        )

        kargs = {
            "market": market,
            "filter_list": filter_list,
            "plate_code": plate_code,
            "begin": begin,
            "num": num,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        else:
            return RET_OK, ret

    def get_code_change(self, code_list=[], time_filter_list=[], type_list=[]):
        """
        股票更换代码或者中途并行交易临时代码信息

        :param code_list: 股票列表，例如['HK.00700']
        :param time_filter_list: 时间过滤列表, 例如[t1, t2], t1 = TimeFilter(type = TimeFilterType.PUBLIC, begin_time = "2019-12-31",end_time = "2019-12-30")
        :param type_list: 类型过滤列表，例如[CodeChangeType.GEM_TO_MAIN]
        :return: (ret, data)

                ret == RET_OK 返回pd dataframe数据，data.DataFrame数据, 数据列格式如下

                ret != RET_OK 返回错误字符串

                =====================   ===========   =================================================================================
                参数                      类型                        说明
                =====================   ===========   =================================================================================
                code_change_info_type   str            类型
                security                str            主代码，在创业板转主板中表示主板
                related_security        str            关联代码，在创业板转主板中表示创业板，在剩余事件中表示临时代码
                public_time             str            公布时间
                effective_time          str            生效时间
                end_time                str            结束时间，在创业板转主板事件不存在该字段，在剩余事件表示临时代码交易结束时间
                =====================   ===========   =================================================================================
        """
        time_filter_list = unique_and_normalize_list(time_filter_list)
        for time_filter in time_filter_list:
            r, n = TimeFilterType.to_number(time_filter.type)
            if time_filter.type is None or r is False:
                error_str = ERROR_STR_PREFIX + "the type of param in time_filter is wrong"
                return RET_ERROR, error_str

        if is_str(code_list):
            code_list = code_list.split(',')
        elif isinstance(code_list, list):
            pass
        else:
            return RET_ERROR, "code list must be like ['HK.00001', 'HK.00700'] or 'HK.00001,HK.00700'"
        code_list = unique_and_normalize_list(code_list)
        for code in code_list:
            if code is None or is_str(code) is False:
                error_str = ERROR_STR_PREFIX + "the type of param in code_list is wrong"
                return RET_ERROR, error_str

        if is_str(type_list):
            type_list = type_list.split(',')
        elif isinstance(type_list, list):
            pass
        else:
            return RET_ERROR, "code list must be like [CodeChangeType.CHANGE_LOT, CodeChangeType.GEMTOMAIN] or 'CodeChangeType.CHANGE_LOT,CodeChangeType.GEMTOMAIN'"
        type_list = unique_and_normalize_list(type_list)
        for type in type_list:
            r, n = CodeChangeType.to_number(type)
            if type is None or r is False:
                error_str = ERROR_STR_PREFIX + "the type of param in type_list is wrong"
                return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            GetCodeChangeQuery.pack_req,
            GetCodeChangeQuery.unpack,
        )

        kargs = {
            "code_list": code_list,
            "time_filter_list": time_filter_list,
            "type_list": type_list,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'code_change_info_type',
                'code',
                'related_code',
                'public_time',
                'effective_time',
                'end_time',
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_ipo_list(self, market):
        """
        获取某个市场的ipo列表
        :param market: str, see Market. 支持 HK/US/SH/SZ/SG/MY/JP 市场
        :return: (ret, data)

                ret == RET_OK, data为pd.DataFrame，列定义如下：

                基本数据（所有市场通用）：
                    code: 股票代码
                    name: 股票名称
                    list_time: 上市日期字符串
                    list_timestamp: 上市日期时间戳

                A股额外数据：
                    apply_code: 申购代码
                    issue_size: 发行总数
                    online_issue_size: 网上发行量
                    apply_upper_limit: 申购上限
                    apply_limit_market_value: 顶格申购需配市值
                    is_estimate_ipo_price: 是否预估发行价
                    ipo_price: 发行价
                    industry_pe_rate: 行业市盈率
                    is_estimate_winning_ratio: 是否预估中签率
                    winning_ratio: 中签率
                    issue_pe_rate: 发行市盈率
                    apply_time: 申购日期字符串
                    apply_timestamp: 申购日期时间戳
                    winning_time: 公布中签日期字符串
                    winning_timestamp: 公布中签日期时间戳
                    is_has_won: 是否已中签
                    winning_num_data: 中签号数据

                港股额外数据：
                    ipo_price_min: 最低发行价
                    ipo_price_max: 最高发行价
                    list_price: 上市开盘价
                    lot_size: 每手股数
                    entrance_price: 入场费
                    is_subscribe_status: 是否可认购
                    apply_end_time: 截止认购日期字符串
                    apply_end_timestamp: 截止认购日期时间戳

                美股额外数据：
                    ipo_price_min: 最低发行价
                    ipo_price_max: 最高发行价
                    issue_size: 发行量

                新加坡额外数据：
                    ipo_price_min: 最低发行价
                    ipo_price_max: 最高发行价
                    issue_size: 发行量
                    apply_start_time: 开始认购日期字符串
                    apply_start_timestamp: 开始认购日期时间戳
                    apply_end_time: 截止认购日期字符串
                    apply_end_timestamp: 截止认购日期时间戳
                    winning_time: 公布中签日期字符串
                    winning_timestamp: 公布中签日期时间戳

                马来西亚额外数据：
                    offer_price: 发行价
                    issue_size: 发行量
                    apply_start_time: 开始认购日期字符串
                    apply_start_timestamp: 开始认购日期时间戳
                    apply_end_time: 截止认购日期字符串
                    apply_end_timestamp: 截止认购日期时间戳
                    winning_time: 公布中签日期字符串
                    winning_timestamp: 公布中签日期时间戳

                日本额外数据：
                    ipo_price_min: 最低发行价
                    ipo_price_max: 最高发行价
                    issue_size: 发行量

                ret != RET_OK, data为错误信息字符串
        """
        if not Market.if_has_key(market):
            error_str = ERROR_STR_PREFIX + "the value of market param is wrong "
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            GetIpoListQuery.pack_req,
            GetIpoListQuery.unpack,
        )

        kargs = {
            'conn_id': self.get_sync_conn_id(),
            'market': market,
            'security_firm': self.__security_firm
        }
        ret, msg, data = query_processor(**kargs)
        if ret != RET_OK:
            return ret, msg

        col_dict = OrderedDict()
        col_dict.update((row[0], True) for row in pb_field_map_BasicIpoData)
        col_dict.update((row[0], True) for row in pb_field_map_CNIpoExData)
        col_dict.update((row[0], True) for row in pb_field_map_HKIpoExData)
        col_dict.update((row[0], True) for row in pb_field_map_USIpoExData)
        col_dict.update((row[0], True) for row in pb_field_map_SGIpoExData)
        col_dict.update((row[0], True) for row in pb_field_map_MYIpoExData)
        col_dict.update((row[0], True) for row in pb_field_map_JPIpoExData)

        return RET_OK, pd.DataFrame(data, columns=col_dict.keys())

    def get_future_info(self, code_list):
        """
         获取期货合约资料
        :param code_list: 期货
        :return: (ret, data)
        ret != RET_OK 返回错误字符串
        ret == RET_OK data为DataFrame类型，字段如下:
        =========================   ===========   =========================
        参数                         类型           说明
        =========================   ===========   =========================
        code                        str            股票代码
        name                        str            股票名称
        owner                       string         标的
        exchange                    string         交易所
        type                        string         合约类型
        size                        float          合约规模
        size_unit                   string         合约规模单位
        price_currency              string         报价货币
        price_unit                  string         报价单位
        min_change                  float          最小变动
        min_change_unit             string         最小变动的单位
        trade_time                  string         交易时间
        time_zone                   string         时区
        last_trade_time             string         最后交易时间
        exchange_format_url         string         交易所规格url
        =========================   ===========   =========================
        """
        if is_str(code_list):
            code_list = code_list.split(',')
        elif isinstance(code_list, list):
            pass
        else:
            return RET_ERROR, "code list must be like ['HK.00001', 'HK.00700'] or 'HK.00001,HK.00700'"
        code_list = unique_and_normalize_list(code_list)

        if not code_list:
            error_str = ERROR_STR_PREFIX + "the type of code param is wrong"
            return RET_ERROR, error_str

        for code in code_list:
            if code is None or is_str(code) is False:
                error_str = ERROR_STR_PREFIX + "the type of param in code_list is wrong"
                return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            GetFutureInfoQuery.pack_req,
            GetFutureInfoQuery.unpack,
        )

        kargs = {
            "code_list": code_list,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        else:
            col_list = [
                'code',
                'name',
                'owner',
                'exchange',
                'type',
                'size',
                'size_unit',
                'price_currency',
                'price_unit',
                'min_change',
                'min_change_unit',
                'trade_time',
                'time_zone',
                'last_trade_time',
                'exchange_format_url',
                'origin_code',
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame

    def set_price_reminder(self, code, op, key=None, reminder_type=None, reminder_freq=None, value=None, note=None,
                           reminder_session_list = [PriceReminderMarketStatus.OPEN, PriceReminderMarketStatus.US_PRE, PriceReminderMarketStatus.US_AFTER]):
        """
         新增、删除、修改、启用、禁用 某只股票的到价提醒，每只股票每种类型最多可设置10个提醒
         注意：
            1. API 中成交量设置统一以股为单位。但是牛牛客户端中，A 股是以为手为单位展示
            2. 到价提醒类型，存在最小精度，如下：
                TURNOVER_UP：成交额最小精度为 10 元（人民币元，港元，美元）。传入的数值会自动向下取整到最小精度的整数倍。
                    如果设置【00700成交额102元提醒】，设置后会得到【00700成交额100元提醒】；如果设置【00700 成交额 8 元提醒】，设置后会得到【00700 成交额 0 元提醒】
                VOLUME_UP：A 股成交量最小精度为 1000 股，其他市场股票成交量最小精度为 10 股。传入的数值会自动向下取整到最小精度的整数倍。
                BID_VOL_UP、ASK_VOL_UP：A 股的买一卖一量最小精度为 100 股。传入的数值会自动向下取整到最小精度的整数倍。
                其余到价提醒类型精度支持到小数点后 3 位
        :param code: 股票
        :param op：SetPriceReminderOp，操作类型
        :param key: int64，标识，新增的情况不需要填
        :param reminder_type: PriceReminderType，到价提醒的频率，删除、启用、禁用的情况下会忽略该入参
        :param reminder_freq: PriceReminderFreq，到价提醒的频率，删除、启用、禁用的情况下会忽略该入参
        :param value: float，提醒值，删除、启用、禁用的情况下会忽略该入参
        :param note: str，用户设置的备注，删除、启用、禁用的情况下会忽略该入参
        :param reminder_session_list: list[PriceReminderMarketStatus]，到价提醒的时段列表，删除、启用、禁用的情况下会忽略该入参
        :return: (ret, data)
        ret != RET_OK 返回错误字符串
        ret == RET_OK data为key
        """
        if code is None or is_str(code) is False:
            error_str = ERROR_STR_PREFIX + 'the type of code param is wrong'
            return RET_ERROR, error_str

        r, v = SetPriceReminderOp.to_number(op)
        if r is False:
            error_str = ERROR_STR_PREFIX + "the type of param in op is wrong"
            return RET_ERROR, error_str

        if reminder_type is not None :
            r, v = PriceReminderType.to_number(reminder_type)
            if r is False:
                error_str = ERROR_STR_PREFIX + "the type of param in reminder_type is wrong"
                return RET_ERROR, error_str

        if reminder_freq is not None :
            r, v = PriceReminderFreq.to_number(reminder_freq)
            if r is False:
                error_str = ERROR_STR_PREFIX + "the type of param in reminder_freq is wrong"
                return RET_ERROR, error_str
            
        _tmp_reminder_session_list = []
        for _reminder_session in reminder_session_list:
            if _reminder_session is PriceReminderMarketStatus.NONE:
                continue
            _tmp_reminder_session_list.append(_reminder_session)

        # 如果没有传入reminder_session_list，则设置默认值
        if len(_tmp_reminder_session_list) == 0:
            _tmp_reminder_session_list = [PriceReminderMarketStatus.OPEN, PriceReminderMarketStatus.US_PRE, PriceReminderMarketStatus.US_AFTER]

        query_processor = self._get_sync_query_processor(
            SetPriceReminderQuery.pack_req,
            SetPriceReminderQuery.unpack,
        )

        kargs = {
            "code": code,
            "op": op,
            "key": key,
            "reminder_type": reminder_type,
            "reminder_freq": reminder_freq,
            "value": value,
            "note": note,
            "conn_id": self.get_sync_conn_id(),
            "reminder_session_list": _tmp_reminder_session_list,
            "security_firm": self.__security_firm
        }
        ret_code, msg, key = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        else:
            return RET_OK, key

    def get_price_reminder(self, code=None, market=None):
        """
         获取对某只股票(某个市场)设置的到价提醒列表
        :param code: 获取该股票的到价提醒，code和market二选一，都存在的情况下code优先
        :param market: 获取该市场的到价提醒，注意传入沪深都会认为是A股市场
        :return: (ret, data)
        ret != RET_OK 返回错误字符串
        ret == RET_OK data为DataFrame类型，字段如下:
        =========================   ==================   =========================
        参数                         类型                 说明
        =========================   ==================   =========================
        code                        str                  股票代码
        key                         int64                标识，用于修改到价提醒
        reminder_type               PriceReminderType    到价提醒的类型
        reminder_freq               PriceReminderFreq    到价提醒的频率
        value                       float                提醒值
        enable                      bool                 是否启用
        note                        string               备注，最多10个字符
        reminder_session_list       list                 提醒时段，枚举参考PriceReminderMarketStatus
        =========================   ==================   =========================
        """
        if code is not None and is_str(code) is False:
            error_str = ERROR_STR_PREFIX + 'the type of code param is wrong'
            return RET_ERROR, error_str

        if code is None and market is not None and not Market.if_has_key(market):
            error_str = ERROR_STR_PREFIX + "the type of param in market is wrong"
            return RET_ERROR, error_str

        if code is None and market is None:
            error_str = ERROR_STR_PREFIX + "must be use one of these params(code, market)"
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            GetPriceReminderQuery.pack_req,
            GetPriceReminderQuery.unpack,
        )

        kargs = {
                "code": code,
                "market": market,
                "conn_id": self.get_sync_conn_id(),
                "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'code',
                'name',
                'key',
                'reminder_type',
                'reminder_freq',
                'value',
                'enable',
                'note',
                'reminder_session_list'
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_user_security_group(self, group_type = UserSecurityGroupType.ALL):
        """
         获取自选股分组列表
        :param group_type: UserSecurityGroupType，分组类型
        :return: (ret, data)
        ret != RET_OK 返回错误字符串
        ret == RET_OK data为DataFrame类型，字段如下:
        =========================   ==================   ================================
        参数                         类型                 说明
        =========================   ==================   ================================
        group_name                   str                  分组名
        group_type                   str                  UserSecurityGroupType，分组类型
        =========================   ==================   ================================
        """
        r, v = UserSecurityGroupType.to_number(group_type)
        if r is False:
            error_str = ERROR_STR_PREFIX + "the type of param in group_type is wrong"
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            GetUserSecurityGroupQuery.pack_req,
            GetUserSecurityGroupQuery.unpack,
        )

        kargs = {
            "group_type": group_type,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'group_name',
                'group_type'
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_market_state(self, code_list):
        """
         获取股票对应市场的市场状态
        :param code_list 股票列表
        :return: (ret, data)
        ret != RET_OK 返回错误字符串
        ret == RET_OK data为DataFrame类型，字段如下:
        =========================   ==================   ================================
        参数                         类型                 说明
        =========================   ==================   ================================
        code                         str                  股票代码
        stock_name                   str                  股票名称
        market_state                 MarketState          市场状态
        =========================   ==================   ================================
        """
        if is_str(code_list):
            code_list = code_list.split(',')
        elif isinstance(code_list, list) and len(code_list) > 0:
            pass
        else:
            return RET_ERROR, "code list must be like ['HK.00001', 'HK.00700'] or 'HK.00001,HK.00700'"
        code_list = unique_and_normalize_list(code_list)
        for code in code_list:
            if code is None or is_str(code) is False:
                error_str = ERROR_STR_PREFIX + "the type of param in code_list is wrong"
                return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            GetMarketStateQuery.pack_req,
            GetMarketStateQuery.unpack,
        )

        kargs = {
            "code_list": code_list,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'code',
                'stock_name',
                'market_state'
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_option_expiration_date(self, code, index_option_type=IndexOptionType.NORMAL):
        """
         获取期权链到期日
        :param code 标的股票代码
        :param index_option_type: 指数期权类型，IndexOptionType
        :return: (ret, data)
        ret != RET_OK 返回错误字符串
        ret == RET_OK data为DataFrame类型，字段如下:
        ============================   ==================   ================================
        参数                            类型                 说明
        ============================   ==================   ================================
        strike_time                    str                  期权链行权日（港股和 A 股市场默认是北京时间，美股市场默认是美东时间）
        option_expiry_date_distance    int                  距离到期日天数，负数表示已过期
        expiration_cycle               ExpirationCycle      交割周期（仅用于香港指数期权）
        ============================   ==================   ================================
        """

        if code is None or is_str(code) is False:
            error_str = ERROR_STR_PREFIX + "the type of code param is wrong"
            return RET_ERROR, error_str

        r, n = IndexOptionType.to_number(index_option_type)
        if r is False:
            msg = ERROR_STR_PREFIX + "the type of index_option_type param is wrong"
            return RET_ERROR, msg

        query_processor = self._get_sync_query_processor(
            GetOptionExpirationDate.pack_req,
            GetOptionExpirationDate.unpack,
        )

        kargs = {
            "code": code,
            "index_option_type": index_option_type,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'strike_time',
                'option_expiry_date_distance',
                'expiration_cycle'
            ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        else:
            return RET_ERROR, "empty data"

    def get_option_market_statistic(self, option_market, data_type, begin_time=None, end_time=None, page_req_key=None):
        """
        获取期权市场统计数据（成交量/持仓量）

        :param option_market: 期权市场类型，OptionMarket
        :param data_type: 数据类型，OptionStatisticDataType（成交量或持仓量）
        :param begin_time: 开始日期，字符串格式 'YYYY-MM-DD'
        :param end_time: 结束日期，字符串格式 'YYYY-MM-DD'，时间跨度超过一年时自动分页
        :param page_req_key: 分页请求的key。如果数据较多，后续请求需传入上次返回的page_req_key。初始请求传None。
        :return: (ret, data, page_req_key)

            ret == RET_OK data为DataFrame类型，page_req_key为分页请求key（无更多数据时为None）

            ret != RET_OK 返回错误字符串

            ============   ======   ==========================
            参数           类型     说明
            ============   ======   ==========================
            time           str      交易日时间字符串
            timestamp      float    交易日时间戳
            call_value     int      看涨期权合计值
            put_value      int      看跌期权合计值
            total_value    int      总值（callValue + putValue）
            ratio          float    Put/Call比值（callValue为0时为N/A）
            ============   ======   ==========================

        :example:

        .. code:: python

            from futu import *
            quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
            ret, data, page_req_key = quote_ctx.get_option_market_statistic(OptionMarket.US_SECURITY, OptionStatisticDataType.VOLUME, begin_time='2024-01-01', end_time='2024-06-01')
            print(ret, data)
            while page_req_key is not None:
                ret, data, page_req_key = quote_ctx.get_option_market_statistic(OptionMarket.US_SECURITY, OptionStatisticDataType.VOLUME, begin_time='2024-01-01', end_time='2024-06-01', page_req_key=page_req_key)
                print(ret, data)
            quote_ctx.close()
        """
        next_page_req_key = None

        if not OptionMarket.if_has_key(option_market):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of option_market param is wrong", next_page_req_key

        if not OptionStatisticDataType.if_has_key(data_type):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of data_type param is wrong", next_page_req_key

        ret, msg, begin_time, end_time = normalize_start_end_date(
            begin_time, end_time, 364, default_time_end='00:00:00')
        if ret != RET_OK:
            return ret, msg, next_page_req_key

        query_processor = self._get_sync_query_processor(
            GetOptionMarketStatistic.pack_req,
            GetOptionMarketStatistic.unpack_rsp,
        )

        kargs = {
            "option_market": option_market,
            "data_type": data_type,
            "begin_time": begin_time,
            "end_time": end_time,
            "next_page_key": page_req_key,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, content = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, next_page_req_key

        data_list, has_next, next_page_req_key = content

        col_list = ['time', 'timestamp', 'call_value', 'put_value', 'total_value', 'ratio']
        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page_req_key

    def get_option_underlying_his_statistic(self, code, index_option_type=IndexOptionType.NORMAL,
                                       begin_time=None, end_time=None, page_req_key=None):
        """
        获取期权标的历史统计数据

        :param code: 标的股票代码，例如 'US.AAPL'
        :param index_option_type: 指数期权类型，IndexOptionType，仅恒指/国指等指数期权需要
        :param begin_time: 开始日期，字符串格式 'YYYY-MM-DD'
        :param end_time: 结束日期，字符串格式 'YYYY-MM-DD'
        :param page_req_key: 分页请求的key。如果数据较多，后续请求需传入上次返回的page_req_key。初始请求传None。
        :return: (ret, data, page_req_key)

            ret == RET_OK data为DataFrame类型，page_req_key为分页请求key（无更多数据时为None）

            ret != RET_OK 返回错误字符串

            ============================   ======   ==========================================
            参数                           类型     说明
            ============================   ======   ==========================================
            code                           str      股票代码
            name                           str      股票名称
            time                           str      交易日时间字符串
            timestamp                      float    交易日时间戳
            option_volume                  int      期权总成交量（call_volume + put_volume）
            call_volume                    int      看涨期权成交量
            put_volume                     int      看跌期权成交量
            put_call_volume_ratio          float    Put/Call成交量比
            option_open_interest           int      期权总持仓量（call + put）
            call_open_interest             int      看涨期权持仓量（T-1延迟）
            put_open_interest              int      看跌期权持仓量（T-1延迟）
            put_call_open_interest_ratio   float    Put/Call持仓量比
            underlying_price               float    标的价格
            ============================   ======   ==========================================

        :example:

        .. code:: python

            from futu import *
            quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
            ret, data, page_req_key = quote_ctx.get_option_underlying_his_statistic('US.AAPL', begin_time='2024-01-01', end_time='2024-06-01')
            print(ret, data)
            while page_req_key is not None:
                ret, data, page_req_key = quote_ctx.get_option_underlying_his_statistic('US.AAPL', begin_time='2024-01-01', end_time='2024-06-01', page_req_key=page_req_key)
                print(ret, data)
            quote_ctx.close()
        """
        next_page_req_key = None

        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + "the type of code param is wrong", next_page_req_key

        if not IndexOptionType.if_has_key(index_option_type):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of index_option_type param is wrong", next_page_req_key

        ret, msg, begin_time, end_time = normalize_start_end_date(
            begin_time, end_time, 364, default_time_end='00:00:00')
        if ret != RET_OK:
            return ret, msg, next_page_req_key

        query_processor = self._get_sync_query_processor(
            GetOptionUnderlyingHisStatistic.pack_req,
            GetOptionUnderlyingHisStatistic.unpack_rsp,
        )

        kargs = {
            "code": code,
            "begin_time": begin_time,
            "end_time": end_time,
            "index_option_type": index_option_type,
            "next_page_key": page_req_key,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, content = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, next_page_req_key

        data_list, has_next, next_page_req_key = content

        col_list = ['code', 'name', 'time', 'timestamp',
                     'option_volume', 'call_volume', 'put_volume', 'put_call_volume_ratio',
                     'option_open_interest', 'call_open_interest', 'put_open_interest', 'put_call_open_interest_ratio',
                     'underlying_price']
        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page_req_key

    def get_option_underlying_overview(self, code_list, index_option_type=IndexOptionType.NORMAL):
        """
        获取期权标的总览数据（最多500个）

        :param code_list: 标的股票代码列表，例如 ['US.AAPL', 'US.TSLA']
        :param index_option_type: 指数期权类型，IndexOptionType，仅恒指/国指等指数期权需要
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame类型，字段如下:

            =====================   ======   =======================================
            参数                    类型     说明
            =====================   ======   =======================================
            code                    str      股票代码
            name                    str      标的名称
            call_volume             int      看涨期权成交量
            put_volume              int      看跌期权成交量
            call_open_interest      int      看涨期权持仓量（T-1延迟）
            put_open_interest       int      看跌期权持仓量（T-1延迟）
            iv                      float    隐含波动率（百分比）
            iv_rank                 float    IV排名百分位（百分比）
            iv_percentile           float    IV百分位（百分比）
            pre_iv                  float    前一交易日IV（百分比）
            hv_30d                  float    30日历史波动率（百分比）
            hv_30d_percentile       float    30日HV百分位
            hv_60d                  float    60日历史波动率（百分比）
            hv_60d_percentile       float    60日HV百分位
            hv_90d                  float    90日历史波动率（百分比）
            hv_90d_percentile       float    90日HV百分位
            hv_120d                 float    120日历史波动率（百分比）
            hv_120d_percentile      float    120日HV百分位
            hv_365d                 float    365日历史波动率（百分比）
            hv_365d_percentile      float    365日HV百分位
            =====================   ======   =======================================
        """
        if not isinstance(code_list, list):
            return RET_ERROR, ERROR_STR_PREFIX + "code_list must be a list"

        if not IndexOptionType.if_has_key(index_option_type):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of index_option_type param is wrong"

        code_list = unique_and_normalize_list(code_list)
        if not code_list:
            return RET_ERROR, ERROR_STR_PREFIX + "code_list is empty"

        query_processor = self._get_sync_query_processor(
            GetOptionUnderlyingOverview.pack_req,
            GetOptionUnderlyingOverview.unpack_rsp,
        )

        kargs = {
            "code_list": code_list,
            "index_option_type": index_option_type,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = ['code', 'name', 'call_volume', 'put_volume',
                     'call_open_interest', 'put_open_interest',
                     'iv', 'iv_rank', 'iv_percentile', 'pre_iv',
                     'hv_30d', 'hv_30d_percentile',
                     'hv_60d', 'hv_60d_percentile',
                     'hv_90d', 'hv_90d_percentile',
                     'hv_120d', 'hv_120d_percentile',
                     'hv_365d', 'hv_365d_percentile']
        return RET_OK, pd.DataFrame(data_list, columns=col_list)

    def get_option_underlying_his_volatility(self, code, index_option_type=IndexOptionType.NORMAL,
                                        begin_time=None, end_time=None, page_req_key=None):
        """
        获取期权标的历史波动率数据

        :param code: 标的股票代码，例如 'US.AAPL'
        :param index_option_type: 指数期权类型，IndexOptionType，仅恒指/国指等指数期权需要
        :param begin_time: 开始日期，字符串格式 'YYYY-MM-DD'
        :param end_time: 结束日期，字符串格式 'YYYY-MM-DD'
        :param page_req_key: 分页请求的key。如果数据较多，后续请求需传入上次返回的page_req_key。初始请求传None。
        :return: (ret, data, page_req_key)

            ret == RET_OK data为DataFrame类型，page_req_key为分页请求key（无更多数据时为None）

            ret != RET_OK 返回错误字符串

            =================   ======   =========================================
            参数                类型     说明
            =================   ======   =========================================
            code                str      股票代码
            name                str      股票名称
            time                str      交易日时间字符串
            timestamp           float    交易日时间戳
            iv                  float    隐含波动率（百分比）
            hv                  float    历史波动率（百分比）
            underlying_price    float    标的收盘价（当日为标记价）
            =================   ======   =========================================

        :example:

        .. code:: python

            from futu import *
            quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
            ret, data, page_req_key = quote_ctx.get_option_underlying_his_volatility('US.AAPL', begin_time='2024-01-01', end_time='2024-06-01')
            print(ret, data)
            while page_req_key is not None:
                ret, data, page_req_key = quote_ctx.get_option_underlying_his_volatility('US.AAPL', begin_time='2024-01-01', end_time='2024-06-01', page_req_key=page_req_key)
                print(ret, data)
            quote_ctx.close()
        """
        next_page_req_key = None

        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + "the type of code param is wrong", next_page_req_key

        if not IndexOptionType.if_has_key(index_option_type):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of index_option_type param is wrong", next_page_req_key

        ret, msg, begin_time, end_time = normalize_start_end_date(
            begin_time, end_time, 364, default_time_end='00:00:00')
        if ret != RET_OK:
            return ret, msg, next_page_req_key

        query_processor = self._get_sync_query_processor(
            GetOptionUnderlyingHisVolatility.pack_req,
            GetOptionUnderlyingHisVolatility.unpack_rsp,
        )

        kargs = {
            "code": code,
            "begin_time": begin_time,
            "end_time": end_time,
            "index_option_type": index_option_type,
            "next_page_key": page_req_key,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, content = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, next_page_req_key

        data_list, has_next, next_page_req_key = content

        col_list = ['code', 'name', 'time', 'timestamp', 'iv', 'hv', 'underlying_price']
        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page_req_key

    def get_option_underlying_rank(self, option_market, sort_type, sort_direction=None,
                                    count=None, trading_date=None, filter_list=None, page=None):
        """
        获取期权热门标的排行

        :param option_market: 期权市场类型，OptionMarket
        :param sort_type: 排序字段，UnderlyingRankSortType
        :param sort_direction: 排序方向，0=降序(默认), 1=升序
        :param count: 每页数量[1,200]，不指定默认200
        :param trading_date: 交易日，字符串格式 'YYYY-MM-DD'，None返回最新排行
        :param filter_list: 筛选条件列表，UnderlyingRankFilter对象列表(AND关系)
        :param page: 分页游标，首次请求传None，翻页时传上次返回的next_page
        :return: (ret, data, next_page, all_count)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame类型，字段如下:

            ======================   ======   ==========================================
            参数                     类型     说明
            ======================   ======   ==========================================
            code                     str      标的股票代码
            name                     str      标的名称
            total_volume             int      期权总成交量
            total_open_interest      int      期权总持仓量
            volume_ratio             float    Put/Call成交量比值（百分比）
            open_interest_ratio      float    Put/Call持仓量比值（百分比）
            iv                       float    隐含波动率（百分比）
            iv_rank                  float    IV排名百分位（百分比）
            iv_percentile            float    IV百分位（百分比）
            price                    float    标的最新价
            change_ratio             float    标的涨跌幅（小数）
            iv_change                float    IV变化率（百分比）
            hv                       float    历史波动率（百分比）
            hv_change                float    HV变化率（百分比）
            market_cap               float    市值
            trading_date             str      排行数据对应交易日
            trading_timestamp        float    排行数据对应交易日时间戳
            ======================   ======   ==========================================

            next_page: 下一页游标（None表示无下一页）
            all_count: 符合条件的总数据量
        """
        if not OptionMarket.if_has_key(option_market):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of option_market param is wrong", None, None

        if not UnderlyingRankSortType.if_has_key(sort_type):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of sort_type param is wrong", None, None

        if sort_direction is not None and sort_direction not in (0, 1):
            return RET_ERROR, ERROR_STR_PREFIX + "sort_direction must be 0 (descending) or 1 (ascending)", None, None

        if count is not None and (not isinstance(count, int) or count <= 0 or count > 200):
            return RET_ERROR, ERROR_STR_PREFIX + "count must be a positive integer between 1 and 200", None, None

        query_processor = self._get_sync_query_processor(
            GetOptionUnderlyingRank.pack_req,
            GetOptionUnderlyingRank.unpack_rsp,
        )

        kargs = {
            "option_market": option_market,
            "sort_type": sort_type,
            "sort_direction": sort_direction,
            "count": count,
            "trading_date": trading_date,
            "filter_list": filter_list,
            "page": page,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None, None

        data_list, next_page, all_count = data
        col_list = ['code', 'name', 'total_volume', 'total_open_interest',
                     'volume_ratio', 'open_interest_ratio',
                     'iv', 'iv_rank', 'iv_percentile',
                     'price', 'change_ratio', 'iv_change',
                     'hv', 'hv_change', 'market_cap',
                     'trading_date', 'trading_timestamp']
        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page, all_count

    def get_option_rank(self, option_market, sort_type, count=None, trading_date=None,
                        sort_direction=None, page=None, filter_list=None):
        """
        获取期权合约排行

        :param option_market: 期权市场类型，OptionMarket
        :param sort_type: 排序类型，OptionRankType
        :param count: 每页数量[1,200]，不指定默认200
        :param trading_date: 交易日，字符串格式 'YYYY-MM-DD'，None返回最新排行
        :param sort_direction: 排序方向，0=降序(默认), 1=升序
        :param page: 分页游标，首次请求传None，翻页时传上次返回的next_page
        :param filter_list: 筛选条件列表，OptionRankFilter对象列表(AND关系)
        :return: (ret, data, next_page, all_count)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame类型，字段如下:

            ============================   ======   ==============================================
            参数                           类型     说明
            ============================   ======   ==============================================
            code                           str      期权合约代码
            name                           str      期权名称
            option_type                    str      期权类型（CALL/PUT）
            oi_increment                   int      增仓量(>=0)
            oi_decrement                   int      减仓量(>=0)
            oi_market_cap_increment        float    增仓额(>=0)
            oi_market_cap_decrement        float    减仓额(>=0)
            volume                         int      成交量
            turnover                       float    成交额
            open_interest                  int      持仓量
            open_interest_market_cap       float    持仓额
            iv                             float    隐含波动率（百分比）
            option_price                   float    期权最新价
            change_ratio                   float    涨跌幅（小数）
            mid_price                      float    中间价
            bid_price                      float    买入价
            bid_volume                     int      买量
            ask_price                      float    卖出价
            ask_volume                     int      卖量
            delta                          float    希腊值 Delta
            gamma                          float    希腊值 Gamma
            theta                          float    希腊值 Theta
            vega                           float    希腊值 Vega
            rho                            float    希腊值 Rho
            trading_date                   str      排行数据对应交易日
            trading_timestamp              float    排行数据对应交易日时间戳
            ============================   ======   ==============================================

            next_page: 下一页游标（None表示无下一页）
            all_count: 符合条件的总数据量
        """
        if not OptionMarket.if_has_key(option_market):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of option_market param is wrong", None, None

        if not OptionRankType.if_has_key(sort_type):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of sort_type param is wrong", None, None

        if sort_direction is not None and sort_direction not in (0, 1):
            return RET_ERROR, ERROR_STR_PREFIX + "sort_direction must be 0 (descending) or 1 (ascending)", None, None

        if count is not None and (not isinstance(count, int) or count <= 0 or count > 200):
            return RET_ERROR, ERROR_STR_PREFIX + "count must be a positive integer between 1 and 200", None, None

        query_processor = self._get_sync_query_processor(
            GetOptionRank.pack_req,
            GetOptionRank.unpack_rsp,
        )

        kargs = {
            "option_market": option_market,
            "sort_type": sort_type,
            "count": count,
            "trading_date": trading_date,
            "sort_direction": sort_direction,
            "page": page,
            "filter_list": filter_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None, None

        data_list, next_page, all_count = data
        col_list = ['code', 'name', 'option_type',
                     'oi_increment', 'oi_decrement',
                     'oi_market_cap_increment', 'oi_market_cap_decrement',
                     'volume', 'turnover', 'open_interest', 'open_interest_market_cap',
                     'iv', 'option_price', 'change_ratio',
                     'mid_price', 'bid_price', 'bid_volume', 'ask_price', 'ask_volume',
                     'delta', 'gamma', 'theta', 'vega', 'rho',
                     'trading_date', 'trading_timestamp']
        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page, all_count

    def get_option_event(self, option_market, count=200, page=None, filter_list=None, sort=None):
        """
        获取期权异动列表 Qot_GetOptionEvent

        :param option_market: 期权市场类型，OptionMarket
        :param count: 每页数量 [1, 300]，默认200
        :param page: 分页标记，首次为None或空字符串，翻页传入上次返回的next_page
        :param filter_list: 筛选条件列表 [OptionEventFilter, ...]，条件间为AND逻辑
        :param sort: 排序条件 OptionEventSort，默认按时间降序
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为dict，包含:
                'event_list': DataFrame类型，字段如下:
                'next_page': 下一页标记（空字符串表示无下一页）
                'all_count': 总记录数

            DataFrame字段:

            ============================   ======   ==============================================
            参数                           类型     说明
            ============================   ======   ==============================================
            option_code                    str      期权合约代码
            owner_code                     str      标的股票代码
            symbol                         str      标的display code
            fill_time                      str      成交时间
            fill_timestamp                 float    成交时间戳（Unix秒）
            ticker_type                    str      成交方向
            price                          float    成交价
            volume                         int      成交量（张）
            turnover                       float    成交额
            option_type                    str      期权类型（CALL/PUT）
            strike_price                   float    行权价
            strike_time                    str      到期日
            strike_timestamp               float    到期日时间戳
            dte                            int      距到期天数
            underlying_price               float    标的价格
            otm                            float    价外比率（百分比）
            bid_price                      float    买一价
            ask_price                      float    卖一价
            iv                             float    隐含波动率（百分比）
            total_volume                   int      期权当日总成交量
            total_open_interest            int      期权当日总持仓量
            vo_ratio                       float    量仓比（百分比）
            delta                          float    Delta
            gamma                          float    Gamma
            vega                           float    Vega
            theta                          float    Theta
            rho                            float    Rho
            sentiment                      str      市场情绪
            order_type_list                list     订单类型列表
            strategy_type                  str      策略类型
            earnings_time                  str      财报日期
            earnings_pub_type              int      财报发布类型
            corporate_action_list          list     公司行动列表
            industry_plate_list            list     行业板块列表
            concept_plate_list             list     概念板块列表
            ============================   ======   ==============================================
        """
        if not OptionMarket.if_has_key(option_market):
            return RET_ERROR, ERROR_STR_PREFIX + "the type of option_market param is wrong"

        if count is not None and (not isinstance(count, int) or count < 1 or count > 300):
            return RET_ERROR, ERROR_STR_PREFIX + "count must be an integer in [1, 300]"

        if filter_list is not None:
            if isinstance(filter_list, OptionEventFilter):
                filter_list = [filter_list]
            if not isinstance(filter_list, list):
                return RET_ERROR, ERROR_STR_PREFIX + "the type of filter_list is wrong"
            for f in filter_list:
                if not isinstance(f, OptionEventFilter):
                    return RET_ERROR, ERROR_STR_PREFIX + "the item of filter_list must be OptionEventFilter"

        if sort is not None and not isinstance(sort, OptionEventSort):
            return RET_ERROR, ERROR_STR_PREFIX + "sort must be OptionEventSort"

        query_processor = self._get_sync_query_processor(
            GetOptionEventQuery.pack_req,
            GetOptionEventQuery.unpack_rsp,
        )

        kargs = {
            "option_market": option_market,
            "count": count,
            "page": page if page is not None else '',
            "filter_list": filter_list,
            "sort": sort,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, content = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        data_list, next_page, all_count, update_timestamp = content

        col_list = ['option_code', 'owner_code', 'symbol',
                    'fill_time', 'fill_timestamp', 'ticker_type', 'price', 'volume', 'turnover',
                    'option_type', 'strike_price', 'strike_time', 'strike_timestamp', 'dte',
                    'underlying_price', 'otm', 'bid_price', 'ask_price',
                    'iv', 'total_volume', 'total_open_interest', 'vo_ratio',
                    'delta', 'gamma', 'vega', 'theta', 'rho',
                    'sentiment', 'order_type_list', 'strategy_type',
                    'earnings_time', 'earnings_pub_type',
                    'corporate_action_list', 'industry_plate_list', 'concept_plate_list']

        return RET_OK, {
            'event_list': pd.DataFrame(data_list, columns=col_list),
            'next_page': next_page,
            'all_count': all_count,
        }

    def get_option_event_alert(self, count=200, page=None):
        """
        获取期权异动提醒设置列表 Qot_GetOptionEventAlert

        :param count: 每页数量 [1, 500]，默认200
        :param page: 分页标记，首次为None或空字符串，翻页传入上次返回的next_page
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为dict，包含:
                'alert_list': DataFrame类型，字段如下
                'next_page': 下一页标记（空字符串表示无下一页）
                'all_count': 告警项总数

            DataFrame字段:

            ===============================  ======   ==============================================
            参数                              类型     说明
            ===============================  ======   ==============================================
            key                              int      告警唯一标识
            enable                           bool     告警开关
            option_market                    str      市场品类 OptionMarket
            watchlist_group_name             str      自选股分组名称
            underlying                       str      指定标的代码
            option_type                      str      期权类型 CALL/PUT
            side_type_list                   list     成交方向列表
            order_type_list                  list     订单类型列表
            market_cap_range_min             float    标的市值下限
            market_cap_range_max             float    标的市值上限
            market_cap_min_inclusive         bool     标的市值下限是否闭区间
            market_cap_max_inclusive         bool     标的市值上限是否闭区间
            expiry_days_range_min            float    距到期天数下限
            expiry_days_range_max            float    距到期天数上限
            expiry_days_min_inclusive        bool     距到期天数下限是否闭区间
            expiry_days_max_inclusive        bool     距到期天数上限是否闭区间
            price_range_min                  float    异动成交价下限
            price_range_max                  float    异动成交价上限
            price_min_inclusive              bool     异动成交价下限是否闭区间
            price_max_inclusive              bool     异动成交价上限是否闭区间
            size_range_min                   float    异动成交量下限（张）
            size_range_max                   float    异动成交量上限（张）
            size_min_inclusive               bool     异动成交量下限是否闭区间
            size_max_inclusive               bool     异动成交量上限是否闭区间
            premium_range_min                float    异动成交额下限
            premium_range_max                float    异动成交额上限
            premium_min_inclusive            bool     异动成交额下限是否闭区间
            premium_max_inclusive            bool     异动成交额上限是否闭区间
            iv_range_min                     float    隐含波动率下限(%)
            iv_range_max                     float    隐含波动率上限(%)
            iv_min_inclusive                 bool     隐含波动率下限是否闭区间
            iv_max_inclusive                 bool     隐含波动率上限是否闭区间
            earnings_date_begin              str      财报时间筛选起始日期(yyyy-MM-dd)
            earnings_date_end                str      财报时间筛选截止日期(yyyy-MM-dd)
            note                             str      备注
            ===============================  ======   ==============================================
        """
        if count is not None and (not isinstance(count, int) or count < 1 or count > 500):
            return RET_ERROR, ERROR_STR_PREFIX + "count must be an integer in [1, 500]"

        query_processor = self._get_sync_query_processor(
            GetOptionEventAlertQuery.pack_req,
            GetOptionEventAlertQuery.unpack_rsp,
        )

        kargs = {
            "count": count,
            "page": page if page is not None else '',
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, content = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        next_page, all_count, data_list = content

        col_list = ['key', 'enable', 'option_market', 'watchlist_group_name', 'underlying',
                    'option_type', 'side_type_list', 'order_type_list',
                    'market_cap_range_min', 'market_cap_range_max',
                    'market_cap_min_inclusive', 'market_cap_max_inclusive',
                    'expiry_days_range_min', 'expiry_days_range_max',
                    'expiry_days_min_inclusive', 'expiry_days_max_inclusive',
                    'price_range_min', 'price_range_max',
                    'price_min_inclusive', 'price_max_inclusive',
                    'size_range_min', 'size_range_max',
                    'size_min_inclusive', 'size_max_inclusive',
                    'premium_range_min', 'premium_range_max',
                    'premium_min_inclusive', 'premium_max_inclusive',
                    'iv_range_min', 'iv_range_max',
                    'iv_min_inclusive', 'iv_max_inclusive',
                    'earnings_date_begin', 'earnings_date_end', 'note']

        return RET_OK, {
            'alert_list': pd.DataFrame(data_list, columns=col_list),
            'next_page': next_page,
            'all_count': all_count,
        }

    def set_option_event_alert(self, op, alert_list=None):
        """
        新增、删除、修改、启用、禁用期权异动提醒 Qot_SetOptionEventAlert

        :param op: AlertOpType，操作类型
        :param alert_list: OptionEventAlertItem 或 list[OptionEventAlertItem]，提醒条目（DeleteAll时可为None）
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为空字符串
        """
        r, v = AlertOpType.to_number(op)
        if r is False:
            return RET_ERROR, ERROR_STR_PREFIX + "the type of op param is wrong. It must be AlertOpType"

        if op != AlertOpType.DELETE_ALL and not alert_list:
            return RET_ERROR, ERROR_STR_PREFIX + "alert_list cannot be empty when op is not DELETE_ALL"

        if alert_list is not None:
            if isinstance(alert_list, OptionEventAlertItem):
                alert_list = [alert_list]
            if not isinstance(alert_list, list):
                return RET_ERROR, ERROR_STR_PREFIX + "alert_list must be a list of OptionEventAlertItem"
            for item in alert_list:
                if not isinstance(item, OptionEventAlertItem):
                    return RET_ERROR, ERROR_STR_PREFIX + "alert_list items must be OptionEventAlertItem"

        query_processor = self._get_sync_query_processor(
            SetOptionEventAlertQuery.pack_req,
            SetOptionEventAlertQuery.unpack_rsp,
        )

        kargs = {
            "op": op,
            "alert_list": alert_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, _ = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ""

    def get_option_zero_dte_screener(self, market, sort_type=None, is_asc=None, count=None, page=None, filter_list=None):
        """
        获取末日期权标的筛选列表 Qot_GetOptionZeroDteScreener

        :param market: OptionMarket，市场类型（必填）
        :param sort_type: ZeroDteSortType，排序类型
        :param is_asc: bool，是否升序
        :param count: int，每页数量[1,500]（默认50）
        :param page: str，分页游标，首次请求传空或不传，翻页时传上次返回的next_page
        :param filter_list: list[ZeroDteFilter]，筛选条件列表(AND关系)
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为dict，包含:
                'item_list': DataFrame类型
                'next_page': 下一页游标（None表示无下一页）
                'update_timestamp': 数据更新时间戳
        """
        query_processor = self._get_sync_query_processor(
            GetOptionZeroDteScreenerQuery.pack_req,
            GetOptionZeroDteScreenerQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "sort_type": sort_type,
            "is_asc": is_asc,
            "count": count,
            "page": page,
            "filter_list": filter_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, content = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        next_page, update_timestamp, data_list = content

        col_list = ['owner', 'name', 'price', 'change_ratio', 'market_cap',
                    'iv', 'iv_rank', 'iv_percentile', 'hv',
                    'volume', 'open_interest', 'last_trading_time',
                    'earnings_timestamp', 'earnings_time', 'earnings_pub_type', 'chain_info']

        return RET_OK, {
            'item_list': pd.DataFrame(data_list, columns=col_list),
            'next_page': next_page,
            'update_timestamp': update_timestamp,
        }

    def get_option_zero_dte_contract(self, owner, strike_date_timestamp, chain_info, sort_type=None, is_asc=None, filter_list=None):
        """
        获取末日期权合约列表 Qot_GetOptionZeroDteContract

        :param owner: str，标的股票代码（如 'US.AAPL'）（必填）
        :param strike_date_timestamp: int，行权日期时间戳秒（必填）
        :param chain_info: dict，期权链信息（必填，来自screener返回的chain_info）
        :param sort_type: ZeroDteContractSortType，排序类型
        :param is_asc: bool，是否升序
        :param filter_list: list[ZeroDteContractFilter]，筛选条件列表(AND关系)
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame类型
        """
        query_processor = self._get_sync_query_processor(
            GetOptionZeroDteContractQuery.pack_req,
            GetOptionZeroDteContractQuery.unpack_rsp,
        )

        kargs = {
            "owner": owner,
            "strike_date_timestamp": strike_date_timestamp,
            "chain_info": chain_info,
            "sort_type": sort_type,
            "is_asc": is_asc,
            "filter_list": filter_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, content = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = ['option', 'name', 'option_type', 'option_price', 'change_ratio',
                    'volume', 'open_interest', 'iv', 'delta', 'gamma', 'vega',
                    'theta', 'rho', 'buy_break_even_point', 'buy_to_bep',
                    'buy_profit_probability', 'sell_profit_probability']

        return RET_OK, pd.DataFrame(content, columns=col_list)

    def get_option_earnings_screener(self, market, sort_type=None, is_asc=None, count=None, page=None, filter_list=None):
        """
        获取财报标的列表 Qot_GetOptionEarningsScreener

        :param market: OptionMarket，市场类型（必填）
        :param sort_type: EarningsSortType，排序类型
        :param is_asc: bool，是否升序
        :param count: int，每页数量[1,500]（默认50）
        :param page: str，分页游标（首次请求传空或不传，翻页时传上次返回的next_page）
        :param filter_list: list[EarningsFilter]，筛选条件列表(AND关系)
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为dict，包含:
                'item_list': DataFrame类型
                'next_page': 下一页游标（空=无下一页）
                'update_timestamp': 数据更新时间戳
                'all_count': 总数量
        """
        query_processor = self._get_sync_query_processor(
            GetOptionEarningsScreenerQuery.pack_req,
            GetOptionEarningsScreenerQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "sort_type": sort_type,
            "is_asc": is_asc,
            "count": count,
            "page": page,
            "filter_list": filter_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, content = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        next_page, update_timestamp, all_count, data_list = content

        col_list = ['owner', 'name', 'price', 'change_ratio', 'market_cap',
                    'iv', 'iv_rank', 'iv_percentile', 'hv',
                    'volume', 'open_interest', 'earnings_timestamp', 'earnings_time',
                    'earnings_pub_type', 'earnings_quarter',
                    'last_report_iv_crush', 'history_report_iv_crush',
                    'last_report_chg_ratio', 'history_report_chg_ratio',
                    'estimate_eps_yoy', 'estimate_revenue_yoy', 'expected_move_ratio']

        return RET_OK, {
            'item_list': pd.DataFrame(data_list, columns=col_list),
            'next_page': next_page,
            'update_timestamp': update_timestamp,
            'all_count': all_count,
        }

    def get_option_seller_screener(self, market, seller_type, sort_type=None, is_asc=None, filter_list=None):
        """
        获取期权卖方筛选列表 Qot_GetOptionSellerScreener

        :param market: OptionMarket，市场类型（必填）
        :param seller_type: SellerType，卖方类型（必填）
        :param sort_type: SellerSortType，排序类型
        :param is_asc: bool，是否升序
        :param filter_list: list[SellerFilter]，筛选条件列表(AND关系)
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame类型
        """
        query_processor = self._get_sync_query_processor(
            GetOptionSellerScreenerQuery.pack_req,
            GetOptionSellerScreenerQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "seller_type": seller_type,
            "sort_type": sort_type,
            "is_asc": is_asc,
            "filter_list": filter_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, content = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = ['option', 'name', 'option_type', 'strike_price', 'strike_time',
                    'strike_timestamp', 'left_days', 'option_price', 'stock_price',
                    'premium', 'otm_degree', 'iv', 'interval_return', 'annualized_return',
                    'itm_probability', 'striked_interval_return', 'striked_annualized_return',
                    'owner']

        return RET_OK, pd.DataFrame(content, columns=col_list)

    def get_earnings_calendar(self, market, sort_type=None, begin_date=None, end_date=None, filter_list=None):
        """
        获取财报日历 Qot_GetEarningsCalendar

        :param market: Market，市场类型（必填，支持HK/US/SH/SZ/SG/JP/AU/CA）
        :param sort_type: EarningsCalendarSortType，排序类型（默认Hot）
        :param begin_date: str，开始日期，格式"yyyy-MM-dd"，不传默认今天（仅拉取当天）
        :param end_date: str，结束日期，格式"yyyy-MM-dd"，不传则仅拉取beginDate当天；与beginDate间隔不超过7天
        :param filter_list: list[EarningsCalendarFilter]，筛选条件列表(AND关系)
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame，列包含:
                security, name, earnings_date, earnings_timestamp, pub_type, period_text,
                eps_actual, eps_predict, revenue_actual, revenue_predict, ebit_actual, ebit_predict,
                option_volume, iv, iv_rank, iv_percentile, market_cap, price
        """
        query_processor = self._get_sync_query_processor(
            GetEarningsCalendarQuery.pack_req,
            GetEarningsCalendarQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "sort_type": sort_type,
            "begin_date": begin_date,
            "end_date": end_date,
            "filter_list": filter_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = ['security', 'name', 'earnings_date', 'earnings_timestamp',
                    'pub_type', 'period_text',
                    'eps_actual', 'eps_predict',
                    'revenue_actual', 'revenue_predict',
                    'ebit_actual', 'ebit_predict',
                    'option_volume', 'iv', 'iv_rank', 'iv_percentile',
                    'market_cap', 'price']

        return RET_OK, pd.DataFrame(data_list, columns=col_list)

    def get_macro_indicator_list(self, region):
        """
        获取宏观指标列表 Qot_GetMacroIndicatorList

        :param region: MacroRegion，国家/地区（必填，支持HK/US/JP/SG/AU/CA/MY/CN）
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame，列包含:
                category_name, indicator_id, name
        """
        query_processor = self._get_sync_query_processor(
            GetMacroIndicatorListQuery.pack_req,
            GetMacroIndicatorListQuery.unpack_rsp,
        )

        kargs = {
            "region": region,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = ['category_name', 'indicator_id', 'name']

        return RET_OK, pd.DataFrame(data_list, columns=col_list)

    def get_macro_indicator_history(self, indicator_id, time=None, max_count=None):
        """
        获取宏观指标历史数据 Qot_GetMacroIndicatorHistory

        :param indicator_id: int，宏观指标ID（必填，来自get_macro_indicator_list返回）
        :param time: str，时间节点"yyyy-MM-dd"，从该时间往前拉取；不传默认当前时间
        :param max_count: int，拉取条数，默认100，上限1000
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame，列包含:
                data_time, release_time, value, predict_value, previous_value, unit_type
        """
        query_processor = self._get_sync_query_processor(
            GetMacroIndicatorHistoryQuery.pack_req,
            GetMacroIndicatorHistoryQuery.unpack_rsp,
        )

        kargs = {
            "indicator_id": indicator_id,
            "time": time,
            "max_count": max_count,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = ['data_time', 'release_time', 'value', 'predict_value', 'previous_value', 'unit_type']

        return RET_OK, pd.DataFrame(data_list, columns=col_list)

    def get_fed_watch_target_rate(self):
        """
        获取FedWatch目标利率概率 Qot_GetFedWatchTargetRate

        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame，列包含:
                meeting_date, target_range, probability
        """
        query_processor = self._get_sync_query_processor(
            GetFedWatchTargetRateQuery.pack_req,
            GetFedWatchTargetRateQuery.unpack_rsp,
        )

        kargs = {
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = ['meeting_date', 'target_range', 'probability']

        return RET_OK, pd.DataFrame(data_list, columns=col_list)

    def get_fed_watch_dot_plot(self):
        """
        获取FedWatch点阵图 Qot_GetFedWatchDotPlot

        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame，列包含:
                year, rate, vote_count, is_median, median_rate, current_rate
        """
        query_processor = self._get_sync_query_processor(
            GetFedWatchDotPlotQuery.pack_req,
            GetFedWatchDotPlotQuery.unpack_rsp,
        )

        kargs = {
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data_list = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = ['year', 'rate', 'vote_count', 'is_median', 'median_rate', 'current_rate']

        return RET_OK, pd.DataFrame(data_list, columns=col_list)

    def get_economic_calendar(self, begin_date, end_date=None, market_list=None,
                             importance=None, count=None, next_page=None):
        """
        获取经济事件日历 Qot_GetEconomicCalendar

        :param begin_date: str，开始日期，格式"yyyy-MM-dd"（必填）
        :param end_date: str，结束日期，格式"yyyy-MM-dd"，不传则仅查begin_date当天
        :param market_list: list[Market]，市场筛选(多选，支持HK/US/SH/SG/JP/AU/MY/CA)
        :param importance: EconomicImportance，事件重要性筛选，默认All
        :param count: int，每页数量，默认50，最大100
        :param next_page: str，翻页标记，首次不传，后续带上返回的next_page
        :return: (ret, data, next_page, has_more)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame，列包含:
                title, timestamp, country, star, previous, consensus, actual

            next_page: 下一页翻页标记（None表示无下一页）
            has_more: 是否还有更多数据
        """
        query_processor = self._get_sync_query_processor(
            GetEconomicCalendarQuery.pack_req,
            GetEconomicCalendarQuery.unpack_rsp,
        )

        kargs = {
            "begin_date": begin_date,
            "end_date": end_date,
            "market_list": market_list,
            "importance": importance,
            "count": count,
            "next_page": next_page,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None, None

        next_page_val, has_more, data_list = data
        col_list = ['title', 'timestamp', 'country', 'star', 'previous', 'consensus', 'actual']

        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page_val, has_more

    def get_earnings_beat_rank(self, market, beat_type, count=None, term=None, filter_list=None, sort_field=None):
        """
        获取盈利超预期排名 Qot_GetEarningsBeatRank

        :param market: Market，市场类型（必填，支持HK/US/SG/JP）
        :param beat_type: BeatType，超预期类型（必填，EPS/REVENUE/EBIT）
        :param count: int，返回数量 [1,300]，默认30
        :param term: BeatTerm，财报周期
        :param filter_list: list[EarningsBeatRankFilter]，筛选条件列表(AND关系)
        :param sort_field: EarningsBeatSortField，排序字段(固定降序)，默认按市值
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为(all_count, DataFrame)元组:
                all_count: 满足条件的数据总量
                DataFrame列包含:
                    security, name, industry, cur_price, last_close_price, change_rate, market_cap,
                    pe_ttm, dividends_ttm, released_date, beat_ratio, actual, estimate, yoy,
                    yoy_growth, earning_day_chg, term, detail_post_period
        """
        query_processor = self._get_sync_query_processor(
            GetEarningsBeatRankQuery.pack_req,
            GetEarningsBeatRankQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "beat_type": beat_type,
            "count": count,
            "term": term,
            "filter_list": filter_list,
            "sort_field": sort_field,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        all_count, data_list = data
        col_list = ['security', 'name', 'industry', 'cur_price', 'last_close_price',
                    'change_rate', 'market_cap', 'pe_ttm', 'dividends_ttm',
                    'released_date', 'beat_ratio', 'actual', 'estimate', 'yoy',
                    'yoy_growth', 'earning_day_chg', 'term', 'detail_post_period']

        return RET_OK, (all_count, pd.DataFrame(data_list, columns=col_list))

    def get_dividend_rank(self, market, rank_type, count=None, filter_list=None, sort_field=None):
        """
        获取股息排行 Qot_GetDividendRank

        :param market: Market，市场类型（必填，支持HK/US/MY/SG/JP）
        :param rank_type: DividendRankType，排行类型（必填，HIGH_YIELD/DIVIDEND_GROWTH）
        :param count: int，返回数量 [1,300]，默认10
        :param filter_list: list[DividendRankFilter]，筛选条件列表(AND关系，支持范围型和枚举型)
        :param sort_field: DividendRankSortField，排序字段(固定降序)，默认由rankType决定
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame:
                DataFrame列包含:
                    security, name, industry, cur_price, change_rate, change_amount, market_cap,
                    dividend_yield_ttm, avg_dividend_yield_5y, distribution_frequency,
                    dividend_grow_year, dividends_ttm, payout_ratio_lfy, next_payable_date
        """
        query_processor = self._get_sync_query_processor(
            GetDividendRankQuery.pack_req,
            GetDividendRankQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "rank_type": rank_type,
            "count": count,
            "filter_list": filter_list,
            "sort_field": sort_field,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = ['security', 'name', 'industry', 'cur_price', 'change_rate',
                    'change_amount', 'market_cap', 'dividend_yield_ttm',
                    'avg_dividend_yield_5y', 'distribution_frequency',
                    'dividend_grow_year', 'dividends_ttm', 'payout_ratio_lfy',
                    'next_payable_date']

        return RET_OK, pd.DataFrame(data, columns=col_list)

    def get_dividend_calendar(self, market, date, data_from=None, count=None):
        """
        获取派息日历 Qot_GetDividendCalendar

        :param market: Market，市场类型（必填，支持HK/US/MY/SG/JP）
        :param date: str，查询日期（必填），格式"YYYY-MM-DD"
        :param data_from: int，分页偏移量，默认0
        :param count: int，返回数量，默认不限
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为(all_count, DataFrame)元组:
                all_count: 该日期下的总数量
                DataFrame列包含:
                    security, name, statement, record_date, ex_date, dividend_payable_date
        """
        query_processor = self._get_sync_query_processor(
            GetDividendCalendarQuery.pack_req,
            GetDividendCalendarQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "date": date,
            "data_from": data_from,
            "count": count,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        all_count, data_list = data
        col_list = ['security', 'name', 'statement', 'record_date', 'ex_date',
                    'dividend_payable_date']

        return RET_OK, (all_count, pd.DataFrame(data_list, columns=col_list))

    def get_us_pre_market_rank(self, sort_dir=None, count=10, offset=None, filter_list=None):
        """
        获取美股盘前榜 Qot_GetUSPreMarketRank

        :param sort_dir: RankSortDir，排序方向，默认降序(领涨)
        :param count: int，返回数量 [1,200]，默认10
        :param offset: int，起始位置，默认0
        :param filter_list: list[SimpleRankFilter]，筛选条件列表(AND关系)
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为(all_count, DataFrame)元组:
                all_count: 满足条件的数据总量
                DataFrame列包含:
                    security, name, pre_market_price, pre_market_change_ratio,
                    pre_market_change_amount, pre_market_turnover, pre_market_volume,
                    close_price, change_ratio, change_amount
        """
        query_processor = self._get_sync_query_processor(
            GetUSPreMarketRankQuery.pack_req,
            GetUSPreMarketRankQuery.unpack_rsp,
        )

        kargs = {
            "sort_dir": sort_dir,
            "offset": offset,
            "count": count,
            "filter_list": filter_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        all_count, data_list = data
        col_list = ['security', 'name', 'pre_market_price', 'pre_market_change_ratio',
                    'pre_market_change_amount', 'pre_market_turnover', 'pre_market_volume',
                    'close_price', 'change_ratio', 'change_amount']

        return RET_OK, (all_count, pd.DataFrame(data_list, columns=col_list))

    def get_us_after_hours_rank(self, sort_dir=None, count=10, offset=None, filter_list=None):
        """
        获取美股盘后榜 Qot_GetUSAfterHoursRank

        :param sort_dir: RankSortDir，排序方向，默认降序(领涨)
        :param count: int，返回数量 [1,200]，默认10
        :param offset: int，起始位置，默认0
        :param filter_list: list[SimpleRankFilter]，筛选条件列表(AND关系)
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为(all_count, DataFrame)元组:
                all_count: 满足条件的数据总量
                DataFrame列包含:
                    security, name, after_hours_price, after_hours_change_ratio,
                    after_hours_change_amount, after_hours_turnover, after_hours_volume,
                    close_price, change_ratio, change_amount
        """
        query_processor = self._get_sync_query_processor(
            GetUSAfterHoursRankQuery.pack_req,
            GetUSAfterHoursRankQuery.unpack_rsp,
        )

        kargs = {
            "sort_dir": sort_dir,
            "offset": offset,
            "count": count,
            "filter_list": filter_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        all_count, data_list = data
        col_list = ['security', 'name', 'after_hours_price', 'after_hours_change_ratio',
                    'after_hours_change_amount', 'after_hours_turnover', 'after_hours_volume',
                    'close_price', 'change_ratio', 'change_amount']

        return RET_OK, (all_count, pd.DataFrame(data_list, columns=col_list))

    def get_us_overnight_rank(self, sort_dir=None, count=10, offset=None, filter_list=None):
        """
        获取美股夜盘榜 Qot_GetUSOvernightRank

        :param sort_dir: RankSortDir，排序方向，默认降序(领涨)
        :param count: int，返回数量 [1,200]，默认10
        :param offset: int，起始位置，默认0
        :param filter_list: list[SimpleRankFilter]，筛选条件列表(AND关系)
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为(all_count, DataFrame)元组:
                all_count: 满足条件的数据总量
                DataFrame列包含:
                    security, name, overnight_price, overnight_change_ratio,
                    overnight_change_amount, overnight_turnover, overnight_volume,
                    close_price, change_ratio, change_amount
        """
        query_processor = self._get_sync_query_processor(
            GetUSOvernightRankQuery.pack_req,
            GetUSOvernightRankQuery.unpack_rsp,
        )

        kargs = {
            "sort_dir": sort_dir,
            "offset": offset,
            "count": count,
            "filter_list": filter_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        all_count, data_list = data
        col_list = ['security', 'name', 'overnight_price', 'overnight_change_ratio',
                    'overnight_change_amount', 'overnight_turnover', 'overnight_volume',
                    'close_price', 'change_ratio', 'change_amount']

        return RET_OK, (all_count, pd.DataFrame(data_list, columns=col_list))

    def get_top_movers_rank(self, market, sort_dir=None, count=10, offset=None, filter_list=None):
        """
        获取领涨/领跌榜(盘中) Qot_GetTopMoversRank

        :param market: Market，市场类型（必填，HK/US）
        :param sort_dir: RankSortDir，排序方向，默认降序(领涨)
        :param count: int，返回数量 [1,200]，默认10
        :param offset: int，起始位置，默认0
        :param filter_list: list[SimpleRankFilter]，筛选条件列表(AND关系)
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为(all_count, DataFrame)元组:
                all_count: 满足条件的数据总量
                DataFrame列包含:
                    security, name, cur_price, change_ratio, change_amount,
                    turnover, volume, turnover_ratio, pe_ttm, amplitude,
                    market_cap, volume_ratio
        """
        query_processor = self._get_sync_query_processor(
            GetTopMoversRankQuery.pack_req,
            GetTopMoversRankQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "sort_dir": sort_dir,
            "offset": offset,
            "count": count,
            "filter_list": filter_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        all_count, data_list = data
        col_list = ['security', 'name', 'cur_price', 'change_ratio', 'change_amount',
                    'turnover', 'volume', 'turnover_ratio', 'pe_ttm', 'amplitude',
                    'market_cap', 'volume_ratio']

        return RET_OK, (all_count, pd.DataFrame(data_list, columns=col_list))

    def get_hot_list(self, market, sort_field=None, sort_dir=None, count=10, offset=None, filter_list=None):
        """
        获取热议榜 Qot_GetHotList

        :param market: Market，市场类型（必填，HK/US）
        :param sort_field: HotListSortField，排序字段，默认综合热度
        :param sort_dir: RankSortDir，排序方向，默认降序
        :param count: int，返回数量 [1,200]，默认10
        :param offset: int，起始位置，默认0
        :param filter_list: list[HotListFilter]，筛选条件列表(市值)
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为(all_count, DataFrame)元组:
                all_count: 满足条件的数据总量
                DataFrame列包含:
                    security, name,
                    trade_heat, trade_heat_change, search_heat, search_heat_change,
                    news_heat, news_heat_change, average_heat, average_heat_change,
                    news_type, news_title, news_url
        """
        query_processor = self._get_sync_query_processor(
            GetHotListQuery.pack_req,
            GetHotListQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "sort_field": sort_field,
            "sort_dir": sort_dir,
            "offset": offset,
            "count": count,
            "filter_list": filter_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        all_count, data_list = data
        col_list = ['security', 'name',
                    'trade_heat', 'trade_heat_change', 'search_heat', 'search_heat_change',
                    'news_heat', 'news_heat_change', 'average_heat', 'average_heat_change',
                    'news_type', 'news_title', 'news_url']

        return RET_OK, (all_count, pd.DataFrame(data_list, columns=col_list))

    def get_short_selling_rank(self, market=None, sort_field=None, sort_dir=None, count=10, offset=None, plate_list=None):
        """
        获取卖空异动榜 Qot_GetShortSellingRank

        :param market: Market，市场类型（HK/US），默认US
        :param sort_field: ShortSellingSortField，排序字段，默认卖空变化量
        :param sort_dir: RankSortDir，排序方向，默认降序
        :param count: int，返回数量 [1,35]，默认10
        :param offset: int，起始位置，默认0
        :param plate_list: list[str]，行业板块代码列表(如['US.BK2024'])，空=全部
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为(all_count, DataFrame)元组:
                all_count: 满足条件的数据总量
                DataFrame列包含:
                    security, name, close_price, change_ratio, change_ratio_5d, change_ratio_10d,
                    volume, short_number, short_number_change, short_ratio, short_ratio_change,
                    short_position_volume, short_position_ratio, days_to_cover,
                    week_avg_short_number, week_avg_short_ratio,
                    month_avg_short_number, month_avg_short_ratio
        """
        query_processor = self._get_sync_query_processor(
            GetShortSellingRankQuery.pack_req,
            GetShortSellingRankQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "sort_field": sort_field,
            "sort_dir": sort_dir,
            "offset": offset,
            "count": count,
            "plate_list": plate_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        all_count, data_list = data
        col_list = ['security', 'name', 'close_price', 'change_ratio', 'change_ratio_5d',
                    'change_ratio_10d', 'volume', 'short_number', 'short_number_change',
                    'short_ratio', 'short_ratio_change', 'short_position_volume',
                    'short_position_ratio', 'days_to_cover', 'week_avg_short_number',
                    'week_avg_short_ratio', 'month_avg_short_number', 'month_avg_short_ratio']

        return RET_OK, (all_count, pd.DataFrame(data_list, columns=col_list))

    def get_period_change_rank(self, market, period_type=None, sort_dir=None, count=10, offset=None, filter_list=None):
        """
        获取区间涨跌幅 Qot_GetPeriodChangeRank

        :param market: Market，市场类型（必填，HK/US）
        :param period_type: RankPeriodType，排序周期，默认5分钟
        :param sort_dir: RankSortDir，排序方向，默认降序
        :param count: int，返回数量 [1,200]，默认10
        :param offset: int，起始位置，默认0
        :param filter_list: list[PeriodChangeRankFilter]，筛选条件列表(AND关系)
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为(all_count, DataFrame)元组:
                all_count: 满足条件的数据总量
                DataFrame列包含:
                    security, name, cur_price, change_ratio, turnover, volume, market_cap,
                    change_rate_5min, change_rate_5d, change_rate_10d, change_rate_20d,
                    change_rate_60d, change_rate_120d, change_rate_250d, change_rate_ytd,
                    pe_ttm, pb, turnover_ratio, volume_ratio, amplitude
        """
        query_processor = self._get_sync_query_processor(
            GetPeriodChangeRankQuery.pack_req,
            GetPeriodChangeRankQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "period_type": period_type,
            "sort_dir": sort_dir,
            "offset": offset,
            "count": count,
            "filter_list": filter_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        all_count, data_list = data
        col_list = ['security', 'name', 'cur_price', 'change_ratio', 'turnover', 'volume',
                    'market_cap', 'change_rate_5min', 'change_rate_5d', 'change_rate_10d',
                    'change_rate_20d', 'change_rate_60d', 'change_rate_120d', 'change_rate_250d',
                    'change_rate_ytd', 'pe_ttm', 'pb', 'turnover_ratio', 'volume_ratio', 'amplitude']

        return RET_OK, (all_count, pd.DataFrame(data_list, columns=col_list))

    def get_high_dividend_soe_rank(self, sort_field=None, sort_dir=None, count=10, offset=None, filter_list=None):
        """
        获取破净高股息国央企(港股) Qot_GetHighDividendSOERank

        默认固定条件(服务端): 概念板块=特估国企 + PB<=1 + 股息率TTM>=5% + PE>=0

        :param sort_field: HighDividendSOESortField，排序字段，默认市值
        :param sort_dir: RankSortDir，排序方向，默认降序
        :param count: int，返回数量 [1,200]，默认10
        :param offset: int，起始位置，默认0
        :param filter_list: list[HighDividendSOERankFilter]，筛选条件列表(可覆盖默认条件)
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为(all_count, DataFrame)元组:
                all_count: 满足条件的数据总量
                DataFrame列包含:
                    security, name, industry, cur_price, change_ratio, turnover, volume,
                    market_cap, pe_ttm, pb, dividend_yield_ttm, turnover_ratio,
                    change_rate_5d, change_rate_10d, change_rate_20d,
                    change_rate_60d, change_rate_120d, change_rate_250d
        """
        query_processor = self._get_sync_query_processor(
            GetHighDividendSOERankQuery.pack_req,
            GetHighDividendSOERankQuery.unpack_rsp,
        )

        kargs = {
            "sort_field": sort_field,
            "sort_dir": sort_dir,
            "offset": offset,
            "count": count,
            "filter_list": filter_list,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        all_count, data_list = data
        col_list = ['security', 'name', 'industry', 'cur_price', 'change_ratio',
                    'turnover', 'volume', 'market_cap', 'pe_ttm', 'pb',
                    'dividend_yield_ttm', 'turnover_ratio', 'change_rate_5d',
                    'change_rate_10d', 'change_rate_20d', 'change_rate_60d',
                    'change_rate_120d', 'change_rate_250d']

        return RET_OK, (all_count, pd.DataFrame(data_list, columns=col_list))

    def get_institution_list(self, market, sort_field=None, sort_dir=None, count=None, page=None, name_part=None):
        """
        获取机构列表 Qot_GetInstitutionList

        :param market: Market，市场类型（必填，HK/US）
        :param sort_field: InstitutionListSortField，排序字段，默认持仓市值
        :param sort_dir: RankSortDir，排序方向，默认降序
        :param count: int，返回数量 [1,200]，默认20
        :param page: str，翻页游标，首次不传，续页传上次返回的next_page
        :param name_part: str，机构名模糊搜索
        :return: (ret, data, next_page, all_count)
        """
        query_processor = self._get_sync_query_processor(
            GetInstitutionListQuery.pack_req,
            GetInstitutionListQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "sort_field": sort_field,
            "sort_dir": sort_dir,
            "count": count,
            "page": page,
            "name_part": name_part,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None, None

        data_list, next_page, all_count = data
        col_list = ['institution_id', 'institution_name', 'position_value',
                    'position_value_change', 'position_count', 'position_count_change',
                    'disclosure_date', 'currency']

        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page, all_count

    def get_institution_profile(self, market, institution_id):
        """
        获取机构概况 Qot_GetInstitutionProfile

        :param market: Market，市场类型（必填，HK/US）
        :param institution_id: int，机构ID（必填）
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为dict，包含机构概况字段
        """
        query_processor = self._get_sync_query_processor(
            GetInstitutionProfileQuery.pack_req,
            GetInstitutionProfileQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "institution_id": institution_id,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        return RET_OK, data

    def get_institution_distribution(self, market, institution_id):
        """
        获取机构持仓行业分布 Qot_GetInstitutionDistribution

        :param market: Market，市场类型（必填，HK/US）
        :param institution_id: int，机构ID（必填）
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame，列: industry_id, industry_name, position_value, portfolio_pct
        """
        query_processor = self._get_sync_query_processor(
            GetInstitutionDistributionQuery.pack_req,
            GetInstitutionDistributionQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "institution_id": institution_id,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = ['industry_id', 'industry_name', 'position_value', 'portfolio_pct']
        return RET_OK, pd.DataFrame(data, columns=col_list)

    def get_institution_holding_change(self, market, institution_id, change_type=None,
                                       sort_field=None, sort_dir=None, count=None, page=None):
        """
        获取机构持仓变动 Qot_GetInstitutionHoldingChange

        :param market: Market，市场类型（必填，HK/US）
        :param institution_id: int，机构ID（必填）
        :param change_type: InstitutionHoldingChangeType，变动类型，默认建仓
        :param sort_field: InstitutionHoldingChangeSortField，排序字段，默认变动比例
        :param sort_dir: RankSortDir，排序方向，默认降序
        :param count: int，返回数量 [1,200]，默认20
        :param page: str，翻页游标
        :return: (ret, data, next_page, all_count)
        """
        query_processor = self._get_sync_query_processor(
            GetInstitutionHoldingChangeQuery.pack_req,
            GetInstitutionHoldingChangeQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "institution_id": institution_id,
            "change_type": change_type,
            "sort_field": sort_field,
            "sort_dir": sort_dir,
            "count": count,
            "page": page,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None, None

        data_list, next_page, all_count = data
        col_list = ['security', 'name', 'portfolio_pct', 'change_shares',
                    'change_pct', 'holding_date', 'source']

        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page, all_count

    def get_institution_holding_list(self, market, institution_id, change_type=None,
                                     sort_field=None, sort_dir=None, count=None,
                                     page=None, keyword=None):
        """
        获取机构持股列表 Qot_GetInstitutionHoldingList

        :param market: Market，市场类型（必填，HK/US）
        :param institution_id: int，机构ID（必填）
        :param change_type: InstitutionHoldingChangeType，按变动类型筛选(不传=全部)
        :param sort_field: InstitutionHoldingListSortField，排序字段，默认持仓市值
        :param sort_dir: RankSortDir，排序方向，默认降序
        :param count: int，返回数量 [1,200]，默认20
        :param page: str，翻页游标
        :param keyword: str，搜索关键词(股票名/代码)
        :return: (ret, data, next_page, all_count)
        """
        query_processor = self._get_sync_query_processor(
            GetInstitutionHoldingListQuery.pack_req,
            GetInstitutionHoldingListQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "institution_id": institution_id,
            "change_type": change_type,
            "sort_field": sort_field,
            "sort_dir": sort_dir,
            "count": count,
            "page": page,
            "keyword": keyword,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None, None

        data_list, next_page, all_count = data
        col_list = ['security', 'name', 'industry_name', 'holding_value', 'holding_pct',
                    'last_holding_pct', 'change_shares', 'portfolio_pct', 'change_pct',
                    'holding_date', 'source', 'currency']

        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page, all_count

    def get_ark_fund_holding(self, holding_type=None, cycle_type=None, sort_field=None,
                             sort_dir=None, count=None, page=None):
        """
        获取ARK基金持仓 Qot_GetArkFundHolding

        :param holding_type: ArkHoldingType，持仓类型，默认持仓
        :param cycle_type: ArkCycleType，周期类型，默认近1天(holdingType=持仓时忽略)
        :param sort_field: ArkFundHoldingSortField，排序字段，默认持仓数量
        :param sort_dir: RankSortDir，排序方向，默认降序
        :param count: int，返回数量 [1,200]，默认20
        :param page: str，翻页游标
        :return: (ret, data, next_page, all_count)
        """
        query_processor = self._get_sync_query_processor(
            GetArkFundHoldingQuery.pack_req,
            GetArkFundHoldingQuery.unpack_rsp,
        )

        kargs = {
            "holding_type": holding_type,
            "cycle_type": cycle_type,
            "sort_field": sort_field,
            "sort_dir": sort_dir,
            "count": count,
            "page": page,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None, None

        data_list, next_page, all_count = data
        col_list = ['security', 'name', 'shares', 'shares_change',
                    'market_value', 'weight', 'weight_change']

        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page, all_count

    def get_ark_stock_dynamic(self, security):
        """
        获取ARK个股交易动态 Qot_GetArkStockDynamic

        :param security: str，股票代码（必填，如 'US.TSLA'）
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为dict，包含:
                dynamic_type, transaction_count, net_shares, last_transaction_time
        """
        query_processor = self._get_sync_query_processor(
            GetArkStockDynamicQuery.pack_req,
            GetArkStockDynamicQuery.unpack_rsp,
        )

        kargs = {
            "security": security,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        return RET_OK, data

    def get_ark_active_transaction(self, holding_type=None, cycle_type=None, sort_field=None,
                                   sort_dir=None, count=None, page=None):
        """
        获取ARK主动交易聚合 Qot_GetArkActiveTransaction

        :param holding_type: ArkActiveTransactionHoldingType，持仓变动类型，默认增持
        :param cycle_type: ArkCycleType，周期类型，默认近1天
        :param sort_field: ArkActiveTransactionSortField，排序字段，默认变动金额
        :param sort_dir: RankSortDir，排序方向，默认降序(净买入在前)
        :param count: int，返回数量 [1,200]，默认50
        :param page: str，翻页游标
        :return: (ret, data, next_page, all_count)
        """
        query_processor = self._get_sync_query_processor(
            GetArkActiveTransactionQuery.pack_req,
            GetArkActiveTransactionQuery.unpack_rsp,
        )

        kargs = {
            "holding_type": holding_type,
            "cycle_type": cycle_type,
            "sort_field": sort_field,
            "sort_dir": sort_dir,
            "count": count,
            "page": page,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None, None

        data_list, next_page, all_count = data
        col_list = ['security', 'name', 'change_amount', 'change_shares']

        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page, all_count

    def get_rating_change(self, market, change_type=None, count=None, page=None):
        """
        获取评级变动 Qot_GetRatingChange

        :param market: Market，市场类型(仅US)
        :param change_type: RatingChangeType，评级变动类型，默认上调
        :param count: int，返回数量 [1,20]，默认10
        :param page: str，翻页游标
        :return: (ret, data, next_page, all_count)
        """
        query_processor = self._get_sync_query_processor(
            GetRatingChangeQuery.pack_req,
            GetRatingChangeQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "change_type": change_type,
            "count": count,
            "page": page,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None, None

        data_list, next_page, all_count = data
        col_list = ['security', 'name', 'rating', 'last_rating', 'target_price',
                    'last_target_price', 'change_type', 'institution_name',
                    'recommendation_date', 'last_recommendation_date']

        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page, all_count

    def get_industrial_chain_list(self, market, keyword=None, count=None, page=None):
        """
        获取产业链列表 Qot_GetIndustrialChainList

        :param market: Market，市场类型
        :param keyword: str，搜索关键字(可选)
        :param count: int，返回数量 [1,50]，默认20
        :param page: str，翻页游标
        :return: (ret, data, next_page, all_count)
        """
        query_processor = self._get_sync_query_processor(
            GetIndustrialChainListQuery.pack_req,
            GetIndustrialChainListQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "keyword": keyword,
            "count": count,
            "page": page,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None, None

        data_list, next_page, all_count = data
        col_list = ['chain_id', 'chain_type', 'name', 'detail',
                    'market_cap', 'stocks_num', 'relation_security_list']

        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page, all_count

    def get_industrial_chain_detail(self, chain_id):
        """
        获取产业链详情 Qot_GetIndustrialChainDetail

        :param chain_id: int，产业链ID
        :return: (ret, data)
        """
        query_processor = self._get_sync_query_processor(
            GetIndustrialChainDetailQuery.pack_req,
            GetIndustrialChainDetailQuery.unpack_rsp,
        )

        kargs = {
            "chain_id": chain_id,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        return RET_OK, data

    def get_industrial_chain_by_plate(self, plate_id):
        """
        获取板块关联产业链 Qot_GetIndustrialChainByPlate

        :param plate_id: int，产业板块ID（必填）
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为list[dict]，每个dict包含:
                chain_id, chain_type, name, market_cap, stocks_num
        """
        query_processor = self._get_sync_query_processor(
            GetIndustrialChainByPlateQuery.pack_req,
            GetIndustrialChainByPlateQuery.unpack_rsp,
        )

        kargs = {
            "plate_id": plate_id,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        return RET_OK, data

    def get_industrial_plate_info(self, plate_id):
        """
        获取产业板块信息 Qot_GetIndustrialPlateInfo

        :param plate_id: int，产业板块ID（必填）
        :return: (ret, data)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为dict，包含:
                plate_id, summary
        """
        query_processor = self._get_sync_query_processor(
            GetIndustrialPlateInfoQuery.pack_req,
            GetIndustrialPlateInfoQuery.unpack_rsp,
        )

        kargs = {
            "plate_id": plate_id,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        return RET_OK, data

    def get_industrial_plate_stock(self, chain_id=None, plate_id=None, market_list=None,
                                       sort_field=None, ascend=None, count=None, page=None):
        """
        获取产业板块成分股 Qot_GetIndustrialPlateStock

        :param chain_id: int，产业链ID（与plate_id二选一，plate_id优先）
        :param plate_id: int，产业板块ID（优先使用）
        :param market_list: list[Market]，市场筛选(支持HK/US/CN/JP/SG/MY，不传默认全部)
        :param sort_field: PlateStockSortField，排序字段，默认市值
        :param ascend: bool，升序True/降序False，默认False(降序)
        :param count: int，每页数量 [1,200]，默认50
        :param page: str，翻页游标
        :return: (ret, data, next_page, all_count)

            ret != RET_OK 返回错误字符串

            ret == RET_OK data为DataFrame，列: security, name
            next_page: 下一页游标(None表示无更多数据)
            all_count: 满足条件的数据总量
        """
        query_processor = self._get_sync_query_processor(
            GetIndustrialPlateStockQuery.pack_req,
            GetIndustrialPlateStockQuery.unpack_rsp,
        )

        kargs = {
            "chain_id": chain_id,
            "plate_id": plate_id,
            "market_list": market_list,
            "sort_field": sort_field,
            "ascend": ascend,
            "count": count,
            "page": page,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        ret_list, next_page, all_count = data
        col_list = ['security', 'name']
        return RET_OK, pd.DataFrame(ret_list, columns=col_list), next_page, all_count

    def get_heat_map_data(self, market, sort_field=None, ascend=None, count=None, page=None, plate_type=None):
        """
        获取热力图数据 Qot_GetHeatMapData

        :param market: Market，市场类型
        :param sort_field: HeatMapSortField，排序字段，默认涨跌幅
        :param ascend: bool，升序True/降序False，默认降序
        :param count: int，返回数量 [1,200]，默认30
        :param page: str，翻页游标
        :param plate_type: HeatMapPlateType，板块类型，默认行业板块
        :return: (ret, data, next_page, all_count)
        """
        query_processor = self._get_sync_query_processor(
            GetHeatMapDataQuery.pack_req,
            GetHeatMapDataQuery.unpack_rsp,
        )

        kargs = {
            "market": market,
            "sort_field": sort_field,
            "ascend": ascend,
            "count": count,
            "page": page,
            "plate_type": plate_type,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None, None

        data_list, next_page, all_count = data
        col_list = ['plate', 'plate_name', 'cur_price', 'change_rate', 'turnover',
                    'volume', 'market_val', 'pe_avg', 'rise_count', 'fall_count',
                    'equal_count', 'leader_stock', 'description']

        return RET_OK, pd.DataFrame(data_list, columns=col_list), next_page, all_count

    def get_rise_fall_distribution(self, security=None, market=None):
        """
        获取涨跌分布 Qot_GetRiseFallDistribution

        :param security: str，板块代码(优先使用，如 'HK.BK1001')
        :param market: Market，市场类型(security未传时使用)
        :return: (ret, data)
        """
        query_processor = self._get_sync_query_processor(
            GetRiseFallDistributionQuery.pack_req,
            GetRiseFallDistributionQuery.unpack_rsp,
        )

        kargs = {
            "security": security,
            "market": market,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, data = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        return RET_OK, data

    def get_top_ten_buy_sell_brokers(self, code, days_before=None):
        """
        获取十大买卖经纪商，默认同时返回净买入和净卖出两组数据。
        daysBefore=0 走实时，daysBefore>0 走历史第 N 个交易日。

        :param code: 股票代码，例如 "HK.00700"
        :param days_before: 距当前交易日天数，0=实时，>0=历史第 N 个交易日，默认 0
        :return: (ret_code, ret_data)
            返回结果同时包含净买入和净卖出两组数据，使用 buy_sell_type 区分。
            实时数据列：net_vol, is_real_time, buy_sell_type, data_time, data_time_str, broker_name, avg_price, total_vol, total_turnover
            历史数据列：net_vol, is_real_time, buy_sell_type, data_time, data_time_str, broker_name
        """
        if code is None or is_str(code) is False:
            error_str = ERROR_STR_PREFIX + 'the type of code param is wrong'
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            GetTopTenBuySellBrokersQuery.pack_req,
            GetTopTenBuySellBrokersQuery.unpack,
        )
        kargs = {
            "code": code,
            "conn_id": self.get_sync_conn_id(),
            "days_before": days_before,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            if len(ret) == 0:
                return RET_OK, pd.DataFrame()
            is_real_time = ret[0].get("is_real_time", True)
            if is_real_time:
                col_list = [
                    'net_vol', 'is_real_time', 'buy_sell_type',
                    'data_time', 'data_time_str',
                    'broker_name', 'avg_price', 'total_vol', 'total_turnover',
                ]
            else:
                col_list = [
                    'net_vol', 'is_real_time', 'buy_sell_type',
                    'data_time', 'data_time_str',
                    'broker_name',
                ]
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        return RET_ERROR, "empty data"


    def get_financials_statements(self, code,
                                  statement_type=None,
                                  financial_type=None,
                                  currency_code=None,
                                  next_key=None,
                                  num=None):
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetFinancialsStatementsQuery.pack_req,
            GetFinancialsStatementsQuery.unpack,
        )
        kargs = {
            'code':            code,
            'conn_id':         self.get_sync_conn_id(),
            'statement_type':  statement_type,
            'financial_type':  financial_type,
            'currency_code':   currency_code,
            'next_key':        next_key,
            'num':             num,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ret

    def get_financials_revenue_breakdown(self, code, date=None, financial_type=None, currency_code=None):
        """
        获取主营构成
        Get Financials Revenue Breakdown
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetFinancialsRevenueBreakdownQuery.pack_req,
            GetFinancialsRevenueBreakdownQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
            'date': date,
            'financial_type': financial_type,
            'currency_code': currency_code,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ret

    def get_company_profile(self, code):
        """
        获取公司详情
        Get Company Detail
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetCompanyProfileQuery.pack_req,
            GetCompanyProfileQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = ['name', 'value', 'field_type']
            return RET_OK, pd.DataFrame(ret, columns=col_list)
        return RET_ERROR, "empty data"

    def get_company_executives(self, code):
        """
        获取公司高管信息
        Get Company Executives
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetCompanyExecutivesQuery.pack_req,
            GetCompanyExecutivesQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = [
                'display_leader_name', 'leader_name', 'position_name',
                'begin_date', 'begin_date_str', 'issue_date', 'issue_date_str',
                'leader_gender', 'leader_age', 'highest_education', 'annual_salary',
            ]
            return RET_OK, pd.DataFrame(ret, columns=col_list)
        return RET_ERROR, "empty data"

    def get_company_executive_background(self, code, leader_name=None):
        """
        获取公司高管背景信息
        Get Company Executive Background
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetCompanyExecutiveBackgroundQuery.pack_req,
            GetCompanyExecutiveBackgroundQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
            'leader_name': leader_name,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ret

    def get_company_operational_efficiency(self, code, num=None, next_key=None, currency_code=None):
        """
        获取公司经营效率
        Get Operational Efficiency
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetCompanyOperationalEfficiencyQuery.pack_req,
            GetCompanyOperationalEfficiencyQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
            'num': num,
            'next_key': next_key,
            'currency_code': currency_code,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ret

    def get_corporate_actions_stock_splits(self, code, next_key=None, num=None):
        """
        获取拆合股（支持港股及非港股，分页）
        Get Stock Split (supports HK and non-HK markets, paginated)
        返回 dict: {"next_key": str, "split_list": list}
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetCorporateActionsStockSplitsQuery.pack_req,
            GetCorporateActionsStockSplitsQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
            'next_key': next_key,
            'num': num,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ret  # {"next_key": str, "split_list": list}

    def get_corporate_actions_buybacks(self, code, next_key=None, num=None):
        """
        获取回购（分页）
        Get Buy Back (paginated)
        返回 dict: {"next_key": str, "hk_buy_back_list": DataFrame, "a_buy_back_list": DataFrame}
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetCorporateActionsBuybacksQuery.pack_req,
            GetCorporateActionsBuybacksQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
            'next_key': next_key,
            'num': num,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if not isinstance(ret, dict):
            return RET_OK, {'next_key': '-1', 'hk_buy_back_list': pd.DataFrame(), 'a_buy_back_list': pd.DataFrame()}
        # 港股字段按 HK_BUYBACK_* 展示列顺序
        hk_cols = [
            'publ_date', 'publ_date_str',
            'end_date', 'end_date_str',
            'buy_back_money',
            'buy_back_sum',
            'percentage',
            'high_price', 'low_price',
            'cumulative_sum',
            'cumulative_percentage',
            'share_type',
        ]
        # A 股字段按 CN_BUYBACK_* 展示列顺序
        a_cols = [
            'change_reg_date', 'change_reg_date_str',
            'change_date', 'change_date_str',
            'event_proce_desc',
            'advance_date', 'advance_date_str',
            'meet_pass_date', 'meet_pass_date_str',
            'start_date', 'start_date_str',
            'end_date', 'end_date_str',
            'pay_date', 'pay_date_str',
            'seller',
            'buy_back_mode',
            'share_type',
            'buy_back_sum',
            'buy_back_money',
            'percentage',
            'value_floor', 'value_ceiling',
            'price_floor', 'price_ceiling',
            'volume_floor', 'volume_ceiling',
        ]
        hk_df = pd.DataFrame(ret.get('hk_buy_back_list', []), columns=hk_cols)
        a_df = pd.DataFrame(ret.get('a_buy_back_list', []), columns=a_cols)
        return RET_OK, {
            'next_key': ret.get('next_key', '-1'),
            'hk_buy_back_list': hk_df,
            'a_buy_back_list': a_df,
        }

    def get_shareholders_overview(self, code, period_id=None):
        """
        获取持股统计，一次请求同时返回主要股东（main_holder）和持股类型（holder_type）数据；
        period_id 为 0 时同时返回可用报告期列表（holding_period）。
        Get ownership static; returns main holders and holder type in one request.
        When period_id is 0, available report periods are also returned.
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetShareholdersOverviewQuery.pack_req,
            GetShareholdersOverviewQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
            'period_id': period_id,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg

        col_list = ["static_date", "static_date_str", "name", "holder_pct", "holder_id"]

        def _build_df(info_list):
            rows = []
            for info in info_list:
                sd = info.get("static_date")
                sd_str = info.get("static_date_str") or (datetime.utcfromtimestamp(sd).strftime('%Y-%m-%d') if sd else None)
                for it in info.get("item_list", []):
                    rows.append({
                        "static_date": sd,
                        "static_date_str": sd_str,
                        "name": it.get("name"),
                        "holder_pct": it.get("holder_pct"),
                        "holder_id": it.get("holder_id"),
                    })
            return pd.DataFrame(rows, columns=col_list)

        if isinstance(ret, dict):
            main_holder_df = _build_df(ret.get("main_holder_list", []))
            holder_type_df = _build_df(ret.get("holder_type_list", []))
            hp_list = ret.get("holding_period_list", [])
        else:
            main_holder_df = pd.DataFrame(columns=col_list)
            holder_type_df = pd.DataFrame(columns=col_list)
            hp_list = []
        hp_cols = ["period_text", "period_id"]
        hp_df = pd.DataFrame(hp_list, columns=hp_cols) if hp_list else pd.DataFrame(columns=hp_cols)
        return RET_OK, {"main_holder": main_holder_df, "holder_type": holder_type_df, "holding_period": hp_df}

    def get_shareholders_institutional(self, code, next_key=None, num=None):
        """
        获取机构持股
        Get Institution Holder
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetShareholdersInstitutionalQuery.pack_req,
            GetShareholdersInstitutionalQuery.unpack,
        )
        kargs = {
            'code': code,
            'next_key': next_key,
            'num': num,
            'conn_id': self.get_sync_conn_id(),
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        next_key_out = "-1"
        update_time = 0
        update_time_str = ""
        if isinstance(ret, dict):
            next_key_out = ret.get("next_key", "-1") or "-1"
            update_time = ret.get("update_time", 0) or 0
            update_time_str = ret.get("update_time_str", "") or ""
        col_list = [
            "period_text",
            "institution_quantity",
            "institution_quantity_change",
            "holder_quantity",
            "holder_quantity_change",
            "holder_pct",
            "holder_pct_change",
            "next_key",
            "update_time",
            "update_time_str",
        ]
        rows = ret.get("item_list", []) if isinstance(ret, dict) else []
        if not rows:
            ret_frame = pd.DataFrame(columns=col_list)
        else:
            ret_frame = pd.DataFrame(rows)
            ret_frame["next_key"] = next_key_out
            ret_frame["update_time"] = update_time
            ret_frame["update_time_str"] = update_time_str
            for c in col_list:
                if c not in ret_frame.columns:
                    ret_frame[c] = None
            ret_frame = ret_frame[col_list]
        return RET_OK, ret_frame

    def get_shareholders_holding_changes(self, code, next_key=None, num=None, sort_type=None, sort_column=None, filter_type=None):
        """
        获取持股变动
        Get Owner List Info
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetShareholdersHoldingChangesQuery.pack_req,
            GetShareholdersHoldingChangesQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
            'next_key': next_key,
            'num': num,
            'sort_type': sort_type,
            'sort_column': sort_column,
            'filter_type': filter_type,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        page_next_key = "-1"
        rows = []
        if isinstance(ret, dict):
            page_next_key = ret.get("next_key", "-1")
            for item in ret.get("item_list", []):
                row = {}
                row["period_text"] = item.get("period_text")
                row["name"] = item.get("name")
                row["holder_id"] = item.get("holder_id")
                row["share_change_num"] = item.get("share_change_num")
                row["shares_change_price"] = item.get("shares_change_price")
                row["share_ratio"] = item.get("holder_pct")
                row["holder_type"] = item.get("holder_type")
                row["holder_type_id"] = item.get("holder_type_id")
                row["holding_date"] = item.get("holding_date")
                row["holding_date_str"] = item.get("holding_date_str")
                row["share_ratio_change"] = item.get("holder_pct_change")
                row["share_num"] = item.get("holder_quantity")
                row["next_key"] = page_next_key
                rows.append(row)
        col_list = [
            "period_text", "name", "holder_id", "share_change_num", "shares_change_price",
            "share_ratio", "holder_type", "holder_type_id", "holding_date", "holding_date_str",
            "share_ratio_change", "share_num", "next_key",
        ]
        if not rows:
            ret_frame = pd.DataFrame(columns=col_list)
        else:
            ret_frame = pd.DataFrame(rows)
            for c in col_list:
                if c not in ret_frame.columns:
                    ret_frame[c] = None
            ret_frame = ret_frame[col_list]
        return RET_OK, ret_frame

    def get_shareholders_holder_detail(self, code, request_type=None, next_key=None, num=None, sort_column=None, sort_type=None, period_id=None, holder_id=None):
        """
        获取持股明细
        Get Ownership Detail
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetShareholdersHolderDetailQuery.pack_req,
            GetShareholdersHolderDetailQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
            'request_type': request_type,
            'next_key': next_key,
            'num': num,
            'sort_column': sort_column,
            'sort_type': sort_type,
            'period_id': period_id,
            'holder_id': holder_id,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        rows = []
        meta = {}
        if isinstance(ret, dict):
            meta["update_time"] = ret.get("update_time")
            meta["update_time_str"] = ret.get("update_time_str")
            for item in ret.get("item_list", []):
                row = dict(item)
                row.update(meta)
                rows.append(row)
        col_list = [
            "period_text", "holder_id", "name",
            "holder_quantity", "holder_quantity_change", "holder_pct", "holder_pct_change",
            "holding_date", "holding_date_str", "close_price", "price_change_pct",
            "source_group_name", "update_time", "update_time_str",
        ]
        if not rows:
            ret_frame = pd.DataFrame(columns=col_list)
        else:
            ret_frame = pd.DataFrame(rows)
            for c in col_list:
                if c not in ret_frame.columns:
                    ret_frame[c] = None
            ret_frame = ret_frame[col_list]
        if isinstance(ret, dict):
            ret_frame.attrs["next_key"] = ret.get("next_key", "-1")
        return RET_OK, ret_frame

    def get_insider_holder_list(self, code, next_key=None, num=None):
        """
        获取内部人持股列表
        Get Owner Insider Holder List
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetInsiderHolderListQuery.pack_req,
            GetInsiderHolderListQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
            'next_key': next_key,
            'num': num,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        meta = {}
        rows = []
        if isinstance(ret, dict):
            meta["all_count"] = ret.get("all_count")
            meta["next_key"] = ret.get("next_key", "-1")
            meta["insider_total_count"] = ret.get("insider_total_count")
            meta["insider_bought_count"] = ret.get("insider_bought_count")
            meta["insider_sold_count"] = ret.get("insider_sold_count")
            for item in ret.get("item_list", []):
                row = dict(item)
                row.update(meta)
                rows.append(row)
        col_list = [
            "holder_id", "holder_quantity", "holder_pct", "name", "title",
            "all_count", "next_key", "insider_total_count", "insider_bought_count", "insider_sold_count",
        ]
        if not rows:
            ret_frame = pd.DataFrame(columns=col_list)
        else:
            ret_frame = pd.DataFrame(rows)
            for c in col_list:
                if c not in ret_frame.columns:
                    ret_frame[c] = None
            ret_frame = ret_frame[col_list]
        return RET_OK, ret_frame

    def get_insider_trade_list(self, code, holder_id=None, num=None, next_key=None):
        """
        获取内部人交易列表
        Get Owner Insider Trade List
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetInsiderTradeListQuery.pack_req,
            GetInsiderTradeListQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
            'holder_id': holder_id,
            'num': num,
            'next_key': next_key,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        rows = []
        all_count = None
        next_key_val = "-1"
        if isinstance(ret, dict):
            all_count = ret.get("all_count")
            next_key_val = ret.get("next_key", "-1")
            rows = list(ret.get("item_list", []))
        col_list = [
            "trade_shares", "min_trade_date", "min_trade_date_str",
            "max_trade_date", "max_trade_date_str",
            "min_price", "max_price", "security_holder_quantity",
            "is_proposed_sale_of_securities", "holder_id", "name", "title",
            "security_description", "transaction_type", "source_group_name",
        ]
        if not rows:
            ret_frame = pd.DataFrame(columns=col_list)
        else:
            ret_frame = pd.DataFrame(rows)
            for c in col_list:
                if c not in ret_frame.columns:
                    ret_frame[c] = None
            ret_frame = ret_frame[col_list]
        ret_frame.attrs["all_count"] = all_count
        ret_frame.attrs["next_key"] = next_key_val
        return RET_OK, ret_frame

    def get_daily_short_volume(self, code, next_key=None, num=None):
        """
        获取每日卖空（美股/港股）
        Get Daily Short Volume (US/HK)
        Returns (ret_code, us_df, hk_df)
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong', None
        query_processor = self._get_sync_query_processor(
            GetDailyShortVolumeQuery.pack_req,
            GetDailyShortVolumeQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
            'next_key': next_key,
            'num': num,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None

        next_key_val = ret.get("next_key", "-1") if isinstance(ret, dict) else "-1"

        us_col_list = [
            "timestamp", "timestamp_str", "total_shares_short", "nasdaq_shares_short",
            "nyse_shares_short", "short_percent", "volume", "close_price",
            "last_close_price", "daily_trade_avg_ratio",
        ]
        us_rows = ret.get("us_item_list", []) if isinstance(ret, dict) else []
        if not us_rows:
            us_df = pd.DataFrame(columns=us_col_list)
        else:
            us_df = pd.DataFrame(us_rows)
            for c in us_col_list:
                if c not in us_df.columns:
                    us_df[c] = None
            us_df = us_df[us_col_list]
        us_df.attrs["next_key"] = next_key_val

        hk_col_list = [
            "timestamp", "timestamp_str", "shares_traded", "turnover",
            "short_sell_shares_traded", "short_sell_turnover", "open_price",
            "close_price", "last_close_price", "daily_trade_avg_ratio",
        ]
        hk_rows = ret.get("hk_item_list", []) if isinstance(ret, dict) else []
        if not hk_rows:
            hk_df = pd.DataFrame(columns=hk_col_list)
        else:
            hk_df = pd.DataFrame(hk_rows)
            for c in hk_col_list:
                if c not in hk_df.columns:
                    hk_df[c] = None
            hk_df = hk_df[hk_col_list]
        if isinstance(ret, dict):
            hk_df.attrs["next_key"] = next_key_val
            hk_df.attrs["aggregated_short"] = ret.get("aggregated_short")
            hk_df.attrs["aggregated_short_ratio"] = ret.get("aggregated_short_ratio")
            hk_df.attrs["new_time_str"] = ret.get("new_time_str")

        return RET_OK, us_df, hk_df

    def get_short_interest(self, code, next_key=None, num=None):
        """
        获取空头持仓（美股/港股）
        Get Short Interest (US/HK)
        Returns (ret_code, us_df, hk_df)
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong', None
        query_processor = self._get_sync_query_processor(
            GetShortInterestQuery.pack_req,
            GetShortInterestQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
            'next_key': next_key,
            'num': num,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None

        next_key_val = ret.get("next_key", "-1") if isinstance(ret, dict) else "-1"

        us_col_list = [
            "timestamp", "timestamp_str", "shares_short", "short_percent", "avg_daily_share_volume",
            "days_to_cover", "close_price", "last_close_price",
        ]
        us_rows = ret.get("us_item_list", []) if isinstance(ret, dict) else []
        if not us_rows:
            us_df = pd.DataFrame(columns=us_col_list)
        else:
            us_df = pd.DataFrame(us_rows)
            for c in us_col_list:
                if c not in us_df.columns:
                    us_df[c] = None
            us_df = us_df[us_col_list]
        us_df.attrs["next_key"] = next_key_val

        hk_col_list = [
            "timestamp", "timestamp_str", "aggregated_short", "aggregated_short_ratio",
            "close_price", "last_close_price",
        ]
        hk_rows = ret.get("hk_item_list", []) if isinstance(ret, dict) else []
        if not hk_rows:
            hk_df = pd.DataFrame(columns=hk_col_list)
        else:
            hk_df = pd.DataFrame(hk_rows)
            for c in hk_col_list:
                if c not in hk_df.columns:
                    hk_df[c] = None
            hk_df = hk_df[hk_col_list]
        hk_df.attrs["next_key"] = next_key_val

        return RET_OK, us_df, hk_df

    def get_option_exercise_probability(self, code):
        """
        获取期权行权概率
        Get Option Strike Probability
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetOptionExerciseProbabilityQuery.pack_req,
            GetOptionExerciseProbabilityQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        rows = []
        if isinstance(ret, dict):
            for item in ret.get("item_list", []):
                rows.append(dict(item))
        col_list = [
            "timestamp", "timestamp_str", "security_price", "strike_probability",
        ]
        if not rows:
            ret_frame = pd.DataFrame(columns=col_list)
        else:
            ret_frame = pd.DataFrame(rows)
            for c in col_list:
                if c not in ret_frame.columns:
                    ret_frame[c] = None
            ret_frame = ret_frame[col_list]
        return RET_OK, ret_frame

    def get_option_volatility(self, code, query_time_period=None, hv_time_period=None):
        """
        获取期权波动率分析
        Get Option Volatility Analysis
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetOptionVolatilityQuery.pack_req,
            GetOptionVolatilityQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
            'query_time_period': query_time_period,
            'hv_time_period': hv_time_period,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        meta = {}
        rows = []
        if isinstance(ret, dict):
            meta["average_impvol"] = ret.get("average_impvol")
            meta["impvol_status"] = ret.get("impvol_status")
            meta["analysis"] = ret.get("analysis", "")
            for item in ret.get("item_list", []):
                row = dict(item)
                row.update(meta)
                rows.append(row)
        col_list = [
            "timestamp", "timestamp_str", "implied_volatility", "history_volatility", "volatility_premium",
            "average_impvol", "impvol_status", "analysis",
        ]
        if not rows:
            ret_frame = pd.DataFrame(columns=col_list)
        else:
            ret_frame = pd.DataFrame(rows)
            for c in col_list:
                if c not in ret_frame.columns:
                    ret_frame[c] = None
            ret_frame = ret_frame[col_list]
        return RET_OK, ret_frame

    def get_corporate_actions_dividends(self, code):
        """
        获取分红派息
        Get Bonus Info
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetCorporateActionsDividendsQuery.pack_req,
            GetCorporateActionsDividendsQuery.unpack,
        )
        kargs = {
            'code': code,
            'conn_id': self.get_sync_conn_id(),
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ret

    def get_valuation_detail(self, code, valuation_type=None, interval_type=None):
        """
        获取个股/指数估值详情（含走势、市场分布、行业分布、盈利增速）
        Get Stock / Index Valuation Detail
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetValuationDetailQuery.pack_req,
            GetValuationDetailQuery.unpack,
        )
        kargs = {
            'code': code,
            'valuation_type': valuation_type,
            'interval_type': interval_type,
            'conn_id': self.get_sync_conn_id(),
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ret

    def get_valuation_plate_stock_list(self, code, valuation_type=None, next_key=None,
                                       num=None, sort_type=None, sort_id=None,
                                       filter_security=None):
        """
        获取板块/指数成分股估值
        Get Valuation Plate/Index Stock List
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + 'the type of code param is wrong'
        query_processor = self._get_sync_query_processor(
            GetValuationPlateStockListQuery.pack_req,
            GetValuationPlateStockListQuery.unpack,
        )
        kargs = {
            'code': code,
            'valuation_type': valuation_type,
            'next_key': next_key,
            'num': num,
            'sort_type': sort_type,
            'sort_id': sort_id,
            'filter_security': filter_security,
            'conn_id': self.get_sync_conn_id(),
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ret
    def get_stock_screen(self, request):
        """
        条件选股V2 (ProtoID 3252)

        :param request: StockScreenRequest, 通过 builder 方式构建的筛选请求。
            示例::

                req = StockScreenRequest()
                req.page_count = 50
                req.add_simple_field(field=1, values=[1])
                req.add_simple_property(name=2201, lower=10000)
                ret, data = quote_ctx.get_stock_screen(req)

        :return: (ret, data)
                ret == RET_OK, data = (last_page, all_count, data_list)
                ret != RET_OK, data = error_str
        """
        if request is None:
            return RET_ERROR, ERROR_STR_PREFIX + "request is required, use StockScreenRequest() to build"

        query_processor = self._get_sync_query_processor(
            StockScreenQuery.pack_req, StockScreenQuery.unpack)
        kargs = {
            "request": request,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, content = query_processor(**kargs)
        if ret_code != RET_OK:
            return ret_code, msg
        return RET_OK, content

    def get_warrant_screen(self, request):
        """
        窝轮筛选V2 (ProtoID 3254)
        透传后端 FetchWarrantListV2 协议。
        响应值自动除以倍率返回 float。

        :param request: WarrantScreenRequest, 通过 builder 方式构建的筛选请求。
            示例::

                req = WarrantScreenRequest(warrant_market=WarrantMarket.HK)
                req.add_interval_filter(field_id=8, min_val=100, max_val=500)
                req.add_choice_filter(field_id=6, choices=[1, 2])
                req.add_sort(field_id=8, desc=True)
                req.page_count = 50
                ret, data = quote_ctx.get_warrant_screen(req)

        :return: (ret, data)
                ret == RET_OK, data = (last_page, all_count, DataFrame)
                ret != RET_OK, data = error_str
        """
        if request is None:
            return RET_ERROR, ERROR_STR_PREFIX + "request is required, use WarrantScreenRequest(warrant_market=WarrantMarket.HK) to build"

        query_processor = self._get_sync_query_processor(
            WarrantScreenQuery.pack_req, WarrantScreenQuery.unpack)
        kargs = {
            "request": request,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, content = query_processor(**kargs)
        if ret_code != RET_OK:
            return ret_code, msg

        last_page, all_count, warrant_list = content
        col_list = [
            'code', 'owner_code', 'name', 'owner_name',
            'issuer_id', 'warrant_type',
            'strike_price', 'maturity_date', 'last_trade_date', 'conversion_ratio',
            'last_close_price', 'recovery_price', 'stock_owner_price', 'current_price',
            'volume', 'turnover', 'sell_vol', 'buy_vol', 'sell_price', 'buy_price',
            'street_rate', 'high_price', 'low_price', 'implied_volatility', 'delta',
            'status', 'street_rate_new', 'score', 'premium', 'leverage',
            'effective_leverage', 'break_even_point', 'ipop', 'amplitude',
            'fx_score', 'ipo_time', 'street_vol', 'lot_size', 'issue_size', 'ipo_price',
            'upper_strike_price', 'lower_strike_price', 'iw_price_status',
            'sensitivity', 'price_recovery_ratio',
        ]
        warrant_frame = pd.DataFrame(warrant_list, columns=col_list)
        return RET_OK, (last_page, all_count, warrant_frame)

    def get_option_screen(self, request):
        """
        期权选股 (ProtoID 3253)
        筛选期权合约，支持按标的属性和期权属性联合筛选。
        响应值自动除以倍率返回 float。

        :param request: OptionScreenRequest, 通过 builder 方式构建的筛选请求。
            示例::

                req = OptionScreenRequest(market_categories=[OptMarketCategory.US_STOCK])
                req.add_underlying_filter(OptUnderlyingIndicator.IV, lower=3000000)
                req.add_option_filter(OptIndicator.OPTION_TYPE, values=[1])
                req.add_sort(OptIndicator.VOLUME, desc=True)
                ret, data = quote_ctx.get_option_screen(req)

        :return: (ret, data)
                ret == RET_OK, data = (last_page, all_count, DataFrame)
                ret != RET_OK, data = error_str
        """
        if request is None:
            return RET_ERROR, ERROR_STR_PREFIX + "request is required, use OptionScreenRequest(market_categories=[...]) to build"

        query_processor = self._get_sync_query_processor(
            OptionScreenQuery.pack_req, OptionScreenQuery.unpack)
        kargs = {
            "request": request,
            "conn_id": self.get_sync_conn_id(),
        }
        ret_code, msg, content = query_processor(**kargs)
        if ret_code != RET_OK:
            return ret_code, msg

        last_page, all_count, option_list = content
        col_list = [
            'code', 'option_name', 'strike_price', 'strike_date',
            'option_type', 'exercise_type', 'expiration_type',
            'in_the_money', 'left_day',
            'price', 'mid_price', 'bid_price', 'ask_price', 'bid_ask_spread',
            'bid_volume', 'ask_volume', 'bid_ask_volume_ratio',
            'change_ratio', 'volume', 'turnover',
            'open_interest', 'open_interest_market_cap', 'vol_oi_ratio', 'premium',
            'implied_volatility', 'history_volatility', 'iv_hv_ratio',
            'delta', 'gamma', 'vega', 'theta', 'rho',
            'leverage_ratio', 'effective_gearing', 'itm_probability',
            'buy_to_bep', 'sell_to_bep',
            'buy_profit_probability', 'sell_profit_probability',
            'intrinsic_value_per', 'time_value_per',
            'itm_degree', 'otm_degree', 'otm_probability',
            'sell_annualized_return', 'interval_return',
            'underlying',
        ]
        option_frame = pd.DataFrame(option_list, columns=col_list)
        return RET_OK, (last_page, all_count, option_frame)
    def get_indicator_list(self, search_key=None, lang_type=0, search_mode=0):
        """
        获取全部可用指标列表
        GetIndicatorList

        :param search_key: 搜索子串。为空/None 返回全部
        :param lang_type: 语言过滤，0=Unknown(不过滤), 1=MyLang, 2=Python。对应 IndicatorLangType
        :param search_mode: 0=Partial 部分匹配（默认）, 1=Exact 完全匹配并返回每个 info.script。对应 IndicatorSearchMode
        :return: (RET_OK, list of dict) 或 (RET_ERROR, errMsg)

        每个 dict 表示一个 IndicatorEntry，结构：
            {
                'my_lang': <info dict 或 None>,
                'python':  <info dict 或 None>,
            }

        info dict 结构：
            {
                'short_name': str,
                'full_name':  str,
                'inputs': [
                    {
                        'index': int,
                        'name':  str,
                        'value': {'type': str, 'value': ...} 或 None,
                    },
                    ...
                ],
                'outputs': [
                    {'index': int, 'name': str},
                    ...
                ],
                'script': str,    # 仅 search_mode=1(Exact) 时有值，其余为空串
            }

        value dict 中 type 取值：'INT'/'FLOAT'/'STRING'/'BOOL'/'COLOR'/'SHAPE'/'LINE'/'UNKNOWN'。
        COLOR 对应 value 是 "#RRGGBB" 字符串；SHAPE/LINE 对应 value 是枚举名字符串。
        """
        query_processor = self._get_sync_query_processor(
            GetIndicatorListQuery.pack_req,
            GetIndicatorListQuery.unpack,
        )
        kargs = {
            "conn_id": self.get_sync_conn_id(),
            "search_key": search_key,
            "lang_type": lang_type,
            "search_mode": search_mode,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            return RET_OK, ret
        else:
            return RET_ERROR, "empty data"

    def request_indicator_calc_async(self, short_name, lang_type, code, kl_type, klines, num=None, input_params=None):
        """
        异步发起指标计算：立即返回 calcId，结果通过 Qot_PushIndicatorCalc(3255) 推送。
        调用方需提前 set_handler(IndicatorCalcHandlerBase 子类) 接收推送，并按 calcId 配对。
        :param short_name: 指标短名
        :param lang_type:  1=MyLang, 2=Python
        :param code:       'HK.00700' 等
        :param kl_type:    KLType 字符串（如 KLType.K_DAY）或 Qot_Common.KLType wire 整数
        :param klines:     pandas.DataFrame（request_history_kline / get_cur_kline 返回）或 list[dict]
        :param num: 最多取前 N 条 K 线参与计算；None 表示使用全部 K 线
        :param input_params: list of dict {"index": int, "value": str}，入参覆盖（可空，留空则使用云配置）
        :return: (RET_OK, calc_id) 或 (RET_ERROR, errMsg)
        """
        if not short_name:
            return RET_ERROR, "short_name is empty"
        if not code:
            return RET_ERROR, "code is required (e.g. 'HK.00700')"
        if kl_type is None:
            return RET_ERROR, "kl_type is required"
        if num is not None:
            if not isinstance(num, int) or num <= 0:
                return RET_ERROR, "num must be None or a positive integer"
        if isinstance(kl_type, str):
            ok, val = KLType.to_number(kl_type)
            if not ok:
                return RET_ERROR, val
            kl_type_wire = int(val)
        else:
            kl_type_wire = int(kl_type)
        if hasattr(klines, "to_dict"):
            klines = klines.to_dict(orient="records")
        ret, parsed = split_stock_str(code)
        if ret != RET_OK:
            return RET_ERROR, parsed
        sec_market, sec_code = parsed

        query_processor = self._get_sync_query_processor(
            RequestIndicatorCalcQuery.pack_req,
            RequestIndicatorCalcQuery.unpack,
        )
        kargs = {
            "short_name":      short_name,
            "lang_type":       int(lang_type),
            "klines":          klines,
            "num":             num,
            "input_params":    input_params or [],
            "conn_id":         self.get_sync_conn_id(),
            "security":        {"market": sec_market, "code": sec_code},
            "kl_type":         kl_type_wire,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ret["calc_id"]

    # ============================================================
    # 事件合约 (Event Contract) 接口
    # ============================================================

    def get_event_contract_category(self, category=None):
        """
        获取事件合约分类列表

        :param category: 一级分类标识，选填；填写则只返回该分类的内容，如 "SPORTS"

        :return: (ret, data)

                ret == RET_OK, data 为 DataFrame，包含 category, category_name, tags
                    (tags 为子分类标识字符串列表，如 ["BASEBALL", "FOOTBALL"])

                ret != RET_OK, data 为错误字符串
        """
        query_processor = self._get_sync_query_processor(
            GetEventContractCategoryQuery.pack_req,
            GetEventContractCategoryQuery.unpack,
        )
        kargs = {
            "category": category,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        col_list = ['category', 'category_name', 'tags']
        ret_frame = pd.DataFrame(ret, columns=col_list)
        return RET_OK, ret_frame

    def filter_competition(self, category=None, tag=None):
        """
        赛事筛选

        :param category: 一级分类，如 "SPORTS"
        :param tag: 二级分类，如 "BASEBALL"
        :return: (ret, data)

                ret == RET_OK, data 为 DataFrame，包含 category, tag, competition, scope

                ret != RET_OK, data 为错误字符串
        """
        query_processor = self._get_sync_query_processor(
            FilterCompetitionQuery.pack_req,
            FilterCompetitionQuery.unpack,
        )
        kargs = {
            "category": category,
            "tag": tag,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = ['category', 'tag', 'competition', 'scope']
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        return RET_ERROR, "empty data"

    def get_event_contract_series_list(self, category=None, tag=None):
        """
        获取事件合约Series列表

        :param category: 一级分类，如 "SPORTS"
        :param tag: 二级分类，如 "BASEBALL"
        :return: (ret, data)

                ret == RET_OK, data 为 DataFrame，包含 series_code, series_name, category, tags, frequency
                    (tags 为二级分类标识字符串列表，一个 series 可归属多个 tag)

                ret != RET_OK, data 为错误字符串
        """
        query_processor = self._get_sync_query_processor(
            GetEventContractSeriesListQuery.pack_req,
            GetEventContractSeriesListQuery.unpack,
        )
        kargs = {
            "category": category,
            "tag": tag,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        if isinstance(ret, list):
            col_list = ['series_code', 'series_name', 'category', 'tags', 'frequency']
            ret_frame = pd.DataFrame(ret, columns=col_list)
            return RET_OK, ret_frame
        return RET_ERROR, "empty data"

    def get_event_contract_event_list(self, series_code, status=None, next_page=None, count=None):
        """
        获取事件合约Event列表

        :param series_code: Series代码，如 "EC.xxx"，必填
        :param status: 事件状态过滤，ECStatus 枚举值
        :param next_page: 翻页标记，首次传None，后续传上次返回的 next_page
        :param count: 返回数量上限，默认200
        :return: (ret, data, next_page)

                ret == RET_OK, data 为 DataFrame, next_page 为翻页标记(空字符串表示无更多)

                ret != RET_OK, data 为错误字符串
        """
        if series_code is None or not is_str(series_code):
            return RET_ERROR, "series_code is required", None

        query_processor = self._get_sync_query_processor(
            GetEventContractEventListQuery.pack_req,
            GetEventContractEventListQuery.unpack,
        )
        kargs = {
            "series_code": series_code,
            "status": status,
            "next_page": next_page,
            "count": count,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None
        event_list, page = ret
        col_list = ['event_code', 'event_name', 'event_sub_name', 'status', 'series_code',
                    'start_date', 'end_date', 'category', 'tags', 'mutually_exclusive',
                    'competition', 'competition_scope']
        ret_frame = pd.DataFrame(event_list, columns=col_list)
        return RET_OK, ret_frame, page

    def get_event_contract(self, event_code, next_page=None, count=None):
        """
        获取事件合约Contract列表

        :param event_code: Event代码，如 "EC.xxx"，必填
        :param next_page: 翻页标记
        :param count: 返回数量上限，默认100，最大1000
        :return: (ret, data, next_page)

                ret == RET_OK, data 为 dict 包含 'contract_list'(DataFrame), 'recommend_contracts'(list), next_page 为翻页标记

                ret != RET_OK, data 为错误字符串
        """
        if event_code is None or not is_str(event_code):
            return RET_ERROR, "event_code is required", None

        query_processor = self._get_sync_query_processor(
            GetEventContractQuery.pack_req,
            GetEventContractQuery.unpack,
        )
        kargs = {
            "event_code": event_code,
            "next_page": next_page,
            "count": count,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None
        contract_list, recommend_list, page = ret
        col_list = ['contract_code', 'event_code', 'series_code', 'contract_type', 'title',
                    'yes_sub_title', 'open_time', 'close_time', 'determination_time',
                    'settled_time', 'latest_expiration_time', 'status', 'result',
                    'settlement_value', 'expiration_value', 'volume',
                    'can_close_early', 'tick_size', 'category', 'tag']
        contract_frame = pd.DataFrame(contract_list, columns=col_list)
        return RET_OK, {'contract_list': contract_frame, 'recommend_contracts': recommend_list}, page

    def get_event_contract_milestone_list(self, category=None, competition=None, related_event=None, next_page=None, count=None):
        """
        获取事件合约里程碑列表

        :param category: 一级分类，如 "SPORTS"
        :param competition: 赛事筛选
        :param related_event: 关联事件代码，如 "EC.xxx"
        :param next_page: 翻页标记
        :param count: 返回数量上限，默认200
        :return: (ret, data, next_page)

                ret == RET_OK, data 为 DataFrame, next_page 为翻页标记

                ret != RET_OK, data 为错误字符串
        """
        query_processor = self._get_sync_query_processor(
            GetEventContractMilestoneListQuery.pack_req,
            GetEventContractMilestoneListQuery.unpack,
        )
        kargs = {
            "category": category,
            "competition": competition,
            "related_event": related_event,
            "next_page": next_page,
            "count": count,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None
        milestone_list, page = ret
        col_list = ['milestone_code', 'title', 'category', 'type', 'start_date',
                    'end_date', 'primary_event_code', 'related_events', 'notification_message']
        ret_frame = pd.DataFrame(milestone_list, columns=col_list)
        return RET_OK, ret_frame, page

    def get_valid_combo_list(self, category=None, competition=None, series=None, next_page=None, count=None):
        """
        获取可Combo事件列表

        :param category: 一级分类过滤，如 "SPORTS"
        :param competition: 赛事过滤
        :param series: Series标的过滤，如 "EC.xxx"
        :param next_page: 翻页标记，首次传None，后续传上次返回的 next_page
        :param count: 单页最大返回数，默认200
        :return: (ret, data, mvc, next_page)

                ret == RET_OK, data 为 DataFrame(包含 event_code, event_name, combo_contracts,
                    series_code, category, competition, competition_scope), mvc 为MVC标的(询价接口需透传),
                    next_page 为翻页标记(空字符串表示无更多)

                ret != RET_OK, data 为错误字符串
        """
        query_processor = self._get_sync_query_processor(
            GetEventContractComboListQuery.pack_req,
            GetEventContractComboListQuery.unpack,
        )
        kargs = {
            "category": category,
            "competition": competition,
            "series": series,
            "next_page": next_page,
            "count": count,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg, None, None
        combo_list, mvc, page = ret
        col_list = ['event_code', 'event_name', 'combo_contracts', 'series_code',
                    'category', 'competition', 'competition_scope']
        ret_frame = pd.DataFrame(combo_list, columns=col_list)
        return RET_OK, ret_frame, mvc, page

    def request_combo_quotes(self, combo_leg_list, mvc):
        """
        Combo询价

        :param combo_leg_list: 腿列表，ComboLeg 对象列表
        :param mvc: MVC标的，从 get_valid_combo_list 返回值透传，必填
        :return: (ret, data)

                ret == RET_OK, data 为 dict，包含 combo_leg_list(回显腿列表, ComboLeg 对象列表),
                    bid_price(yes买价), ask_price(yes卖价), quote_id(报价ID，下单需用),
                    should_retry(是否建议重试)

                ret != RET_OK, data 为错误字符串
        """
        if not combo_leg_list or not isinstance(combo_leg_list, list):
            return RET_ERROR, "combo_leg_list is required"
        for leg in combo_leg_list:
            if not isinstance(leg, ComboLeg):
                return RET_ERROR, make_wrong_type_msg('combo_leg_list item', 'ComboLeg')
        if mvc is None or not is_str(mvc):
            return RET_ERROR, "mvc is required"

        query_processor = self._get_sync_query_processor(
            GetEventContractComboRfqQuery.pack_req,
            GetEventContractComboRfqQuery.unpack,
        )
        kargs = {
            "combo_leg_list": combo_leg_list,
            "mvc": mvc,
            "conn_id": self.get_sync_conn_id(),
            "security_firm": self.__security_firm,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, ret

    def subscribe_event_contract(self, code_list, subtype_list, kline_source_list=None,
                                 is_first_push=True, subscribe_push=True):
        """
        订阅事件合约实时信息，指定合约代码和订阅的数据类型即可

        :param code_list: 需要订阅的事件合约代码列表，如 ['EC.xxx']
        :param subtype_list: 需要订阅的数据类型列表，参见SubType（QUOTE/ORDER_BOOK/TICKER/K_*）
        :param kline_source_list: K线来源列表，参见ECKlineSource，订阅K线类型时生效，
                                  如 [ECKlineSource.ORDER_BOOK_YES]，不填，由后端按默认
                                  （合约级成交价K线）处理
        :param is_first_push: 订阅成功后是否马上推送一次已有数据
        :param subscribe_push: 订阅后是否注册推送
        :return: (ret, err_message)

                ret == RET_OK err_message为None

                ret != RET_OK err_message为错误描述字符串
        :example:

        .. code:: python

        from futu import *
        quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
        quote_ctx.set_handler(EventContractKlineHandlerBase())  # 接收K线推送需先设置handler
        print(quote_ctx.subscribe_event_contract(['EC.xxx'], [SubType.K_DAY]))
        quote_ctx.close()
        """
        ret, msg, code_list, subtype_list = self._check_subscribe_param(
            code_list, subtype_list)
        if ret != RET_OK:
            return ret, msg

        query_processor = self._get_sync_query_processor(
            SubEventContractQuery.pack_subscribe_req,
            SubEventContractQuery.unpack_rsp,
        )
        kargs = {
            'code_list': code_list,
            'subtype_list': subtype_list,
            'conn_id': self.get_sync_conn_id(),
            'is_first_push': is_first_push,
            'subscribe_push': subscribe_push,
            'kline_source_list': kline_source_list,
            'security_firm': self.__security_firm,
        }
        ret_code, msg, _ = query_processor(**kargs)
        if ret_code != RET_OK:
            return RET_ERROR, msg
        return RET_OK, None

    def unsubscribe_event_contract(self, code_list, subtype_list, kline_source_list=None):
        """
        取消订阅事件合约

        :param code_list: 取消订阅的事件合约代码列表
        :param subtype_list: 取消订阅的类型，参见SubType
        :param kline_source_list: K线来源列表，参见ECKlineSource，用于精确反订阅某K线来源，不填忽略该维度
        :return: (ret, err_message)

                ret == RET_OK err_message为None

                ret != RET_OK err_message为错误描述字符串
        """
        ret, msg, code_list, subtype_list = self._check_subscribe_param(
            code_list, subtype_list)
        if ret != RET_OK:
            return ret, msg

        query_processor = self._get_sync_query_processor(
            SubEventContractQuery.pack_unsubscribe_req,
            SubEventContractQuery.unpack_rsp,
        )
        kargs = {
            'code_list': code_list,
            'subtype_list': subtype_list,
            'conn_id': self.get_sync_conn_id(),
            'subscribe_push': False,
            'kline_source_list': kline_source_list,
            'security_firm': self.__security_firm,
        }
        ret_code, msg, _ = query_processor(**kargs)
        if ret_code != RET_OK:
            return RET_ERROR, msg
        return RET_OK, None

    def unsubscribe_all_event_contract(self):
        """
        取消当前连接所有事件合约订阅
        :return: (ret, err_message)
        """
        query_processor = self._get_sync_query_processor(
            SubEventContractQuery.pack_unsub_all_req,
            SubEventContractQuery.unpack_rsp,
        )
        kargs = {
            'conn_id': self.get_sync_conn_id(),
            'security_firm': self.__security_firm,
        }
        ret_code, msg, _ = query_processor(**kargs)
        if ret_code != RET_OK:
            return RET_ERROR, msg
        return RET_OK, None

    def get_event_contract_snapshot(self, code_list):
        """
        获取事件合约快照

        :param code_list: 事件合约代码列表，如 ['EC.xxx']
        :return: (ret, data)

                ret == RET_OK, data 为 DataFrame，包含 code, name, event_code, yes_sub_title,
                    no_sub_title, status, price, cumulative_volume, yes_bid, yes_bid_size, yes_ask, yes_ask_size,
                    no_bid, no_bid_size, no_ask, no_ask_size, last_trade_time, volume_24h, open_interest

                ret != RET_OK, data 为错误字符串
        """
        if is_str(code_list):
            code_list = [code_list]
        code_list = unique_and_normalize_list(code_list)
        if not code_list:
            return RET_ERROR, ERROR_STR_PREFIX + "code_list is null"

        query_processor = self._get_sync_query_processor(
            GetEventContractSnapshotQuery.pack_req,
            GetEventContractSnapshotQuery.unpack,
        )
        kargs = {
            'code_list': code_list,
            'conn_id': self.get_sync_conn_id(),
            'security_firm': self.__security_firm,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        col_list = ['code', 'name', 'event_code', 'yes_sub_title', 'no_sub_title',
                    'status', 'price', 'cumulative_volume', 'yes_bid', 'yes_bid_size', 'yes_ask',
                    'yes_ask_size', 'no_bid', 'no_bid_size', 'no_ask', 'no_ask_size',
                    'last_trade_time', 'volume_24h', 'open_interest']
        ret_frame = pd.DataFrame(ret, columns=col_list)
        return RET_OK, ret_frame

    def get_event_contract_order_book(self, code, num=10):
        """
        获取事件合约实时摆盘数据

        :param code: 事件合约代码，如 'EC.xxx'
        :param num: 请求的摆盘档数，默认10，需大于0；实际返回档数按后台数据收敛
        :return: (ret, data)

                ret == RET_OK 返回字典，数据格式如下

                ret != RET_OK 返回错误字符串

                {'code': 合约代码
                 'yes_bids': [(yes_bid_price1, size1), (yes_bid_price2, size2), ...]   # YES 买盘
                 'yes_asks': [(yes_ask_price1, size1), (yes_ask_price2, size2), ...]   # YES 卖盘
                 'no_bids':  [(no_bid_price1, size1), (no_bid_price2, size2), ...]     # NO 买盘
                 'no_asks':  [(no_ask_price1, size1), (no_ask_price2, size2), ...]}    # NO 卖盘
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + "the type of code param is wrong"

        if num is None or isinstance(num, int) is False:
            error_str = ERROR_STR_PREFIX + "the type of num param is wrong"
            return RET_ERROR, error_str

        if num <= 0:
            error_str = ERROR_STR_PREFIX + "num is %s, which should be greater than 0" % num
            return RET_ERROR, error_str

        query_processor = self._get_sync_query_processor(
            GetEventContractOrderBookQuery.pack_req,
            GetEventContractOrderBookQuery.unpack,
        )
        kargs = {
            'code': code,
            'num': num,
            'conn_id': self.get_sync_conn_id(),
            'security_firm': self.__security_firm,
        }
        ret_code, msg, orderbook = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        return RET_OK, orderbook

    def get_event_contract_kline(self, code, pre_side=None, ktype=KLType.K_DAY,
                                 kline_source=None, max_count=1000):
        """
        获取事件合约K线

        :param code: 事件合约代码，如 'EC.xxx'
        :param pre_side: 合约方向，参见PredSide（YES/NO），
                         kline_source=None 且为合约级K线时需指定方向
        :param ktype: K线类型，参见KLType，事件合约仅支持 K_1M/K_5M/K_60M/K_DAY
        :param kline_source: K线来源，参见ECKlineSource（ORDER_BOOK_YES），
                             不填表示合约级成交价K线；优先级高于 pre_side
        :param max_count: 最大返回条数，上限1000
        :return: (ret, data)

                ret == RET_OK, data 为 DataFrame，包含 code, pre_side, name, time_key, open,
                    high, low, close, volume

                ret != RET_OK, data 为错误字符串
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + "the type of code param is wrong"

        query_processor = self._get_sync_query_processor(
            GetEventContractKlineQuery.pack_req,
            GetEventContractKlineQuery.unpack,
        )
        kargs = {
            'code': code,
            'pre_side': pre_side,
            'ktype': ktype,
            'kline_source': kline_source,
            'max_count': max_count,
            'conn_id': self.get_sync_conn_id(),
            'security_firm': self.__security_firm,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        col_list = ['code', 'pre_side', 'name', 'time_key', 'open', 'high',
                    'low', 'close', 'volume']
        ret_frame = pd.DataFrame(ret, columns=col_list)
        return RET_OK, ret_frame

    def get_event_contract_ticker(self, code, count=30):
        """
        获取事件合约实时逐笔

        :param code: 事件合约代码，如 'EC.xxx'
        :param count: 返回条数，默认30，最大1000
        :return: (ret, data)

                ret == RET_OK, data 为 DataFrame，包含 code, time, yes_price, no_price, volume,
                    side, sequence

                ret != RET_OK, data 为错误字符串
        """
        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + "the type of code param is wrong"

        query_processor = self._get_sync_query_processor(
            GetEventContractTickerQuery.pack_req,
            GetEventContractTickerQuery.unpack,
        )
        kargs = {
            'code': code,
            'count': count,
            'conn_id': self.get_sync_conn_id(),
            'security_firm': self.__security_firm,
        }
        ret_code, msg, ret = query_processor(**kargs)
        if ret_code == RET_ERROR:
            return ret_code, msg
        col_list = ['code', 'time', 'yes_price', 'no_price', 'volume',
                    'side', 'sequence']
        ret_frame = pd.DataFrame(ret, columns=col_list)
        return RET_OK, ret_frame

    def request_history_event_contract_kline(self, code, start=None, end=None,
                                             pre_side=None, ktype=KLType.K_DAY,
                                             kline_source=None, max_count=1000,
                                             page_req_key=None):
        """
        拉取事件合约历史K线，不需要先下载历史数据。

        :param code: 事件合约代码
        :param start: 开始时间，例如'2025-06-20'
        :param end:  结束时间，例如'2025-07-20'。
                  start和end的组合如下：
                     ==========    ==========    ========================================
                     start类型      end类型       说明
                     ==========    ==========    ========================================
                     str            str           start和end分别为指定的日期
                     None           str           start为end往前365天
                     str            None          end为start往后365天
                     None           None          end为当前日期，start为end往前365天
                     ==========    ==========    ========================================
        :param pre_side: 合约方向，参见PredSide
        :param ktype: K线类型，参见KLType，事件合约仅支持 K_1M/K_5M/K_60M/K_DAY
        :param kline_source: K线来源，参见ECKlineSource（ORDER_BOOK_YES）；选填，不填，由后端按默认
                             （合约级成交价K线）处理
        :param max_count: 本次请求最大返回的数据点个数，传None表示返回start和end之间所有的数据。
        :param page_req_key: 分页请求的key。如果start和end之间的数据点多于max_count，那么后续请求时，
                             要传入上次调用返回的page_req_key。初始请求时应该传None。
        :return: (ret, data, page_req_key)

                ret == RET_OK 返回pd dataframe数据。page_req_key在分页请求时（即max_count>0）
                可能返回，并且需要在后续的请求中传入。如果没有更多数据，page_req_key返回None。

                ret != RET_OK 返回错误字符串

            =================   ===========   ==============================================================================
            参数                  类型                        说明
            =================   ===========   ==============================================================================
            code                str            事件合约代码
            pre_side            str            合约方向，参见PredSide
            name                str            合约名称
            time_key            str            k线时间
            open                float          开盘价
            high                float         最高价
            low                 float         最低价
            close               float          收盘价
            volume              float          成交量
            =================   ===========   ==============================================================================
        :example:

        .. code:: python

            from futu import *
            quote_ctx = OpenQuoteContext(host='127.0.0.1', port=11111)
            ret, data, page_req_key = quote_ctx.request_history_event_contract_kline(
                'EC.xxx', start='2025-06-20', end='2025-07-20', kline_source=ECKlineSource.ORDER_BOOK_YES, max_count=50)
            print(ret, data)
            quote_ctx.close()
        """
        next_page_req_key = None
        ret, msg, req_start, end = normalize_start_end_date(start, end, 365)
        if ret != RET_OK:
            return ret, msg, next_page_req_key

        if code is None or is_str(code) is False:
            return RET_ERROR, ERROR_STR_PREFIX + "the type of code param is wrong", next_page_req_key
        if not KLType.if_has_key(ktype):
            error_str = ERROR_STR_PREFIX + "ktype is %s, which is not valid. (%s)" \
                % (ktype, KLType.get_all_keys())
            return RET_ERROR, error_str, next_page_req_key
        if kline_source is not None and not ECKlineSource.if_has_key(kline_source):
            error_str = ERROR_STR_PREFIX + "kline_source is %s, which is not valid. (%s)" \
                % (kline_source, ECKlineSource.get_all_keys())
            return RET_ERROR, error_str, next_page_req_key

        max_kl_num = min(1000, max_count) if max_count is not None else 1000
        data_finish = False
        list_ret = []
        while not data_finish:
            kargs = {
                'code': code,
                'pre_side': pre_side,
                'kl_type': ktype,
                'kline_source': kline_source,
                'begin_time': req_start,
                'end_time': end,
                'max_ack_kl_num': max_kl_num,
                'conn_id': self.get_sync_conn_id(),
                'next_req_key': page_req_key,
                'security_firm': self.__security_firm,
            }
            query_processor = self._get_sync_query_processor(
                RequestHistoryEventContractKlQuery.pack_req,
                RequestHistoryEventContractKlQuery.unpack_rsp,
            )
            ret_code, msg, content = query_processor(**kargs)
            if ret_code != RET_OK:
                return ret_code, msg, next_page_req_key

            list_kline, has_next, page_req_key = content
            list_ret.extend(list_kline)
            next_page_req_key = page_req_key
            if max_count is not None:
                if max_count > len(list_ret) and has_next:
                    data_finish = False
                    max_kl_num = min(max_count - len(list_ret), 1000)
                else:
                    data_finish = True
            else:
                data_finish = not has_next

        col_list = ['code', 'pre_side', 'name', 'time_key', 'open', 'high',
                    'low', 'close', 'volume']
        kline_frame_table = pd.DataFrame(list_ret, columns=col_list)
        return RET_OK, kline_frame_table, next_page_req_key

